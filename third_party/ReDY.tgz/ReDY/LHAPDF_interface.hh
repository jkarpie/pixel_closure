/*
  This header contains the link to the LHAPDF libraries.
  Every function defined there may be called using

    LHAPDF::function_defined_in_lhapdf(....)

  The functions defined here are called using

    PDF::function_defined_here(....)

  and are essentially aliases redefined here for convenience.
  You are referred to the LHAPDF library
       http://projects.hepforge.org/lhapdf/
  for detailed explainations.
*/

#ifndef PDF_H
#define PDF_H

#include <string>
#include <iostream>
#include "LHAPDF/LHAPDF.h"  // PDF library LHAPDF

enum verbosity { SILENT=0, LOWKEY=1, DEFAULT=2 };
enum approx_method { interpol=0, chebyshev=1 };


namespace PDF {

  //extern bool initialized;
  extern int check_initialization();

  // initialize a pdf.
  extern int pdf_init(std::string SET_NAME, int SUBSET=0, verbosity v=DEFAULT);

  // use approximate PDFs:
  // computes once for all the PDFs for a given mu^2 and x in a given range
  extern int UseApproximatePDFs(bool approx=true, approx_method meth=interpol, unsigned int n=1000);
  extern bool IsApproximatePDFs();
  extern int SetApproxMethod(approx_method meth=interpol, unsigned int n=1000);
  extern approx_method GetApproxMethod();
  extern int SetAutomaticMu(bool automu=true);
  extern int pdfs_approx(double mu, double xmin, double xmax=1.);

  // stuff
  extern int pdf_select_subset(int subset);
  extern int number_of_subsets();
  extern void extrapolate(bool extrapolate=true);

  // alpha_s as in the PDF set
  extern double alphas_PDF(double Q);

  // print info
  extern void PrintPDFInfo(int SUBSET=0);
  

  // Call pdfs in a standard notation, after the above initialization.
  // 
  // using approximate PDFs: 
  //   mu < 0 is ignored ( use mu as set in pdfs_approx(mu,...) )
  //   mu > 0 and different from that set with pdfs_approx(mu,...) will:
  //       - use the previous mu if SetAutomaticMu(false) DEFAULT
  //       - call again pdfs_approx(mu,...) if SetAutomaticMu(true)
  extern double pdf (int pdf_number, double x, double mu=-1);
  extern double u   (double x, double mu=-1);
  extern double ubar(double x, double mu=-1);
  extern double d   (double x, double mu=-1);
  extern double dbar(double x, double mu=-1);
  extern double s   (double x, double mu=-1);
  extern double str (double x, double mu=-1);
  extern double sbar(double x, double mu=-1);
  extern double c   (double x, double mu=-1);
  extern double chm (double x, double mu=-1);
  extern double cbar(double x, double mu=-1);
  extern double b   (double x, double mu=-1);
  extern double bot (double x, double mu=-1);
  extern double bbar(double x, double mu=-1);
  extern double g   (double x, double mu=-1);

  // same as before, but call x*f(x,Q)
  extern double xpdf (int pdf_number, double x, double mu=-1);
  extern double xu   (double x, double mu=-1);
  extern double xubar(double x, double mu=-1);
  extern double xd   (double x, double mu=-1);
  extern double xdbar(double x, double mu=-1);
  extern double xs   (double x, double mu=-1);
  extern double xstr (double x, double mu=-1);
  extern double xsbar(double x, double mu=-1);
  extern double xc   (double x, double mu=-1);
  extern double xchm (double x, double mu=-1);
  extern double xcbar(double x, double mu=-1);
  extern double xb   (double x, double mu=-1);
  extern double xbot (double x, double mu=-1);
  extern double xbbar(double x, double mu=-1);
  extern double xg   (double x, double mu=-1);


};

# endif    /*  PDF_H  */
