#include <cmath>
#include "resummation.hh"
#include "chebyshev.hh"
#include "QCD_EW.hh"
#include "math/dilog.hh"
#include "math/gauss_integration.hh"
#include "vtot.hh"
#include "vrap.hh"
#include "LHAPDF_interface.hh"
#include <gsl/gsl_sf.h>
#include <gsl/gsl_errno.h>

using namespace std;



namespace resumm {

  const double gamma_E = 0.5772156649015328606065120900824;

  // flag to choose the BNX luminosity
  bool BNX = false;

  bool not_approx_pdf_minimal=false, not_approx_pdf_borel=false, extern_approx;

  double nf;
  double alpha, alphabar;
  double s, q, mur, muf, mur_rat, muf_rat;
  double luminosity_in_x;
  double b0, b1, b2;
  unsigned int LL_order, matching_order;
  collider coll_res;
  double c_mp, aa=1.;
  double em2Y;

  // chebyshev stuff
  int n_max_cheb_borel;
  double *coeff_cheb_borel;
  int n_max_cheb_lum;
  double *coeff_cheb_lum;
  double beta_lum=5., gamma_lum=6.;
  int method_cheb_lum=0;

  // coefficients for resummation functions
  double A1 = QCD::C_F/M_PI;
  double A2, A3, D2; // definition inside init_res(..)
  double g01, g02;


  // functions in the exponent; gk means N^(k-1)LL approximation
  // z is the variable alphabar*log(1/N)
  complex g1(complex z) {
    return (log(z+1)*(z+1)-z)*(2.*A1/b0);
  }
  complex g2(complex z) {
    return (( pow(log(z+1),2)*0.5 - z + log(z+1) ) * ( A1*b1/b0/b0 ) +
	    (z - log(z+1) ) * A2/b0/b0
	    - (log(z+1) * (gamma_E - log(q/mur)) + z*log(muf/mur) )*2.*A1/b0 );
  }
  // g3 taken from Moch-Vermaseren-Vogt, hep-ph/0506288
  complex g3(complex z) {
    return ( (z*z/(z+1.)) * (A3 - A1*b2 + A1*b1*b1 - A2*b1)/2./b0/b0/b0
	     + ( log(z+1.)/(z+1.) + pow(log(z+1.),2.)/(z+1.)/2. ) * A1*b1*b1/b0/b0/b0
	     + log(z+1.) * A1*(b2-b1*b1)/b0/b0/b0
	     + ( z/(z+1.) - log(z+1.)/(z+1.) ) * ( 2.*A1*b1*gamma_E + A2*b1/b0 )/b0/b0
	     - ( z/(z+1.) ) * ( A1*b2/b0/b0 + 2.*A1*(gamma_E*gamma_E + ZETA2) + 2.*A2*gamma_E/b0 )/b0
	     + ( z/(z+1.) ) * D2/2./b0/b0
	     + ( ( z/(z+1.) ) * ( 2.*A1*gamma_E + A2/b0 -A1*b1/b0 )/b0
	      + log(z+1.)/(z+1.) * A1*b1/b0/b0 ) * 2.*log(q/mur)
	     - z * A2/b0/b0 * 2.*log(muf/mur)
	     + ( z * pow(log(muf/mur),2.) - z/(z+1.) * pow(log(q/mur),2.) ) * 2.*A1/b0 
	     )/2.;
  }

  // Sudakov exponent
  complex S(complex z) {
    complex value;
    value = g1(z)/alphabar;
    if(LL_order > 0) value += g2(z);
    if(LL_order > 1) value += g3(z)*alphabar;
    return value;
  }
  double g0() {
    double value = 1.;
    if(LL_order > 0) value += g01 * alpha;
    if(LL_order > 1) value += g02 * alpha*alpha;
    return value;
  }


  complex expS_order1(complex z) {
    complex value;
    value = z*z*A1/b0/alphabar;
    if(LL_order > 0) value += z*2*(log(q/muf)-gamma_E)*A1/b0 + g01*alpha;
    return value;
  }
  complex expS_order2(complex z) {
    complex value;
    value = pow(expS_order1(z),2.)/2. - z*z*z*A1/b0/alphabar/3.;
    if(LL_order > 0) value += z*z*( A1*(gamma_E-log(q/mur))/b0 + A2/2./b0/b0 ) - g01*alpha*g01*alpha/2.;
    if(LL_order > 1) value += z*alphabar* ( D2/2./b0/b0 - 2.*A2*gamma_E/b0/b0 - 2.*A1*(gamma_E*gamma_E+ZETA2)/b0
					    + 4.*A1*gamma_E*log(q/mur)/b0 +2.*A2*log(q/muf)/b0/b0
					    - 2.*A1*(pow(log(q/mur),2.)-pow(log(muf/mur),2.))/b0 )/2. + g02*alpha*alpha;
    return value;
  }
  complex expS_matched(complex z){
    complex value;
    value = exp(S(z)) * g0() - 1.;
    if(matching_order > 0) value -= expS_order1(z);
    if(matching_order > 1) value -= expS_order2(z);
    return value;
  }






  ///////////////////////////
  //  BOREL  PRESCRIPTION  //
  ///////////////////////////

  int  borel_type  = 1;    // default eq. (3.29)
  bool borel_const = true; // default eq. (3.29)
  complex delta_term(complex xi, double x) {
    complex val;
    //if     (borel_type == 0) val = (1.-exp((xi)*log(1-x)))/xi;
    //else if(borel_type == 1) val = 1./xi - IncompleteBeta(xi, 1.-xi/2., 1.-x);
    if     (borel_type == 0) val = -exp((xi)*log(1-x))/xi;
    else if(borel_type == 1) val = -IncompleteBeta(xi, 1.-xi/2., 1.-x);
    //else if(borel_type == 2) val = IncompleteGamma(xi, log(1./x)); // must give the same result as below (Cauchy theorem)
    else if(borel_type == 2) val = TruncatedGamma(xi, log(1./x));
    if(borel_const) val += 1./xi;
    return val;
  }
  complex cheb_term(complex xi, double x, int j) {
    complex val;
    if     (borel_type == 0) val = exp((xi+j+1.)*log(1.-x))/(xi+j+1.);
    else if(borel_type == 1) val = IncompleteBeta(xi+j+1, 1.-xi/2., 1.-x);
    else if(borel_type == 2) val = TruncatedGamma(xi+j+1, log(1./x));
    //else if(borel_type == 2) val = TruncatedGamma(xi, (1.+j)*log(1./x)) * exp(-xi*log(1.+j));
    return val;
  }
  complex convolution(complex xi, double x) { 
    complex value(0.,0.);
    for(int j=0; j<=n_max_cheb_borel; j++) {
      value += coeff_cheb_borel[j] * cheb_term(xi,x,j);
    }
    return value - luminosity_in_x * delta_term(xi,x);
  }
  complex sigma_exp(double w, complex xi) {
    return expS_matched(w/xi)*exp(-w/alphabar);
  }
  double sigma_exp_re(double w, void *p) {
    complex xi = *(complex *) p;
    return real(sigma_exp(w,xi));
  }
  double sigma_exp_im(double w, void *p) {
    complex xi = *(complex *) p;
    return imag(sigma_exp(w,xi));
  }
  // Integrating in dw first
  complex R1(complex xi, double C, double x) {
    double prec=1e-4;
    complex res(integration::gauss(sigma_exp_re,0.,C,prec,xi),integration::gauss(sigma_exp_im,0.,C,prec,xi));
    complex value = res*convolution(xi,x)/xi/Gamma(xi)/2./M_PI/alphabar;
    return value;
  }
  complex Rtheta(double theta, double C, double x) {
    double r=0.3+C;
    complex xi = polar(r,theta);
    return R1(xi,C,x)*xi;
  }
  double Rtheta_re(double theta, void *p) {
    complex par = *(complex *) p;
    return real(Rtheta(theta,real(par),imag(par)));
  }
  // Integrating in d\xi
  double Borel_polar(double x, double C) {
    double prec=1e-4;
    complex par(C,x);
    return 2*integration::gauss(Rtheta_re,0,M_PI,prec,par); // two times half circle
    //return integration::gauss(Rtheta_re,0,2.*M_PI,prec,par); // full circle
  }






  ///////////////////////////
  //  MINIMAL PRESCRIPTION //
  ///////////////////////////

  complex LuminosityN(complex N){
    complex value(0,0);
    for(int i=0; i<=n_max_cheb_lum; i++) {
      if(method_cheb_lum==2) // total
	if(isINT(gamma_lum)) {
	  for(int j=0; j<=gamma_lum; j++) {
	    value += coeff_cheb_lum[i] * pow(-1.,j) * gsl_sf_choose(INT(gamma_lum),j) / (N+i+j-beta_lum);
	  }
	} else {
	  //value += Gamma(N+i-beta_lum) * gsl_sf_gamma(1+gamma_lum) * coeff_cheb_lum[i] / Gamma(N + i + 1 - beta_lum + gamma_lum);
	  value += exp(log(Gamma(N+i-beta_lum)) - log(Gamma(N + i + 1 - beta_lum + gamma_lum))) * gsl_sf_gamma(1+gamma_lum) * coeff_cheb_lum[i];
	}
      else if(method_cheb_lum==3) // total log
	value += coeff_cheb_lum[i]/pow(N-1.,i+1.);
      else if(method_cheb_lum==0) // rap
	if(isINT(gamma_lum)) {
	  for(int j=0; j<=gamma_lum; j++) {
	    value += coeff_cheb_lum[i] * pow(-1.,j) * gsl_sf_choose(INT(gamma_lum),j) * pow(em2Y, i+j-beta_lum+gamma_lum-j) / (N+i+j-beta_lum);
	  }
	} else {
	  cerr << "Not yet implemented for non-integer values of gamma_lum" << endl;
	  exit(-33);
	  //value += IncompleteBeta(N+i-beta_lum, 1.+gamma_lum, em2Y) * coeff_cheb_lum[i];
	}
      else if(method_cheb_lum==1) // rap log
	value += coeff_cheb_lum[i]/pow(N-1.,i+1.)/em2Y;
      else {
	cerr << "Non existent method for luminosity Chebyshev approximation." << endl;
	exit(-12);
      }
    }
    return value;
  }
  complex lum_times_expS_matched(complex N) {
    complex z = -alphabar*log(N);
    return expS_matched(z) * LuminosityN(N);
  }
  double Minimal_integrand(double t, void *p) {
    double x = * (double *) p;
    complex N = c_mp + (aa-I)*log(t);
    complex res = (I-aa) * exp(-N*log(x)) * lum_times_expS_matched(N)/t;
    return imag(res)/M_PI;
  }
  double Minimal_integrand_inf(double t, void *p) {
    double x = * (double *) p;
    complex N = c_mp + (I-aa)*t;
    complex res = (I-aa) * exp(-N*log(x)) * lum_times_expS_matched(N);
    return imag(res)/M_PI;
  }
  double x_Minimal(double x) {
    double prec = 1e-4;
    return integration::dgauss(Minimal_integrand,0.,1.,prec,x);
    //return integration::gauss_inf_up(Minimal_integrand_inf,0.,prec,x);  // fails..
  }
  double rap_Minimal(double Y, double x) {
    em2Y = exp(-2*ABS(Y));
    double prec = 1e-4;
    //return integration::dgauss(Minimal_integrand,0.,1.,prec,x/em2Y);
    return integration::gauss_inf_up(Minimal_integrand_inf,0.,prec,x/em2Y);  // faster
  }




  int Init(double S, double alpha_s, double muF_q_ratio, double muR_q_ratio, int n_f, collider coll) {
    s = S;
    mur_rat = muR_q_ratio;
    muf_rat = muF_q_ratio;
    coll_res = coll;
    nf = (double)n_f;
    b0 = QCD::b0(nf);
    b1 = QCD::b1(nf);
    b2 = QCD::b2(nf);
    alpha = alpha_s;
    alphabar = 2*b0*alpha;
    A2 = (67.*QCD::C_A/2.-10.*QCD::T_R*nf)*QCD::C_F/18./M_PI/M_PI - QCD::C_A*QCD::C_F/12.;
    A3 = ( QCD::C_A*QCD::C_A* (245./24.-67.*ZETA2/9.+11.*ZETA3/6.+11.*ZETA2*ZETA2/5.) +
	   ( (2.*ZETA3 - 55./24.)*QCD::C_F + (10.*ZETA2/9.-7.*ZETA3/3.-209./108.)*QCD::C_A )*nf
	   - nf*nf*1./27. )*QCD::C_F/4./M_PI/M_PI/M_PI;
    D2 = QCD::C_F * ( QCD::C_A * (176.*ZETA2/3. + 56.*ZETA3 - 1616./27.) + nf*(224./27.-32.*ZETA2/3.) )/16./M_PI/M_PI;
    g01 = QCD::C_F*(4.*ZETA2-4.+2.*gamma_E*gamma_E + (4.*gamma_E-3.)*log(muF_q_ratio))/M_PI;
    g02 = ( QCD::C_F * ( 511./4. - 198.*ZETA2 - 60.*ZETA3 + 552.*ZETA2*ZETA2/5. + 128.*gamma_E*gamma_E*(ZETA2-1.+gamma_E*gamma_E/4.) )
	    + QCD::C_A * ( -1535./12. + 376.*ZETA2/3. + 604.*ZETA3/9. - 92.*ZETA2*ZETA2/5. + 1616.*gamma_E/27.
			   - 56.*gamma_E*ZETA3 + gamma_E*gamma_E* (536./9. - 16.*ZETA2 + 176.*gamma_E/9.) )
	    + nf * ( 127./6. - 64.*ZETA2/3. + 8.*ZETA3/9. - gamma_E*(224./27.+gamma_E*(80.+32.*gamma_E)/9.) )
	    + 4.*SQR(log(muF_q_ratio)) * ( QCD::C_F * (32.*gamma_E*gamma_E - 48.*gamma_E +18.)
					   + QCD::C_A * (44.*gamma_E/3.-11.)
					   + nf * (2.-8.*gamma_E/3.))
	    - 2.*log(muF_q_ratio) * ( QCD::C_F * (48.*ZETA3 + 72.*ZETA2 -93. -128.*gamma_E*ZETA2 +128.*gamma_E
						  + 48.*gamma_E*gamma_E -64.*gamma_E*gamma_E*gamma_E)
				       + QCD::C_A * (193./3. -24.*ZETA3 -88.*ZETA2/3. +16.*gamma_E*ZETA2 -536*gamma_E/9. -88.*gamma_E*gamma_E/3.)
				       + nf * (16.*ZETA2/3. -34./3. +80.*gamma_E/9. +16.*gamma_E*gamma_E/3.))
	    )*QCD::C_F/16./M_PI/M_PI  - b0*g01*2.*log(muF_q_ratio/muR_q_ratio);
    return 1;
  }
  int InitFromVtot() {
    Init(vtot::GetS(),vtot::GetAlphaQCD(),vtot::GetFactScaleRatio(),vtot::GetRenormScaleRatio(),vtot::GetNf(),vtot::GetCollider());
    return 1;
  }
  int InitFromVrap() {
    Init(vrap::GetS(),vrap::GetAlphaQCD(),vrap::GetFactScaleRatio(),vrap::GetRenormScaleRatio(),vrap::GetNf(),vrap::GetCollider());
    return 1;
  }
  // log_order:
  //    0: LL
  //    1: NLL
  //    2: NNLL
  int SetLogOrder(unsigned int log_order) {
    if(log_order > 2) {
      LL_order = 2;
      cerr << "Next^" << log_order << " Leading Log approximation order too large. Set to maximum value NNLL." << endl;
    } else {
      LL_order = log_order;
    }
    return 1;
  }
  // match_order:
  //    0: LO
  //    1: NLO
  //    2: NNLO
  int SetMatchOrder(unsigned int match_order) {
    if(match_order > 2) {
      matching_order = 2;
      cerr << "Matching with Next^" << match_order << " Leading Order not implemented. Set to maximum value NNLO." << endl;
    } else {
      matching_order = match_order;
    }
    return 1;
  }

  int Set_x(double x) {
    q = sqrt( s*x );
    mur = q*mur_rat;
    muf = q*muf_rat;
    cheb::init(muf,coll_res);
    return 1;
  }

  int DontUseApproxPDFsForBorelPrescription(bool use) {
    not_approx_pdf_borel = use;
    return 1;
  }
  int DontUseApproxPDFsForMinimalPrescription(bool use) {
    not_approx_pdf_minimal = use;
    return 1;
  }


};






////////////////////////////////////
//  PUBLIC  FUNCTIONS             //
////////////////////////////////////

// choose to use the luminosity by Becher, Neubert, Xu
// eq. (4.44) of Bonvini, Forte, Ridolfi NPB 847 (2011) 93-159, arXiv:1009.5691 [hep-ph]
// only applicable to rapidity distributions
int resumm::SetBNXluminosity(bool bnx) {
  BNX = bnx;
  cout << "Using BNX luminosity for Borel prescription: " << (BNX ? "TRUE" : "FALSE") << endl;
  return 0;
}

// Borel type: 0= log(1-z), 1= log\frac{(1-z)}{\sqrt{z}}, 2= log(log(1/z))
int resumm::SetBorelType(int type) {
  if(type == 0) borel_type = 0;
  else if(type == 1) borel_type = 1;
  else if(type == 2) borel_type = 2;
  else {
    cerr << "No corresponding type for " << type << ". Set to default 0." << endl;
    borel_type = 0;
  }
  return 0;
}

// 
int resumm::SetAddConstants(bool add) {
  borel_const = add;
  cout << "Using Borel prescription " << (add ? "WITH" : "WITHOUT") << " constants added." << endl;
  return 0;
}




// for total cross-section
double resumm::Borel_tot(double x, double C, unsigned int log_order, unsigned int match_order, unsigned int N_cheb) {
  //init_res(vtot::GetS(),x,vtot::GetFactScaleRatio(),vtot::GetRenormScaleRatio(),vtot::GetCollider());
  //InitFromVtot();
  SetLogOrder(log_order);
  SetMatchOrder(match_order);
  Set_x(x);

  if(not_approx_pdf_borel) {
    extern_approx = PDF::IsApproximatePDFs();
    PDF::UseApproximatePDFs(false);
  }

  gsl_error_handler_t *old_handler = gsl_set_error_handler (NULL);
  gsl_set_error_handler_off();

  luminosity_in_x = cheb::Lum(x);

  if(borel_type == 2) {
    //*
    n_max_cheb_borel = N_cheb;
    coeff_cheb_borel = new double[n_max_cheb_borel+1];
    cheb::cheb_approx_borel_log1z(x,coeff_cheb_borel,n_max_cheb_borel);
    /*/
    double *coeff_cheb_borel_tmp = new double[N_cheb+1];
    cheb::cheb_approx_borel(x,coeff_cheb_borel_tmp,N_cheb);
    n_max_cheb_borel = N_cheb+1;
    coeff_cheb_borel = new double[n_max_cheb_borel+1];
    for (int j=0; j<=n_max_cheb_borel; j++) {
      double sum = 0.;
      for (int p=j-1; p<n_max_cheb_borel; p++) {
	if(p<0) continue;
	sum += coeff_cheb_borel_tmp[p] * gsl_sf_choose(p+1,j);
      }
      coeff_cheb_borel[j] = sum * pow(-1.,j);
      //cout << endl << "  j="<<j<<"  :  "<< coeff_cheb_borel[j];
    }
    */
  } else {
    n_max_cheb_borel = N_cheb;
    coeff_cheb_borel = new double[n_max_cheb_borel+1];
    cheb::cheb_approx_borel(x,coeff_cheb_borel,n_max_cheb_borel);
  }

  double result = Borel_polar(x,C);
  delete coeff_cheb_borel;

  gsl_set_error_handler (old_handler);

  if(not_approx_pdf_borel) {
    PDF::UseApproximatePDFs(extern_approx);
  }

  return result * vtot::DY_prefactor();
}

double resumm::Minimal_tot(double x, unsigned int log_order, unsigned int match_order,
			   unsigned int N_cheb, int method, double beta, double gamma) {
  //init_res(vtot::GetS(),x,vtot::GetFactScaleRatio(),vtot::GetRenormScaleRatio(),vtot::GetCollider());
  //InitFromVtot();
  SetLogOrder(log_order);
  SetMatchOrder(match_order);
  Set_x(x);

  if(not_approx_pdf_minimal) {
    extern_approx = PDF::IsApproximatePDFs();
    PDF::UseApproximatePDFs(false);
  }

  beta_lum = beta;
  gamma_lum = gamma;
  method_cheb_lum = method + 2;
  if(method_cheb_lum == 3) beta_lum = 1;
  c_mp = beta_lum + 4.;
  if(c_mp >= exp(1./alphabar)) {
    c_mp = ( beta_lum + exp(1./alphabar) )/2.;
    if(c_mp >= exp(1./alphabar)) {
      cerr << "Landau pole N_L = " << exp(1./alphabar) << " to the left of the rightmost singularity: " << beta_lum << endl;
      exit(-13);
    }
  }

  gsl_error_handler_t *old_handler = gsl_set_error_handler (NULL);
  gsl_set_error_handler_off();

  n_max_cheb_lum = N_cheb;
  coeff_cheb_lum = new double[n_max_cheb_lum+1];
  if(method_cheb_lum == 2)
    cheb::cheb_approx_luminosity(coeff_cheb_lum,n_max_cheb_lum,beta_lum,gamma_lum);
  else if(method_cheb_lum == 3)
    cheb::cheb_approx_luminosity_log(1e-6,coeff_cheb_lum,n_max_cheb_lum);
  else {
    cerr << "Non existent method for luminosity Chebyshev approximation." << endl;
    exit(-12);
  }

  double result = x_Minimal(x);
  delete coeff_cheb_lum;

  gsl_set_error_handler (old_handler);

  if(not_approx_pdf_minimal) {
    PDF::UseApproximatePDFs(extern_approx);
  }

  return result * vtot::DY_prefactor();

}

// for rapidity distribution
double resumm::Borel_rap(double Y, double x, double C, unsigned int log_order, unsigned int match_order, unsigned int N_cheb) {
  //init_res(vrap::GetS(),x,vrap::GetFactScaleRatio(),vrap::GetRenormScaleRatio(),vrap::GetCollider());
  //InitFromVrap();
  SetLogOrder(log_order);
  SetMatchOrder(match_order);
  Set_x(x);

  if(not_approx_pdf_borel) {
    extern_approx = PDF::IsApproximatePDFs();
    PDF::UseApproximatePDFs(false);
  }

  if(borel_type == 2) {
    cerr << "Not yet implemented BP with log(1/z) for rapidity distributions" << endl;
    exit(104);
  }

  double x1=sqrt(x)*exp(Y), x2=sqrt(x)*exp(-Y);
  luminosity_in_x = lumi::qqbar_lumi(x1,x2,muf,DY,vrap::GetCollider());

  n_max_cheb_borel = N_cheb;
  coeff_cheb_borel = new double[n_max_cheb_borel+1];
  double result = 0.;

  gsl_error_handler_t *old_handler = gsl_set_error_handler (NULL);
  gsl_set_error_handler_off();
  if(BNX) {
    cheb::cheb_approx_borel_rap_BNX( 1,Y,x,coeff_cheb_borel,n_max_cheb_borel);
    result = Borel_polar(sqrt(x)*exp(Y),C);
    cheb::cheb_approx_borel_rap_BNX(-1,Y,x,coeff_cheb_borel,n_max_cheb_borel);
    result += Borel_polar(sqrt(x)*exp(-Y),C);
    result /= 2.;
  } else {
    cheb::cheb_approx_borel_rap(Y,x,coeff_cheb_borel,n_max_cheb_borel);
    result = Borel_polar(x*exp(2*ABS(Y)),C);
  }
  gsl_set_error_handler (old_handler);
  delete coeff_cheb_borel;

  if(not_approx_pdf_borel) {
    PDF::UseApproximatePDFs(extern_approx);
  }

  return result * vrap::DY_prefactor();
}

double resumm::Minimal_rap(double Y, double x, unsigned int log_order, unsigned int match_order,
			   unsigned int N_cheb, int method, double beta, double gamma) {
  //init_res(vrap::GetS(),x,vrap::GetFactScaleRatio(),vrap::GetRenormScaleRatio(),vrap::GetCollider());
  //InitFromVrap();
  SetLogOrder(log_order);
  SetMatchOrder(match_order);
  Set_x(x);

  if(not_approx_pdf_minimal) {
    extern_approx = PDF::IsApproximatePDFs();
    PDF::UseApproximatePDFs(false);
  }

  beta_lum = beta;
  gamma_lum = gamma;
  method_cheb_lum = method;
  if(method_cheb_lum == 1) beta_lum = 1;
  else if(method_cheb_lum == 0) {
    if(!isINT(gamma_lum)) {
      cerr << "You can't use method 0 with gamma not integer yet, because the incomplete Beta function is not completely implemented." << endl;
      exit(-777);
    }
  }

  c_mp = beta_lum + 4.;
  if(c_mp >= exp(1./alphabar)) {
    c_mp = ( beta_lum + exp(1./alphabar) )/2.;
    if(c_mp >= exp(1./alphabar)) {
      cerr << "Landau pole N_L = " << exp(1./alphabar) << " to the left of the rightmost singularity: " << beta_lum << endl;
      exit(-13);
    }
  }

  n_max_cheb_lum = N_cheb;
  coeff_cheb_lum = new double[n_max_cheb_lum+1];
  double result = 0.;
  gsl_error_handler_t *old_handler = gsl_set_error_handler (NULL);
  gsl_set_error_handler_off();

  if(method_cheb_lum == 0)
    cheb::cheb_approx_luminosity_rap(Y,coeff_cheb_lum,n_max_cheb_lum,beta_lum,gamma_lum);
  else if(method_cheb_lum == 1)
    cheb::cheb_approx_luminosity_rap_log(Y,1e-6,coeff_cheb_lum,n_max_cheb_lum);
  else {
    cerr << "Non existent method for luminosity Chebyshev approximation." << endl;
    exit(-12);
  }
  //for(int ii=0; ii<=n_max_cheb_lum; ii++) cout << coeff_cheb_lum[ii] << endl;
  result = rap_Minimal(Y,x);
  
  gsl_set_error_handler (old_handler);
  delete coeff_cheb_lum;

  if(not_approx_pdf_minimal) {
    PDF::UseApproximatePDFs(extern_approx);
  }

  return result * vrap::DY_prefactor();

}
