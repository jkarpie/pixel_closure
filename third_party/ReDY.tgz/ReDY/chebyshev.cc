#include "chebyshev.hh"
#include "math/gauss_integration.hh"
#include <gsl/gsl_math.h>
#include <gsl/gsl_chebyshev.h>
#include <gsl/gsl_sf.h>


using namespace std;


namespace cheb {

  int **Tnk, NTused=0;
  double beta_lum=5., gamma_lum=6.;
  double global_x;
  int global_pm;
  collider coll;
  double muF;

  // ** Luminosity functions: interface with Vlumifns.hh

  // for total cross-section
  double xLum_integrand(double z, void* p) {
    double x = *(double *) p;
    return x*lumi::qqbar_lumi(z,x/z,muF,DY,coll)/z;
  }
  double Lum(double x) {
    double precision = 1e-4;
    return integration::dgauss2(xLum_integrand,x,1.,precision,x)/x;
  }
  double Lum_manipulated(double z, void *p) {
    return Lum(z) * pow(1-z,-gamma_lum) * pow(z,beta_lum);
  }
  double Lum_log(double x, void *p) {
    double z = exp(x);
    return Lum(z) * z;
  }
  double Lum_plus(double z, void *p) {
    double x = *(double *) p;
    return (Lum(x/z)/z-Lum(x))/(1.-z);
  }
  double Lum_plus_log1z(double t, void *p) {
    double x = *(double *) p;
    // z = e^-t
    return (Lum(x*exp(t))*exp(t)-Lum(x))/t;
  }

  // for rapidity distribution
  double Lum_rap_manipulated(double z, void *p) {
    double Y = *(double *) p; // hadronic rapidity
    double x1 = sqrt(z)*exp(Y), x2 = sqrt(z)*exp(-Y);
    return lumi::qqbar_lumi(x1,x2,muF,DY,coll) * pow(exp(-2.*ABS(Y))-z,-gamma_lum) * pow(z,beta_lum);
  }
  double Lum_rap_log(double x, void *p) {
    double Y = *(double *) p; // hadronic rapidity
    double z = exp(-2.*ABS(Y))*exp(x);
    double x1 = sqrt(z)*exp(Y), x2 = sqrt(z)*exp(-Y);
    return lumi::qqbar_lumi(x1,x2,muF,DY,coll)*z;
  }
  double Lum_rap_plus(double z, void *p) {
    double Y = *(double *) p; // hadronic rapidity
    double x = global_x;
    double x1 = sqrt(x/z)*exp(Y), x2 = sqrt(x/z)*exp(-Y);
    double x10 = sqrt(x)*exp(Y), x20 = sqrt(x)*exp(-Y);
    return (lumi::qqbar_lumi(x1,x2,muF,DY,coll)/z - lumi::qqbar_lumi(x10,x20,muF,DY,coll))/(1.-z);
  }
  double Lum_rap_plus_BNX(double z, void *p) {
    double Y = *(double *) p; // hadronic rapidity
    double x = global_x;
    double x1=0., x2=0.;
    if(global_pm == 1) {
      x1 = sqrt(x)*exp(Y)/z; x2 = sqrt(x)*exp(-Y);
    } else if(global_pm == -1) {
      x1 = sqrt(x)*exp(Y); x2 = sqrt(x)*exp(-Y)/z;
    }
    double x10 = sqrt(x)*exp(Y), x20 = sqrt(x)*exp(-Y);
    return (lumi::qqbar_lumi(x1,x2,muF,DY,coll)/z - lumi::qqbar_lumi(x10,x20,muF,DY,coll))/(1.-z);
  }


  // coefficients T_nk of Chebyshev expansion
  int T(int n, int k){
    int value=1;
    if(k>n || n<0 || k<0) {
      value = 0;
      //cerr << "Wrong values of (n,k) in T_{n,k}; possible problems are: n<0, k<0, k>n." << endl;
      //exit(0);
    } else if(((n-k)%2)==1) {
      value = 0;
    } else if(n>0) {
      if(k==0) {
	value= -Tnk[n-2][k];
      } else if(k==n && n!=1) {
	value = 2*Tnk[n-1][k-1];
      } else if(k<n) {
	value = 2*Tnk[n-1][k-1]-Tnk[n-2][k];
      }
    }
    return value;
  }

  double ctilde(double *c, int k, int N) {
    double value=0;
    for(int n=k; n<=N; n++){
      value += c[n]*Tnk[n][k];
    }
    if(k==0) value -= 0.5*c[0];
    //if(k==N) value -= 0.5*c[N];  // TEST!!!!
    return value;
  }
  
  double chat(double *c, int p, int N, double zmax) {
    double value=0;
    for(int k=p; k<=N; k++){
      value += pow(-1.,k-p)*c[k]*gsl_sf_choose(k,p);
    }
    return value*pow(2./zmax,p);
  }
  double bp(double *c, int p, int N, double A) {
    double value=0;
    for(int k=p; k<=N; k++){
      value += c[k]*gsl_sf_choose(k,p);
    }
    return value*pow(-A,p);
  }
  double bp_log1z(double *c, int p, int N, double A) {
    double value=0;
    for(int k=p; k<=N; k++){
      value += c[k]*gsl_sf_choose(k,p)*pow(-1.,k);
    }
    return value*pow(-A,p);
  }
  double cbar(double *c, int p, int N, double M) {
    double value=0;
    for(int k=p; k<=N; k++){
      value += (c[k]*gsl_sf_fact(k))/gsl_sf_fact(k-p);
    }
    return value*pow(-2./M,p);
  }


  // this function computes coefficients T[n][k] up to n=N
  int initT(unsigned int N){
    Tnk = new int*[N+1];
    for(unsigned int n=0; n<=N; n++) {
      Tnk[n]= new int[N+1];
      for(unsigned int k=0; k<=N; k++) {
	Tnk[n][k]=T(n,k);
      }
    }
    return 1;
  }



};


// init function
int cheb::init(double mu, collider c) {
  muF = mu;
  coll = c;
  return 1;
}



//////////////////////////////
// for TOTAL cross-section  //
//////////////////////////////
int cheb::cheb_approx_luminosity(double *coeff_lum, unsigned int N_lum, double beta, double gamma) {
  initT(N_lum);
  beta_lum = beta;
  gamma_lum = gamma;

  gsl_cheb_series *cs_lum = gsl_cheb_alloc (N_lum); 
  gsl_function F;
  double *coeff_lum_tmp, *coeff_tilde_lum;
  F.function = Lum_manipulated;

  coeff_lum_tmp = new double[N_lum+1];
  coeff_tilde_lum = new double[N_lum+1];
  gsl_cheb_init (cs_lum, &F, 0., 1.);
  for(unsigned int k=0; k<=N_lum; k++) {
    coeff_lum_tmp[k] = cs_lum->c[k];
  }
  for(unsigned int k=0; k<=N_lum; k++) {
    coeff_tilde_lum[k] = ctilde(coeff_lum_tmp,k,N_lum);
  }
  for(unsigned int k=0; k<=N_lum; k++) {
    coeff_lum[k] = chat(coeff_tilde_lum,k,N_lum,1.);
  }
  gsl_cheb_free (cs_lum);

  return 1;
}
int cheb::cheb_approx_luminosity_log(double z_min, double *coeff_lum, unsigned int N_lum) {
  initT(N_lum);

  gsl_cheb_series *cs_lum = gsl_cheb_alloc (N_lum); 
  gsl_function F;
  double *coeff_lum_tmp, *coeff_tilde_lum;
  F.function = Lum_log;

  double M=-log(z_min);
  coeff_lum_tmp = new double[N_lum+1];
  coeff_tilde_lum = new double[N_lum+1];
  gsl_cheb_init (cs_lum, &F, -M, 0.);
  for(unsigned int k=0; k<=N_lum; k++) {
    coeff_lum_tmp[k] = cs_lum->c[k];
  }
  for(unsigned int k=0; k<=N_lum; k++) {
    coeff_tilde_lum[k] = ctilde(coeff_lum_tmp,k,N_lum);
  }
  for(unsigned int k=0; k<=N_lum; k++) {
    coeff_lum[k] = cbar(coeff_tilde_lum,k,N_lum,M);
  }
  gsl_cheb_free (cs_lum);

  return 1;
}

int cheb::cheb_approx_borel(double x, double *coeff_borel, unsigned int N_plus) {
  initT(N_plus);
  gsl_cheb_series *cs_plus = gsl_cheb_alloc (N_plus); 
  gsl_function F;
  double *coeff_plus, *coeff_tilde_plus, A;
  F.function = Lum_plus;
  F.params = &x;

  coeff_plus = new double[N_plus+1];
  coeff_tilde_plus = new double[N_plus+1];
  A = 2./(1.-x);
  gsl_cheb_init (cs_plus, &F, x, 1.);
  for(unsigned int i=0; i<=N_plus; i++){
    coeff_plus[i] = cs_plus->c[i];
  }
  for(unsigned int i=0; i<=N_plus; i++){
    coeff_tilde_plus[i] = ctilde(coeff_plus,i,N_plus);
  }
  for(unsigned int i=0; i<=N_plus; i++){
    coeff_borel[i] = bp(coeff_tilde_plus,i,N_plus,A);
  }
  gsl_cheb_free (cs_plus);

  return 1;
}

int cheb::cheb_approx_borel_log1z(double x, double *coeff_borel, unsigned int N_plus) {
  initT(N_plus);
  gsl_cheb_series *cs_plus = gsl_cheb_alloc (N_plus); 
  gsl_function F;
  double *coeff_plus, *coeff_tilde_plus, A;
  F.function = Lum_plus_log1z;
  F.params = &x;

  coeff_plus = new double[N_plus+1];
  coeff_tilde_plus = new double[N_plus+1];
  double a=6, tmax=a*log(10.);
  A = 2./tmax;
  gsl_cheb_init (cs_plus, &F, 0., tmax);
  for(unsigned int i=0; i<=N_plus; i++){
    coeff_plus[i] = cs_plus->c[i];
  }
  for(unsigned int i=0; i<=N_plus; i++){
    coeff_tilde_plus[i] = ctilde(coeff_plus,i,N_plus);
  }
  for(unsigned int i=0; i<=N_plus; i++){
    coeff_borel[i] = bp_log1z(coeff_tilde_plus,i,N_plus,A);
  }
  gsl_cheb_free (cs_plus);

  return 1;
}



////////////////////////////////
// for RAPIDITY distributions //
////////////////////////////////
int cheb::cheb_approx_luminosity_rap(double Y, double *coeff_lum, unsigned int N_lum, double beta, double gamma) {
  initT(N_lum);
  beta_lum = beta;
  gamma_lum = gamma;

  gsl_cheb_series *cs_lum = gsl_cheb_alloc (N_lum); 
  gsl_function F;
  double *coeff_lum_tmp, *coeff_tilde_lum;
  F.function = Lum_rap_manipulated;
  F.params = &Y;

  coeff_lum_tmp = new double[N_lum+1];
  coeff_tilde_lum = new double[N_lum+1];
  gsl_cheb_init (cs_lum, &F, 0., exp(-2.*ABS(Y)));
  for(unsigned int k=0; k<=N_lum; k++) {
    coeff_lum_tmp[k] = cs_lum->c[k];
  }
  for(unsigned int k=0; k<=N_lum; k++) {
    coeff_tilde_lum[k] = ctilde(coeff_lum_tmp,k,N_lum);
  }
  for(unsigned int k=0; k<=N_lum; k++) {
    coeff_lum[k] = chat(coeff_tilde_lum,k,N_lum,exp(-2.*ABS(Y)));
    //cout << coeff_lum[k] << endl;
  }
  gsl_cheb_free (cs_lum);

  return 1;
}

int cheb::cheb_approx_luminosity_rap_log(double Y, double z_min, double *coeff_lum, unsigned int N_lum) {
  initT(N_lum);
  //beta_lum = beta;
  //gamma_lum = gamma;

  gsl_cheb_series *cs_lum = gsl_cheb_alloc (N_lum); 
  gsl_function F;
  double *coeff_lum_tmp, *coeff_tilde_lum;
  F.function = Lum_rap_log;
  F.params = &Y;

  double M=-log(z_min) - 2.*ABS(Y);
  coeff_lum_tmp = new double[N_lum+1];
  coeff_tilde_lum = new double[N_lum+1];
  gsl_cheb_init (cs_lum, &F, -M, 0.);
  for(unsigned int k=0; k<=N_lum; k++) {
    coeff_lum_tmp[k] = cs_lum->c[k];
  }
  for(unsigned int k=0; k<=N_lum; k++) {
    coeff_tilde_lum[k] = ctilde(coeff_lum_tmp,k,N_lum);
  }
  for(unsigned int k=0; k<=N_lum; k++) {
    coeff_lum[k] = cbar(coeff_tilde_lum,k,N_lum,M);
  }
  gsl_cheb_free (cs_lum);

  return 1;
}

int cheb::cheb_approx_borel_rap(double Y, double x, double *coeff_borel, unsigned int N_plus) {
  initT(N_plus);
  gsl_cheb_series *cs_plus = gsl_cheb_alloc (N_plus); 
  gsl_function F;
  double *coeff_plus, *coeff_tilde_plus, A;

  F.function = Lum_rap_plus;
  F.params = &Y;
  global_x = x;

  coeff_plus = new double[N_plus+1];
  coeff_tilde_plus = new double[N_plus+1];
  A = 2./(1.-x*exp(2.*ABS(Y)));
  gsl_cheb_init (cs_plus, &F, x*exp(2.*ABS(Y)), 1.);
  for(unsigned int i=0; i<=N_plus; i++){
    coeff_plus[i] = cs_plus->c[i];
  }
  for(unsigned int i=0; i<=N_plus; i++){
    coeff_tilde_plus[i] = ctilde(coeff_plus,i,N_plus);
  }
  for(unsigned int i=0; i<=N_plus; i++){
    coeff_borel[i] = bp(coeff_tilde_plus,i,N_plus,A);
  }
  gsl_cheb_free (cs_plus);

  return 1;
}


int cheb::cheb_approx_borel_rap_BNX(int pm, double Y, double x, double *coeff_borel, unsigned int N_plus) {
  initT(N_plus);
  gsl_cheb_series *cs_plus = gsl_cheb_alloc (N_plus); 
  gsl_function F;
  double *coeff_plus, *coeff_tilde_plus, A;

  F.function = Lum_rap_plus_BNX;
  F.params = &Y;
  global_x = x;
  global_pm = pm;

  coeff_plus = new double[N_plus+1];
  coeff_tilde_plus = new double[N_plus+1];
  A = 2./(1.-sqrt(x)*exp(pm*Y));
  gsl_cheb_init (cs_plus, &F, sqrt(x)*exp(pm*Y), 1.);
  for(unsigned int i=0; i<=N_plus; i++){
    coeff_plus[i] = cs_plus->c[i];
  }
  for(unsigned int i=0; i<=N_plus; i++){
    coeff_tilde_plus[i] = ctilde(coeff_plus,i,N_plus);
  }
  for(unsigned int i=0; i<=N_plus; i++){
    coeff_borel[i] = bp(coeff_tilde_plus,i,N_plus,A);
  }
  gsl_cheb_free (cs_plus);

  return 1;
}

