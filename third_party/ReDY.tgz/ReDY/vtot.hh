#ifndef __VTOT__
#define __VTOT__

#include "math/dilog.hh"
#include "math/DClasses.hh"
#include "Vlumifns.hh"  // luminosity functions required for Drell-Yan


namespace vtot {

  extern collider GetCollider();  // Get collider: pp (or LHC) or ppbar (or Tevatron)
  extern double GetECM();  // Get the hadron c.m.s. energy, sqrt(S)
  extern double GetS();  // Get the hadron c.m.s. energy squared S
  extern double GetQ();  // Final state invariant mass
  extern double Getx();  // Get the value of hadronic x = Q^2/S = (Q/E_CM)^2
  extern double GetFactScale();  // Factorization scale
  extern double GetRenormScale();  // Renormalization scale
  extern double GetFactScaleRatio();  // Factorization scale ratio wrt Q
  extern double GetRenormScaleRatio();  // Renormalization scale ratio wrt Q
  extern double GetAlphaQED();  // Get the value of alpha_QED
  extern double GetAlphaQCD();  // Get the value of alpha_QCD 
  extern int GetOrder();  // Get the order k for N^k LO computation
  extern int GetNf();  // Set number of light flavours.

  extern int SetCollider(collider c);  // Set collider: pp (or LHC) or ppbar (or Tevatron)
  extern int SetECM(double CM_energy);  // Set the hadron c.m.s. energy, sqrt(S)
  extern int SetS(double s);  // Set the hadron c.m.s. energy squared, S
  extern int SetQ(double q);  // Final state invariant mass
  extern int Setx(double x);  // Set the value of hadronic x = Q^2/S = (Q/E_CM)^2
  extern int SetScales(double mu_R, double mu_F);  // Renormalization and Factorization scales
  extern int SetScalesRatio(double muR_Q_ratio, double muF_Q_ratio);  // Renormalization and Factorization scales ratio wrt Q
  extern int SetOrder(int order);  // Set the order k for N^k LO computation
  extern int SetAlphaQED(double alpha);  // Set the value of alpha_QED (default: ~1/128 -> Z pole value)
  extern int SetAlphaQCD(double alpha);  // Set the value of alpha_QCD (default taken from PDFs at the scale mu_R)
  extern int SetNf(int nf);  // Set number of light flavours. NOTE: the function SetScale will overwrite the value set here

  // Set to TRUE to isolate NNLO contribution; if FALSE (default without calling) the full LO+NLO+NNLO is computed
  extern int SetNNLOonly(bool flag=true);

  // procedure to decide which of Z/gamma^* exchanges are being computed:
  // E could be:   gamma_only, Zgamma_interf, Z_only, Zgamma, Wplus, Wminus
  // ( Zgamma is the sum: gamma_only + Zgamma_interf + Z_only )
  extern void SetV(exchange E);


  // set flag_quiet to TRUE to suppress the output
  extern int SetQuiet(bool flag_quiet=false);

  extern double DY_prefactor(double M, double alpha);  // prefactor (alpha is alpha_QED)
  extern double DY_prefactor();  // prefactor using local values

  extern int SetSeed(int n=0); // Set seed of random number generator. Call _BEFORE_ init()

  extern int PrintInfo(); // Prints some informations about the initialization
  extern int PrintCurrentInfo(); // Prints some informations about the current computation

  // main functions: see the example sources for their usage
  extern int init(double CM_energy, collider c, exchange exch, bool flag_quiet=false);  // set flag_quiet to TRUE to suppress the output
  extern int set_variables(double x, double muR_Q_ratio=1., double muF_Q_ratio=1.);
  extern double x_distr_lo  (double x, double muR_q_ratio=1., double muF_Q_ratio=1.);
  extern double x_distr_nlo (double x, double muR_q_ratio=1., double muF_Q_ratio=1.);
  extern double x_distr_nnlo(double x, double muR_q_ratio=1., double muF_Q_ratio=1.);
  extern double x_distr_lo  ();
  extern double x_distr_nlo ();
  extern double x_distr_nnlo();
  extern double mass_integrated_cross_section_lo  (double M_min, double M_max, bool run=true);
  extern double mass_integrated_cross_section_nlo (double M_min, double M_max, bool run=true);
  extern double mass_integrated_cross_section_nnlo(double M_min, double M_max, bool run=true);
  extern DVector int_y();
  extern DVector int_y_M();


}





#endif
