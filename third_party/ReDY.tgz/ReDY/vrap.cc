/*======================================================================
 LO, NLO, NNLO rapidity distributions for 
      p p(bar) -> q qbar (q) -> (Z,gamma^*) + X,
                  q g -> (Z,gamma^*) + q + X
                  g g -> (Z,gamma^*) + X
 BOOST & REAL INTEGRANDS ARE COMBINED INTO ONE.
 ====================================================================*/

#include <iomanip>
#include <sys/time.h>
#include "QCD_EW.hh"
#include "math/dilog.hh"
#include "math/NAClasses.hh"
#include "BornNLOfns.hh"  // Born kinematics & NLO cross section fns.
#include "qbarqfns.hh"  // NNLO hard cross section fns. for q-\bar{q} channel
#include "qgfns.hh"  // NNLO hard cross section fns. for q-g channel
#include "ggfns.hh"  // NNLO hard cross section fns. for g-g channel
#include "qiqjfns.hh"  // NNLO hard cross section fns. for q_i \neq q_j channel
#include "LHAPDF_interface.hh"
#include "vrap.hh"

using namespace std;
using namespace BornNLO;
//using namespace lumi;



namespace vrap {
  double E_CM;            // hadron-hadron center-of-mass energy (sqrt(S))
  double Q, muR, muF;     // DY-mass; renormalization & factorization scales
  double muRrel, muFrel;  // global muR/Q, muF/Q (needed to do M (Q) integral)
  double tau;
  //double Born_LO_term;
  //double Born_NLO_term;
  //double Born_NNLO_term;
  double alphat;  // local value of alpha_QED(Q)
  double asR;     // local value of alpha_s(mu_R)
  bool alpha_run;
  exchange exchM; // value of "exchange" for doing M (Q) integral
  double Nf;      // Nf = number of light quarks flavors; should ~ depend on Q.
  // rapidity & integration ranges:
  double Y, y_lower, y_upper, xi_l, xi_u, ymax, Ml, Mu; 
  collider coll;
  exchange exch_particles;
  int ranseed=-1, n_points;
  int f_NNLO_only;  // fudge parameter to isolate NNLO terms
  // normally should be 1
  // Set to 0 for only the NNLO hard cross section terms
  int f_quiet = 0; // Set to 1 to suppress intermediate printing by rap_y() and by setV().

  int order_flag;

  /*=================================================================
    The overall q qbar -> DY normalization:
    The "Born-level" partonic cross section in pb is sigma_DY_0.
    It omits the quark charges, which will be supplied elsewhere.
    (Now sigma_DY_0 is factored out front of everything.)
    The "2/M" normalization gives d sigma/dM.                     */

  double sigma_DY_0(double M, double alpha){
    return GeV2pb * 2./M * 4.*PI*alpha*alpha/3./QCD::N_c /M/M ;
  }

  // Total prefactor:
  double DY_prefactor(double M, double alpha){
    return sigma_DY_0(M,alpha) * M*M/E_CM/E_CM;
  }
  double DY_prefactor(){
    return sigma_DY_0(Q,alphat) * Q*Q/E_CM/E_CM;
  }


  // set random number generator seed
  int SetSeed(int n) {
    ranseed = n;
    return 1;
  }

  int init(double CM_energy, double q, collider c, exchange exch, double muR_Q_ratio, double muF_Q_ratio, bool flag_quiet) {
    PDF::check_initialization();
    f_quiet = int(flag_quiet);

    coll = c;
    exch_particles = exch;
    E_CM = CM_energy;
    Q = q;
    tau = Q*Q/E_CM/E_CM;
    muF = Q * muF_Q_ratio;
    muR = Q * muR_Q_ratio;
    Nf = QCD::nf_of_mu(muR);  // Number of light quark flavors in hard cross section
    asR = PDF::alphas_PDF(muR)/M_PI;

    //alphat = 1./128.;   // USE FOR ALL Z/W COMPARISONS WITH FRANK!!!
    alphat = EW::alpha_em_Z;   // Z pole value
    //alphat = 1./132.1;  // Used for fxd. tgt. M=8 GeV in  hep-ph/0306192
    //alphat = EW::alpha_em;  // Zero energy value 1/137
    //alphat = EW::alpha_QED(Q);   // Dixon running QED coupling, better for low-mass

    lumi::compute_all(f_quiet);
    lumi::setV(exch_particles,Q,alphat,Nf,f_quiet);

    f_NNLO_only = 1; // Set f_NNLO_only = 0 (1)  for NNLO terms only (LO+NLO+NNLO)

    if(ranseed < 0) SetSeed(0);
    PrintInfo();
    return 1;
  }

  int PrintInfo() {
    if(f_quiet==0) {
      //cout << " enter random number seed: "; 
      //cin >> ranseed;
      //ran(-ranseed);   // initialize random number generator
      cout << " ranseed =         " << ranseed << endl; 
      cout << " E_CM =            " << E_CM << " GeV" << endl;
      cout << " collider =        " << coll << "  (1 = pp;  2 = ppbar)"  << endl; 
      cout << " alpha_s(M_Z) =    " << QCD::alphaZ << endl; 
      cout << " 1/alpha_QED =     " << 1./alphat << endl; 
      cout << " x =               " << tau << endl;
      cout << " Q =               " << Q  << " GeV" << endl
	   << " muR/Q =           " << muR/Q << endl
	   << " muF/Q =           " << muF/Q << endl; 
      cout << " Nf =              " << Nf << endl
	   << " NFf =             " << lumi::NFf(int(Nf)) << endl;
      cout << " alpha_s(muR)/Pi = " << asR << endl; 
      cout << " DY prefactor =    " << DY_prefactor(Q,alphat) << endl;
    }
    return 1;
  }


  double rap_distr_lo(double y) {
    order_flag = 0;
    Y = y;
    DVector cross_section = rap_y();
    return cross_section[0];
  }
  double rap_distr_nlo(double y) {
    order_flag = 1;
    Y = y;
    DVector cross_section = rap_y();
    return cross_section[0];
  }
  double rap_distr_nnlo(double y) {
    order_flag = 2;
    Y = y;
    DVector cross_section = rap_y();
    return cross_section[0];
  }
  double rap_integrated_lo(double Y_min, double Y_max) {
    double xi_l = 0.5 * (1. + tanh(Y_min));
    double xi_u = 0.5 * (1. + tanh(Y_max));
    order_flag = 0;
    DVector LO_int_y = vrap::int_y(xi_l, xi_u);
    return LO_int_y[0];
  }
  double rap_integrated_nlo(double Y_min, double Y_max) {
    double xi_l = 0.5 * (1. + tanh(Y_min));
    double xi_u = 0.5 * (1. + tanh(Y_max));
    order_flag = 1;
    DVector NLO_int_y = int_y(xi_l, xi_u);
    return NLO_int_y[0];
  }
  double rap_integrated_nnlo(double Y_min, double Y_max) {
    double xi_l = 0.5 * (1. + tanh(Y_min));
    double xi_u = 0.5 * (1. + tanh(Y_max));
    order_flag = 2;
    DVector NNLO_int_y = int_y(xi_l, xi_u);
    return NNLO_int_y[0];
  }
  double mass_integrated_rap_distr_lo(double y, double M_min, double M_max, bool run) {
    order_flag = 0;
    alpha_run = run;
    exchM = exch_particles;
    Y = y;
    Ml = M_min;
    Mu = M_max;
    DVector cross_section = rap_y_M();
    return cross_section[0];
  }
  double mass_integrated_rap_distr_nlo(double y, double M_min, double M_max, bool run) {
    order_flag = 1;
    alpha_run = run;
    exchM = exch_particles;
    Y = y;
    Ml = M_min;
    Mu = M_max;
    DVector cross_section = rap_y_M();
    return cross_section[0];
  }
  double mass_integrated_rap_distr_nnlo(double y, double M_min, double M_max, bool run) {
    order_flag = 2;
    alpha_run = run;
    exchM = exch_particles;
    Y = y;
    Ml = M_min;
    Mu = M_max;
    DVector cross_section = rap_y_M();
    return cross_section[0];
  }


  int SetCollider(collider c) { coll=c; return 1; }
  int SetECM(double CM_energy) { E_CM = CM_energy; return 1; }
  int SetS(double s) { E_CM = sqrt(s); return 1; }
  int SetQ(double q) {
    Q = q;
    tau = Q*Q/E_CM/E_CM;
    return 1;
  }
  int Setx(double x) {
    tau = x;
    Q = E_CM*sqrt(tau);
    return 1;
  }
  int SetY(double y) { Y=y; return 1; }
  int SetScales(double mu_R, double mu_F) {
    muR = mu_R;
    muF = mu_F;
    Nf = QCD::nf_of_mu(muR);  // Number of light quark flavors in hard cross section:
    asR = PDF::alphas_PDF(muR)/M_PI;  // ren. & fact. scales
    return 1;
  }
  int SetScalesRatio(double muR_Q_ratio, double muF_Q_ratio) {
    SetScales(Q * muR_Q_ratio, Q * muF_Q_ratio);
    return 1;
  }
  void SetV(exchange E) {
    lumi::setV(E,Q,alphat,Nf,f_quiet);
  }
  int SetOrder(int order) { order_flag=order; return 1; }
  int SetAlphaQED(double alpha) {
    alphat = alpha;
    lumi::setV(exch_particles,Q,alphat,Nf,f_quiet);
    return 1;
  }
  int SetAlphaQCD(double alpha) { asR = alpha/M_PI; return 1; }
  int SetNf(int nf) { Nf = nf; return 1; }
  int SetNNLOonly(bool flag) {
    if(flag) f_NNLO_only = 0;
    else f_NNLO_only = 1;
    return 1;
  }
  int SetQuiet(bool flag_quiet) { f_quiet=flag_quiet; return 1; }

  // Get... functions
  collider GetCollider() { return coll; }  // Get collider: pp (or LHC) or ppbar (or Tevatron)
  double GetECM() { return E_CM; }  // Get the hadron c.m.s. energy, sqrt(S)
  double GetS() { return E_CM*E_CM; }  // Get the hadron c.m.s. energy, sqrt(S)
  double GetQ() { return Q; }  // Final state invariant mass
  double Getx() { return tau; }  // Get the value of hadronic x = Q^2/S = (Q/E_CM)^2
  double GetFactScale() { return muF; }  // Factorization scale
  double GetRenormScale() { return muR; }  // Renormalization scale
  double GetFactScaleRatio() { return muF/Q; }  // Factorization scale ratio wrt Q
  double GetRenormScaleRatio() { return muR/Q; }  // Renormalization scale ratio wrt Q
  double GetAlphaQED() { return alphat; }  // Get the value of alpha_QED
  double GetAlphaQCD() { return asR*M_PI; }  // Get the value of alpha_QCD 
  int GetOrder() { return order_flag; }  // Get the order k for N^k LO computation
  int GetNf() { return int(Nf); }  // Set number of light flavours.




/*================================================================
  The full (NLO, NNLO) DY calculation, with cuts, divides up into 
  3 pieces:
  1) A Born kinematics piece (Born), with only DY in final state, and
     proportional to delta(1-z).
  2a) Two boosted Born kinematics pieces (boost), where 
      y_DY = 1/2 * ln(x1/x2) \pm ln(z),
  and
  2b) A fully smeared distribution (real), for the full DY + parton(s)
      final state.
  Here we artificially smear 2a) and add it to 2b) 
=================================================================*/


//================================================================
// The Born-type terms in the integrand.

double Born_integrand(double y) {
  //double tau = Q*Q/E_CM/E_CM;
  //double asR = QCD::alpha_s(muR)/PI;
  double x1 = sqrt(tau) * exp(y);
  double x2 = sqrt(tau) * exp(-y);
  if ((x1 >= 1.) || (x2 >= 1.)){
    cerr << "Some value is wrong, because Q/sqrt(s) * e^abs(y) > 1." << endl;
    return 0.;
  }
  double LO_term = 1.;
  double NLO_term = Born_NLO(muF/Q);
  double NNLO_term = Born_NNLO(Nf,muF/Q,muR/Q);
  double Born_term = 0.;
  if (order_flag == 0) {
    Born_term = LO_term; }
  if (order_flag == 1) {
    Born_term = LO_term + asR * NLO_term; }
  if (order_flag == 2) {
    if (f_NNLO_only == 0) Born_term = asR*asR * NNLO_term;
    else Born_term = LO_term + asR * NLO_term + asR*asR * NNLO_term;
  }
  return Born_term * lumi::qqbar_lumi(x1,x2,muF,DY,coll);
}

//================================================================
// The boost + real-type terms in the integrand.
// NLO and NNLO terms are separate routines.

/*
namespace vrap_int_NLO {
  double lumiz1, lumiz2, lumiz, lumi0, qg_lumiz1, gq_lumiz2, boost_ans,
         lumi_ys, lumi_0, lumi_1, gq_lumi_ys, qg_lumi_ys, 
         gq_lumi_1, qg_lumi_0, real_ans;
  double x1a, x2a, x1b, x2b, x1_z1, x2_z1, x1, x2, x1_0, x2_0, x1_1, x2_1;
};
*/

double int_NLO(double y, double ys, double z){
  using namespace lumi;
  double lumiz1, lumiz2, lumiz, lumi0, qg_lumiz1, gq_lumiz2, boost_ans,
         lumi_ys, lumi_0, lumi_1, gq_lumi_ys, qg_lumi_ys, 
         gq_lumi_1, qg_lumi_0, real_ans;
  //double tau = Q*Q/E_CM/E_CM;
// Boost terms in integrand:
  // for ys = 0 boost (x2 is the radiator):
  double x1a = sqrt(tau) * exp(y) ;
  double x2a = sqrt(tau) * exp(-y)/z ;
  lumiz1 = qqbar_lumi(x1a,x2a,muF,DY,coll); 
  qg_lumiz1 = qg_lumi(x1a,x2a,muF,coll);
  // for ys = 1 boost (x1 is the radiator):
  double x1b = sqrt(tau) * exp(y)/z ;
  double x2b = sqrt(tau) * exp(-y) ;
  lumiz2 = qqbar_lumi(x1b,x2b,muF,DY,coll); 
  gq_lumiz2 = gq_lumi(x1b,x2b,muF,coll); // is the same as qg_lumiz1 for gamma,Z !!MB
  lumiz = lumiz1 + lumiz2 ;
  // for z = 1 subtraction (q qbar only):
  double x1_z1 = sqrt(tau) * exp(y) ;
  double x2_z1 = sqrt(tau) * exp(-y) ;
  lumi0 = 2. * qqbar_lumi(x1_z1,x2_z1,muF,DY,coll);
  boost_ans = 
  // qqbar
      NLO_qbarq_boost(z,muF/Q) * lumiz/z
    - NLO_qbarq_boost_soft(z,muF/Q) * lumi0
  // gq + qg 
    + NLO_qg_boost(z,muF/Q) * ( gq_lumiz2 + qg_lumiz1 )/z ;
//
// Real terms in integrand:
  double x1 = sqrt(tau) * exp(y) * sqrt((z+(1.-z)*ys)/z/(1.-(1.-z)*ys)) ;
  double x2 = tau/x1/z ;
  lumi_ys = qqbar_lumi(x1,x2,muF,DY,coll); 
  qg_lumi_ys = qg_lumi(x1,x2,muF,coll);
  gq_lumi_ys = gq_lumi(x1,x2,muF,coll);
  // for ys = 0 subtraction:
  double x1_0 = sqrt(tau) * exp(y) ;
  double x2_0 = tau/x1_0/z ;
  lumi_0 = qqbar_lumi(x1_0,x2_0,muF,DY,coll); 
  qg_lumi_0 = qg_lumi(x1_0,x2_0,muF,coll);
  // for ys = 1 subtraction:
  double x1_1 = sqrt(tau) * exp(y)/z ;
  double x2_1 = tau/x1_1/z ;
  lumi_1 = qqbar_lumi(x1_1,x2_1,muF,DY,coll); 
  gq_lumi_1 = gq_lumi(x1_1,x2_1,muF,coll);
  //
  real_ans = 
      // qqbar
        NLO_qbarq_real(ys,z) * lumi_ys
      - NLO_qbarq_real_soft(ys,z) * lumi_0
      - NLO_qbarq_real_soft(1.-ys,z) * lumi_1
     // qg + gq
      + NLO_qg_real(1.-ys,z) * gq_lumi_ys 
      - NLO_qg_real_soft(1.-ys,z) * gq_lumi_1
      + NLO_qg_real(ys,z) * qg_lumi_ys
      - NLO_qg_real_soft(ys,z) * qg_lumi_0 ;
  real_ans = real_ans/z ;
  return boost_ans + real_ans;
}

double int_NNLO(double y, double ys, double z){
  using namespace lumi;
  double lumiz1, lumiz2, lumiz, lumi0, qg_lumiz1, gq_lumiz2, 
    qq_11_lumiz1, qq_22_lumiz2, qq_CE1_lumiz1, qq_CE2_lumiz2, boost_ans,
    lumi_ys, lumi_0, lumi_1, lumi_z1, 
    qbarq_BC_lumi_ys, qbarq_NFf_lumi_ys, qbarq_ax_lumi_ys,
    qg_lumi_ys, qg_lumi_0, gq_lumi_ys, gq_lumi_1, gg_lumi_ys,
    qq_11_lumi_ys, qq_11_lumi_0, qq_22_lumi_ys, qq_22_lumi_1,
    qq_12_lumi_ys, qq_12_ax_lumi_ys, 
    qq_CE1_lumi_ys, qq_CE2_lumi_ys, qq_CF_lumi_ys, 
    qq_CE1_lumi_0, qq_CE2_lumi_1, real_ans;
  if ((ys < 1.0e-08) || (ys > 1.0-1.0e-08) || (z > 1.0-1.0e-08)){ return 0.; }
  //double tau = Q*Q/E_CM/E_CM;
  if ((tau * exp(2.*y) >= 1.) || (tau * exp(-2.*y) >= 1.)
                                 || (z <= tau)){ return 0.; } 
// Boost terms in integrand:
  // for ys = 0 boost (x2 is the radiator):
  double x1a = sqrt(tau) * exp(y) ;
  double x2a = sqrt(tau) * exp(-y)/z ;
  lumiz1 = qqbar_lumi(x1a,x2a,muF,DY,coll); 
  qg_lumiz1 = qg_lumi(x1a,x2a,muF,coll); 
  qq_11_lumiz1 = qq_11_lumi(x1a,x2a,muF,coll);
  qq_CE1_lumiz1 = qq_CE1_lumi(x1a,x2a,muF,coll);
  // for ys = 1 boost (x1 is the radiator):
  double x1b = sqrt(tau) * exp(y)/z ;
  double x2b = sqrt(tau) * exp(-y) ;
  lumiz2 = qqbar_lumi(x1b,x2b,muF,DY,coll); 
  gq_lumiz2 = gq_lumi(x1b,x2b,muF,coll);
  qq_22_lumiz2 = qq_22_lumi(x1b,x2b,muF,coll); 
  qq_CE2_lumiz2 = qq_CE2_lumi(x1b,x2b,muF,coll);
  lumiz = lumiz1 + lumiz2 ;
  // for z = 1 subtraction (q qbar only):
  double x1_z_1 = sqrt(tau) * exp(y) ;
  double x2_z_1 = sqrt(tau) * exp(-y) ;
  lumi0 = 2. * qqbar_lumi(x1_z_1,x2_z_1,muF,DY,coll);
  boost_ans = 
     ( qbarq_boost_soft(z,Nf,muF/Q,muR/Q) + qbarq_boost_hard(z,Nf,muF/Q,muR/Q)
       // removed to q_iq_j channel:
       - qq11_boost_tot(z,1.) )  * lumiz/z 
    - qbarq_boost_soft(z,Nf,muF/Q,muR/Q) * lumi0 
    + qg_boost_tot(z,Nf,muF/Q,muR/Q) * ( qg_lumiz1/z + gq_lumiz2/z )  
    + qq11_boost_tot(z,muF/Q) * ( qq_11_lumiz1/z + qq_22_lumiz2/z )
    + qq_CE_boost_tot(z,muF/Q) * ( qq_CE1_lumiz1/z + qq_CE2_lumiz2/z )
    ; 
//
// Real terms in integrand:
  double x1 = sqrt(tau) * exp(y) * sqrt((z+(1.-z)*ys)/z/(1.-(1.-z)*ys)) ;
  double x2 = tau/x1/z ;
  lumi_ys = qqbar_lumi(x1,x2,muF,DY,coll); 
  qbarq_BC_lumi_ys = qqbar_BC_lumi(x1,x2,muF,coll); // BUGFIX, 11/21/2003 (LD)
  qbarq_NFf_lumi_ys = qqbar_lumi(x1,x2,muF,gluon,coll);
  qbarq_ax_lumi_ys = qqbar_ax_lumi(x1,x2,muF,coll);
  qg_lumi_ys = qg_lumi(x1,x2,muF,coll);
  gq_lumi_ys = gq_lumi(x1,x2,muF,coll);
  gg_lumi_ys = gg_lumi(x1,x2,muF,coll);
  qq_11_lumi_ys = qq_11_lumi(x1,x2,muF,coll);
  qq_22_lumi_ys = qq_22_lumi(x1,x2,muF,coll);
  qq_12_lumi_ys = qq_12_lumi(x1,x2,muF,coll);
  qq_12_ax_lumi_ys = qq_12_ax_lumi(x1,x2,muF,coll);
  qq_CE1_lumi_ys = qq_CE1_lumi(x1,x2,muF,coll);
  qq_CE2_lumi_ys = qq_CE2_lumi(x1,x2,muF,coll);
  qq_CF_lumi_ys = qq_CF_lumi(x1,x2,muF,coll);
  // for ys = 0 subtraction:
  double x1_0 = sqrt(tau) * exp(y) ;
  double x2_0 = tau/x1_0/z ;
  lumi_0 = qqbar_lumi(x1_0,x2_0,muF,DY,coll); 
  qg_lumi_0 = qg_lumi(x1_0,x2_0,muF,coll); 
  qq_11_lumi_0 = qq_11_lumi(x1_0,x2_0,muF,coll); 
  qq_CE1_lumi_0 = qq_CE1_lumi(x1_0,x2_0,muF,coll);
  // for ys = 1 subtraction:
  double x1_1 = sqrt(tau) * exp(y)/z ;
  double x2_1 = tau/x1_1/z ;
  lumi_1 = qqbar_lumi(x1_1,x2_1,muF,DY,coll); 
  gq_lumi_1 = gq_lumi(x1_1,x2_1,muF,coll); 
  qq_22_lumi_1 = qq_22_lumi(x1_1,x2_1,muF,coll); 
  qq_CE2_lumi_1 = qq_CE2_lumi(x1_1,x2_1,muF,coll);
  // for z = 1 subtraction (q qbar only):
  double x1_z1 = sqrt(tau) * exp(y) ;
  double x2_z1 = sqrt(tau) * exp(-y) ;
  lumi_z1 = qqbar_lumi(x1_z1,x2_z1,muF,DY,coll);
  //
  real_ans = 
  // q-\bar{q}:
    // 1) nonsingular terms: now includes unsubtracted soft pieces;
    //   BC terms have been removed, now have own luminosity function
    //   C^2 and C*D terms have been removed to q_i q_j channel;
    //   muF- and muR-dependence now included
      qbarq_real_hard(ys,z,Nf,muF/Q,muR/Q) * lumi_ys
    // 2) y -> 0 and y -> 1 singular subtraction terms:
    - ( qbarq_real_soft_0(ys,z,Nf,muF/Q,muR/Q)
       // removed to q_iq_j channel:
       - qq11_real_soft(ys,z,1.) ) * lumi_0
    - ( qbarq_real_soft_1(ys,z,Nf,muF/Q,muR/Q)
       // removed to q_iq_j channel:
       - qq11_real_soft(1.-ys,z,1.) ) * lumi_1
     // 3) z -> 1 singular + subtraction terms (they alone work):
    - qbarq_real_soft_z1(ys,z,Nf,muF/Q) * lumi_z1 * z
  // q\bar{q} BC terms:
    + qbarq_BC_real_hard(ys,z) * qbarq_BC_lumi_ys
  // q\bar{q} NFf terms:
    + qbarq_NFf_real_hard(ys,z) * qbarq_NFf_lumi_ys
    + qq_AB_ax_real_hard(ys,z) * qbarq_ax_lumi_ys  // extra axial term for Z
  // qg:
    + qg_real_hard(ys,z,Nf,muF/Q,muR/Q) * qg_lumi_ys
    + qg_real_hard(1.-ys,z,Nf,muF/Q,muR/Q) * gq_lumi_ys
    - qg_real_soft(ys,z,Nf,muF/Q,muR/Q) * qg_lumi_0
    - qg_real_soft(1.-ys,z,Nf,muF/Q,muR/Q) * gq_lumi_1
  // gg (only "hard" terms):
    + gg_real_hard(ys,z,muF/Q) * gg_lumi_ys
  // q_i q_j (qbar_j)   and   identical quark terms:
    + qq11_real_hard(ys,z,muF/Q) * qq_11_lumi_ys
    + qq11_real_hard(1.-ys,z,muF/Q) * qq_22_lumi_ys
    - qq11_real_soft(ys,z,muF/Q) * qq_11_lumi_0
    - qq11_real_soft(1.-ys,z,muF/Q) * qq_22_lumi_1
    + qq12_real_hard(ys,z) * qq_12_lumi_ys         // a.k.a. CD_V
    + qq_CD_ax_real_hard(ys,z) * qq_12_ax_lumi_ys  // CD_axial term, for Z
    + qq_CE_real_hard(ys,z) * qq_CE1_lumi_ys
    + qq_CE_real_hard(1.-ys,z) * qq_CE2_lumi_ys
    + qq_CF_real_hard(ys,z) * qq_CF_lumi_ys
    - qq_CE_real_soft(ys,z) * qq_CE1_lumi_0
    - qq_CE_real_soft(1.-ys,z) * qq_CE2_lumi_1
    ;
  real_ans = real_ans/z;
  // TEMPORARY DIAGNOSTICS:
  if (abs(boost_ans + real_ans) >= 0) { }
  else { cout << setw(15) << setprecision(15)
                << "  y =  " << y
                << "  ;  ys  " << ys 
                << "  ;  z =  " << z << endl; 
           cout << " boost_ans =  " << boost_ans
                << " ;   real_ans =  " << real_ans << endl;
           cout << " qq_CD_ax_real_hard(ys,z) =  " 
                << qq_CD_ax_real_hard(ys,z) 
                << " ; qq_12_ax_lumi_ys = "  << qq_12_ax_lumi_ys << endl;
           cout << " qq_AB_ax_real_hard(ys,z) =  " 
                << qq_AB_ax_real_hard(ys,z) 
                << " ; qbarq_ax_lumi_ys = " << qbarq_ax_lumi_ys << endl;
  }
  return boost_ans + real_ans;
}

/*=================================================================
 For integrating over M, we need slightly different integrands:
 We have to reset the lumi-functions for a different M,
 which also requires passing along exch,alphat 
 (we assume Nf stays constant over the integration range).  */

double Born_integrand_M(double y, double M){
  Q = M;    muR = muRrel*Q;    muF = muFrel*Q;    tau = Q*Q/E_CM/E_CM;
  if(alpha_run) {
    asR = PDF::alphas_PDF(muR)/M_PI;
    // if you want to run alpha_QED here:
    // alphat = EW::alpha_QED(Q); 
  }
  lumi::setV(exchM,M,alphat,Nf,1);
  return DY_prefactor(Q,alphat) * Born_integrand(y);
}

double int_NLO_M(double y, double ys, double z, double M){
  Q = M;    muR = muRrel*Q;    muF = muFrel*Q;    tau = Q*Q/E_CM/E_CM;
  if(alpha_run) {
    asR = PDF::alphas_PDF(muR)/M_PI;
    // if you want to run alpha_QED here:
    // alphat = EW::alpha_QED(Q); 
  }
  lumi::setV(exchM,M,alphat,Nf,1);
  return DY_prefactor(Q,alphat) * asR * int_NLO(y,ys,z);
}

double int_NNLO_M(double y, double ys, double z, double M){
  Q = M;    muR = muRrel*Q;    muF = muFrel*Q;    tau = Q*Q/E_CM/E_CM;
  if(alpha_run) {
    asR = PDF::alphas_PDF(muR)/M_PI;
    // if you want to run alpha_QED here:
    // alphat = EW::alpha_QED(Q); 
  }
  lumi::setV(exchM,M,alphat,Nf,1);
  return DY_prefactor(Q,alphat) * asR * asR  * int_NNLO(y,ys,z);
}

//============================================================
class surf: public Surface{
public:
  int n;
  surf(int m): n(m){}

  double surface(DVector & x){
    // Integrands for evaluation at fixed y:
    if (n==1){  // evaluate NLO integrand at fixed y
      return int_NLO(Y, x[1], x[2]) ; }
    if (n==2){  // evaluate NNLO integrand at fixed y
      return int_NNLO(Y, x[1], x[2]) ; }
    // Integrands for integration over a range in y:
    // introduce change of variables to do integral over y:
    // let xi = (1+tanh(y))/2,  y = ln(x/(1-x))/2.
    // Then let xi = xi_l * (1-xx) + xi_u * xx,
    // xx = (xi-xi_l)/(xi_u-xi_l),   so that xx runs from 0 to 1.
    double xi = xi_l * (1-x[1]) + xi_u * x[1] ;
    double ytemp = 0.5*log(xi/(1-xi));
    double Jy = 0.5*(xi_u-xi_l)/xi/(1.-xi);
    if (n==3) {  // integrate Born_integrand over y
      return Jy * Born_integrand(ytemp) ; }
    if (n==4) {  // integrate NLO integrand over y
      return Jy * int_NLO(ytemp, x[2], x[3]) ; }
    if (n==5) {  // integrate NNLO integrand over y
      return Jy * int_NNLO(ytemp, x[2], x[3]) ; }
    // Integrands for integration over a range in M:
    // mapping of M range containing Z pole:
    double Gamma_Z = EW::Gamma_Z; 
    double u_l = atan((Ml*Ml-MASS::mass_Z*MASS::mass_Z)/Gamma_Z/MASS::mass_Z);
    double u_u = atan((Mu*Mu-MASS::mass_Z*MASS::mass_Z)/Gamma_Z/MASS::mass_Z);
    double u = u_l + (u_u-u_l) * x[1];
    double M = sqrt(MASS::mass_Z*MASS::mass_Z + Gamma_Z*MASS::mass_Z*tan(u));
    double JM = (u_u-u_l) * Gamma_Z*MASS::mass_Z*(1.+tan(u)*tan(u))/2./M;
    // uniform mapping of M range:
    //    double M = Ml + (Mu-Ml) * x[1];   double JM = Mu-Ml; 
    if (n==6) { // integrate Born integrand over M:
      return JM * Born_integrand_M(Y,M); }
    if (n==7) { // integrate NLO integrand over M:
      return JM * int_NLO_M(Y, x[2], x[3], M) ; }
    if (n==8) { // integrate NNLO integrand over M:
      return JM * int_NNLO_M(Y, x[2], x[3], M) ; }
    else return 0;
  }

};

// "sqint" runs a VEGAS integration for function number n_f,
// over a n-dimensional unit square (hypercube), using surface "surf".
// It returns "integral, sd, chi2" as a DVector:

DVector sqint(int n_f, int n_dim, int n_call, int n_adapt, int n_run, 
              int ranseed){
  double integral, sd, chi2; 
  DVector temp_out(0,2);
  DVector x1(1,n_dim);  DVector x2(1,n_dim);
  for (int i=1; i <= n_dim; i++) {
     x1[i] = 0.;   x2[i] = 1.;
  }
  VegasGrid V(x1,x2,n_call,ranseed);  // last argument is "ranseed"
  surf Sfc(0);
  V.reset(n_call);
  Sfc.n = n_f;
  if (f_quiet==0){ cout << "adapting grid"<<endl; }
  integral = Sfc.vegas(V,n_adapt,sd,chi2);
  if (f_quiet==0){
    cout << setw(8) << setprecision(8) << integral 
	 << "  pm  " << sd << "  chi2 = " << chi2 << endl;
    cout << "evaluating integral" <<endl;
  }  
  integral = Sfc.vegasint(V,n_run,sd,chi2);
  if (f_quiet==0){  
    cout << setw(8) << setprecision(8) << integral 
	 << "  pm  " << sd << "  chi2 = " << chi2 << endl;
    cout << endl;
  }
  temp_out.fill(3,integral,sd,chi2);
  return temp_out;
}

// ========== BASIC INTEGRATION ROUTINES FOR \int dy and fixed y =======

// Routine to integrate over y, from y_lower to y_upper,
// or actually, the related variables xi_l to xi_u:

DVector int_y(double xil, double xiu){
  DVector result(0,1);
  DVector Born_int(0,2);   DVector i_NLO(0,2);   DVector i_NNLO(0,2);
  xi_l = xil;   xi_u = xiu;
  double total_int = 0., total_int_error = 0.;
  double prefactor = DY_prefactor(Q,alphat);
  //double asR = QCD::alpha_s(muR)/PI;
  if (f_quiet==0) cout  << endl << "Now computing integral over rapidity" << endl << endl;
// LO case
  if (order_flag == 0) {
    if (abs(Born_integrand(0.2)) < 1.0e-16){
      if (f_quiet==0) cout << "   Setting Born terms to 0, since f_qqbar = 0  " << endl;
      result.fill(2,0.,0.); 
    }
    else {
      if (f_quiet==0) cout << "   Now integrating Born terms " << endl;
      Born_int = sqint(3,1,1000,10,20,ranseed);
      total_int = prefactor * Born_int[0];
      total_int_error = prefactor * Born_int[1];
      if (f_quiet==0) cout << " LO integral =  " << setw(8) << setprecision(8)
			   << prefactor*Born_int[0] << "  pm  " << prefactor*Born_int[1]
			   <<  ";    chi^2 =  " << Born_int[2] << endl << endl;
    }
  }
// NLO case
  if (order_flag == 1) {
    if (abs(Born_integrand(0.2)) < 1.0e-16){
      if (f_quiet==0) cout << "   Setting Born terms to 0, since f_qqbar = 0  " << endl;
      Born_int.fill(3,0.,0.,0.);
    }
    else {
     if (f_quiet==0) cout << "   Now integrating Born terms " << endl;
     Born_int = sqint(3,1,1000,10,20,ranseed);
     if (f_quiet==0) cout << " Born-type integral =  " << setw(8) << setprecision(8)
			  << prefactor*Born_int[0] << "  pm  " << prefactor*Born_int[1]
			  <<  ";    chi^2 =  " << Born_int[2] << endl << endl;
    }
    if (abs(int_NLO(.03,.43,.93)) < 1.0e-16) {
      if (f_quiet==0) cout << "Setting non-Born NLO terms to 0, since integrand ~ 0 " << endl;
      i_NLO.fill(3,0.,0.,0.);
    }
    else {
      if (f_quiet==0) cout << " Now integrating NLO terms " << endl;
      i_NLO = sqint(4,3,10000,10,20,ranseed);
      if (f_quiet==0) cout << " NLO non-Born integral =  " << setw(8) << setprecision(8)
			   << prefactor * asR * i_NLO[0] 
			   << "  pm  " << prefactor * asR * i_NLO[1]
			   <<  ";    chi^2 =  " << i_NLO[2] << endl << endl;
    }
    total_int = prefactor * ( Born_int[0] + asR * i_NLO[0] );
    total_int_error = prefactor * sqrt( Born_int[1]*Born_int[1] 
                                      + asR*asR * i_NLO[1]*i_NLO[1] ) ;
    if (f_quiet==0) cout << " NLO integral =  " << setw(8) << setprecision(8)
			 << total_int << "  pm  " << total_int_error << endl << endl;
  }
// NNLO case
  if (order_flag == 2) {
    if (abs(Born_integrand(0.2)) < 1.0e-16){
      if (f_quiet==0) cout << "   Setting Born terms to 0, since f_qqbar = 0  " << endl;
      Born_int.fill(3,0.,0.,0.);
    }
    else {
    if (f_quiet==0) cout << " Now integrating Born terms " << endl;
    Born_int = sqint(3,1,1000,10,20,ranseed);
    if (f_quiet==0) cout << " Born-type integral =  " << setw(8) << setprecision(8)
			 << prefactor*Born_int[0] << "  pm  " << prefactor*Born_int[1]
			 <<  ";    chi^2 =  " << Born_int[2] << endl << endl;
    }
    if (f_NNLO_only == 1){
      if (abs(int_NLO(.03,.43,.93)) < 1.0e-16) {
        if (f_quiet==0) cout << "Setting NLO non-Born terms to 0, since integrand ~ 0 " << endl;
        i_NLO.fill(3,0.,0.,0.);
      }
      else {
      if (f_quiet==0) cout << " Now integrating NLO terms " << endl;
      i_NLO = sqint(4,3,5000,10,20,ranseed);
      if (f_quiet==0) cout << " NLO non-Born integral =  " << setw(8) << setprecision(8)
			   << prefactor * asR * i_NLO[0] 
			   << "  pm  " << prefactor * asR * i_NLO[1]
			   <<  ";    chi^2 =  " << i_NLO[2] << endl << endl;
      }
    }
    if (f_quiet==0) cout << "   Now integrating NNLO terms " << endl;
    i_NNLO = sqint(5,3,5000,10,30,ranseed);
    if (f_quiet==0) cout << " NNLO non-Born integral =  " << setw(8) << setprecision(8)
			 << prefactor * asR*asR * i_NNLO[0] 
			 << "  pm  " << prefactor * asR*asR * i_NNLO[1]
			 <<  ";    chi^2 =  " << i_NNLO[2] << endl 
			 << endl;
    if (f_NNLO_only == 0) {
      total_int = prefactor * ( Born_int[0] + asR*asR * i_NNLO[0] );
      total_int_error = prefactor * sqrt( Born_int[1]*Born_int[1] 
                                   + asR*asR*asR*asR * i_NNLO[1]*i_NNLO[1] ) ;
      if (f_quiet==0) cout << " NNLO (ONLY) integral =  " << setw(8) << setprecision(8)
			   << total_int << "  pm  " << total_int_error  
			   << endl << endl;
    }
    else {
    total_int = prefactor * ( Born_int[0] 
			    + asR * i_NLO[0] + asR*asR * i_NNLO[0] );
    total_int_error = prefactor * sqrt( Born_int[1]*Born_int[1] 
                            + asR*asR * i_NLO[1]*i_NLO[1]
                   + asR*asR*asR*asR * i_NNLO[1]*i_NNLO[1] ) ;
    if (f_quiet==0) cout << " NNLO integral =  " << setw(8) << setprecision(8)
			 << total_int << "  pm  " << total_int_error  
			 << endl << endl;
    }
  }
 result.fill(2,total_int,total_int_error);  
 return result;
}

// Routine computes d sigma/dM/dy, plus errors:

DVector rap_y(){
  double total = 0., total_error = 0.;
  double prefactor = DY_prefactor(Q,alphat);
  //double asR = QCD::alpha_s(muR)/PI;
  DVector result(0,1);   DVector i_NLO(0,2);  DVector i_NNLO(0,2);
  if (f_quiet==0) {
    cout << setw(9) << setprecision(9) << " working on    y =  " << Y << endl; 
  }
// LO case
  if (order_flag == 0) { 
    total = prefactor * Born_integrand(Y);
    total_error = 0.; }
// NLO case
  else if (order_flag == 1) {
    double Born_ans = Born_integrand(Y);
    if (abs(int_NLO(.03,.43,.93)) < 1.0e-16) {
       if (f_quiet==0) {
	 cout << "Setting NLO non-Born terms to 0, since integrand ~ 0 " << endl;
       }
       i_NLO.fill(3,0.,0.,0.);
    } else { 
      i_NLO = sqint(1,2,5000,10,20,ranseed);
    }
    total = prefactor * ( Born_ans + asR * i_NLO[0] );
    total_error = prefactor * asR * i_NLO[1] ;
  }
// NNLO case
  else if (order_flag == 2) {
    double Born_ans = Born_integrand(Y);
    if (f_NNLO_only == 1) {
      if (f_quiet==0) {
	cout << " computing NLO integral for y = " << Y << endl; 
      }
      if (abs(int_NLO(.03,.43,.93)) < 1.0e-16) {
	if (f_quiet==0) {
	  cout << "Setting NLO non-Born terms to 0, since integrand ~ 0 " << endl;
	}
	i_NLO.fill(3,0.,0.,0.);
      } else { 
	///////////////////////////////////////////////////
	// Start time TO BE ELIMINATED!!!!
	struct timeval t0, t1;
	gettimeofday(&t0,NULL);
	//--------------
	i_NLO = sqint(1,2,5000,10,20,ranseed);
	//--------------
	// Finish time
	gettimeofday(&t1,NULL);
	double t=t1.tv_sec-t0.tv_sec+(t1.tv_usec-t0.tv_usec)*0.000001;
	cout << "Total time: " << t << "s" << endl;
	///////////////////////////////////////////////////
      }
    }
    if (f_quiet==0) {
      cout << " computing NNLO integral for y = " << Y << endl; 
    }
    i_NNLO = sqint(2,2,20000,3,10,ranseed);
    if (f_NNLO_only == 0) {
      total = prefactor * ( Born_ans + asR*asR * i_NNLO[0] );
      total_error = prefactor * asR*asR * i_NNLO[1] ;
    }
    else {
      total = prefactor * ( Born_ans + asR * i_NLO[0] + asR*asR * i_NNLO[0] );
      total_error = prefactor * asR * sqrt( i_NLO[1]*i_NLO[1]
                                          + asR*asR * i_NNLO[1]*i_NNLO[1] );
    }
  } else {
    cout << "Invalid value for \"order_flag\" = " << order_flag << endl;
  }
  if (f_quiet==0) {
  cout << setw(8) << setprecision(8) <<  " y = " << Y 
       << ";   d^2sigma/dM/dy =  " << total
       << "   pm  " << total_error << endl;
  }
  result.fill(2,total,total_error);
  return result;
}

// ============ SCAN IN RAPIDITY y =========================

// Make table of K factors for fixed-target Drell-Yan, M vs. y.
// There are
//       M_steps evenly-spaced values of M, from M_min to M_max,
// vs.   y_steps evenly-spaced values of y, from   0   to y_max.
// For J. Stirling.
/*
void makeKtable(double y_max, int y_steps, 
                double M_min, double M_max, int M_steps){
  double yMAX;   // the physical limit for y
  f_quiet = 1;  // shut off output
  cout << endl
       << "--------------------------------------------------------" << endl; 
  cout << setw(8) << setprecision(8) << "Performing mass/rapidity scan:  " 
       << M_min << "  < M < " << M_max << "  ;   0 < y < " << y_max 
       << endl; 
 cout << "--------------------------------------------------------" << endl; 
 cout << "number of mass steps =  " << M_steps 
      << "; number of rapidity steps =  " << y_steps << endl << endl; 
  double y_step_size = y_max/y_steps;
  double M_step_size = (M_max-M_min)/M_steps;
// print header
  cout << " y =         " ;
  for (int j = 0; j <= y_steps; j++) {
    y = 0. + y_step_size * j;
    cout << y << "           " ;
  }
  cout << endl;
  cout << "---------------------------------------------" 
       << "---------------------------------------------" << endl;
//
  for (int i = 0; i <= M_steps; i++) {
    Q = M_min + M_step_size * i;
    cout << " M =  " << Q << " :    " ;
    yMAX = log(E_CM/Q);
    muF = Q;   muR = muF;  // ren. & fact. scales equal to Q here
    for (int j = 0; j <= y_steps; j++) {
      y = 0. + y_step_size * j;
      if (y < yMAX){
// LO MRST:
	order_flag = 0;  //QCD::alpha_s_Z = 0.130;  pdf_init(mrst,1);
	DVector LO_rap_y = rap_y();
// NLO MRST:
	order_flag = 1;  //QCD::alpha_s_Z = 0.119;  pdf_init(mrst,2);
	DVector NLO_rap_y = rap_y();
	cout << NLO_rap_y[0]/LO_rap_y[0] << "   " ;
      }
      else { cout <<  0.0 << "   " ; }
    }
  cout << endl;
  }
  cout << "------------------------------------------------------- " << endl;
}
*/
/* Make table of "C" factors for fixed-target Drell-Yan, M vs. y.
   There are
         M_steps evenly-spaced values of M, from M_min to M_max,
   vs.   y_steps evenly-spaced values of y, from   0   to y_max.
   "C" is defined by J. Stirling as
   sigma(NLO) = sigma (LO, but using NLO pdfs) 
                  * ( 1 + alphas(M)/pi C(M,y) )
			 Now we include errors too.   */
/*
void makeCtable(double y_max, int y_steps,
                double M_min, double M_max, int M_steps){
  double yMAX;   // the physical limit for y
  f_quiet = 1;  // shut off output
  cout << endl
       << "--------------------------------------------------------"
       << endl << "Running `makeCtable'   " << endl;
  cout << setw(8) << setprecision(8) << "Performing mass/rapidity scan:  "
       << M_min << "  < M < " << M_max << "  ;   0 < y < " << y_max
       << endl;
  cout << "--------------------------------------------------------" <<
                endl;
  cout << "number of mass steps =  " << M_steps
       << "; number of rapidity steps =  " << y_steps << endl << endl;
  double y_step_size = y_max/y_steps;
  double M_step_size = (M_max-M_min)/M_steps;
  cout <<endl<< "=========   Table of C(M,y) values  ===========" <<endl<<endl;
  for (int i = 0; i <= M_steps; i++) {
    Q = M_min + M_step_size * i;
    cout << " M = " << Q << " :" << endl 
         << "y    |        C       (   error in C    "  << endl ;
    yMAX = log(E_CM/Q);
    muF = Q;   muR = muF;  // ren. & fact. scales equal to Q here
    for (int j = 0; j <= y_steps; j++) {
      y = 0. + y_step_size * j;
      if (y < yMAX){
	// LO, but using NLO [*LO* MRST, NLO Alek.] pdfs:
	//	order_flag = 0;  alpha_s_Z = 0.130; pdf_init(mrst,2);
        order_flag = 0; pdf_init(alekhin,1); QCD::alpha_s_Z = Alekhin_alpha_s(MASS::mass_Z); 
        lumi::compute_all();
	DVector LO_rap_y = rap_y();
	// NLO, using SAME NLO [*LO* MRST, NLO Alek.] pdfs::
	//	order_flag = 1;  alpha_s_Z = 0.119; pdf_init(mrst,2);
        order_flag = 1; pdf_init(alekhin,1); QCD::alpha_s_Z = Alekhin_alpha_s(MASS::mass_Z); 
	// here we can compute only the qqbar, or only the qg, component:
        compute_qqbar();
	DVector NLO_rap_y = rap_y();
        // for qqbar:
	double Cvalue = ( NLO_rap_y[0]/LO_rap_y[0] - 1. )/ (QCD::alpha_s(Q)/PI); 
	// For qg use compute_qg() instead of lumi::compute_all(), and then this formula:
       	// double Cvalue = NLO_rap_y[0]/LO_rap_y[0]/ (alpha_s(Q)/PI);
	// 
	// error should be same regardless:
        double Cerror = sqrt( NLO_rap_y[0]*NLO_rap_y[0]
                        /LO_rap_y[0]/LO_rap_y[0]/LO_rap_y[0]/LO_rap_y[0]
                              * LO_rap_y[1]*LO_rap_y[1]
	       	  + 1./LO_rap_y[0]/LO_rap_y[0] * NLO_rap_y[1]*NLO_rap_y[1] )
	  / (QCD::alpha_s(Q)/PI) ;
        cout << y << "  |    " << Cvalue  << "   (   " << Cerror << endl ;
      }
      else { cout << y << "  |    " << 0.0  << "             (   " << 0.0 << endl ; }
    }
    cout << endl<< endl ;
  }
  cout << "------------------------------------------------------- " << endl;
}
*/
/* Make table of "D" and "E" factors for fixed-target Drell-Yan, M vs. y.
   There are
         M_steps evenly-spaced values of M, from M_min to M_max,
   vs.   y_steps evenly-spaced values of y, from   0   to y_max.
   "D" and "E" are defined as
   sigma(NNLO) = sigma (LO, but using NNLO pdfs) 
                   * ( 1 + alphas(M)/pi D(M,y) 
                         + (alphas(M)/pi)^2 * E(M,y) )
			 Now we include errors too.   */
/*
void makeDEtable(double y_max, int y_steps,
                double M_min, double M_max, int M_steps){
  double yMAX;   // the physical limit for y
  f_quiet = 1;  // shut off output
  lumi::compute_all();
  cout << endl
       << "--------------------------------------------------------" 
       << endl << "Running `makeDEtable'   " << endl;
  cout << setw(8) << setprecision(8) << "Performing mass/rapidity scan:  "
       << M_min << "  < M < " << M_max << "  ;   0 < y < " << y_max
       << endl;
  cout << "--------------------------------------------------------" <<
                endl;
  cout << "number of mass steps =  " << M_steps
       << "; number of rapidity steps =  " << y_steps << endl << endl;
  double y_step_size = y_max/y_steps;
  double M_step_size = (M_max-M_min)/M_steps;
  cout <<endl<< "=========   Table of D(M,y) values  ===========" <<endl<<endl;
  for (int i = 0; i <= M_steps; i++) {
    Q = M_min + M_step_size * i;
    cout << " M = " << Q << " :" << endl 
         << "y    |        D       (   error in D    "  << endl ;
    yMAX = log(E_CM/Q);
    muF = Q;   muR = muF;  // ren. & fact. scales equal to Q here
    for (int j = 0; j <= y_steps; j++) {
      y = 0. + y_step_size * j;
      if (y < yMAX){
	// LO, but using MRST NNLO average pdfs:
        order_flag = 0;  QCD::alpha_s_Z = 0.1155;  pdf_init(mrst,6);  
        // lumi::compute_all();
	DVector LO_rap_y = rap_y();
	// NLO, using SAME NNLO pdfs:
        order_flag = 1;  QCD::alpha_s_Z = 0.1155;  pdf_init(mrst,6);  
	// We can also compute only the qqbar, or only the qg, component.
        // For qqbar, use compute_qqbar() and same Dvalue formula.
        // lumi::compute_all();
	DVector NLO_rap_y = rap_y();
	double Dvalue = ( NLO_rap_y[0]/LO_rap_y[0] - 1. )/ (QCD::alpha_s(Q)/PI);
	// For qg use compute_qg() instead of compute_all(), and then this formula:
       	// double Dvalue = NLO_rap_y[0]/LO_rap_y[0]/ (alpha_s(Q)/PI);
	// 
	// error should be same regardless:
        double Derror = sqrt( NLO_rap_y[0]*NLO_rap_y[0]
                        /LO_rap_y[0]/LO_rap_y[0]/LO_rap_y[0]/LO_rap_y[0]
                              * LO_rap_y[1]*LO_rap_y[1]
	       	  + 1./LO_rap_y[0]/LO_rap_y[0] * NLO_rap_y[1]*NLO_rap_y[1] )
	  / (QCD::alpha_s(Q)/PI) ;
        cout << y << "  |    " << Dvalue  << "   (   " << Derror << endl ;
      }
      else { cout << y << "  |    " << 0.0  << "             (   " << 0.0 << endl ; }
    }
    cout << endl<< endl ;
  }
// print E table header
  cout <<endl<< "=========   Table of E(M,y) values  ===========" <<endl<<endl;
  for (int i = 0; i <= M_steps; i++) {
    Q = M_min + M_step_size * i;
    cout << " M = " << Q << " :" << endl 
         << "y    |        E       (   error in E    "  << endl ;
    yMAX = log(E_CM/Q);
    muF = Q;   muR = muF;  // ren. & fact. scales equal to Q here
    for (int j = 0; j <= y_steps; j++) {
      y = 0. + y_step_size * j;
      if (y < yMAX){
	// LO, but using MRST NNLO average pdfs:
        order_flag = 0;  QCD::alpha_s_Z = 0.1155;  pdf_init(mrst,6);  
        // lumi::compute_all();
	DVector LO_rap_y = rap_y();
	// NNLO, using SAME NNLO pdfs:
        order_flag = 2;  QCD::alpha_s_Z = 0.1155;  pdf_init(mrst,6);  
	// We can also compute only the qqbar, or only the qg, component.
        // For qqbar, use compute_qqbar() and same Dvalue formula.
        f_NNLO_only = 0;
        // lumi::compute_all();
	DVector NNLO_rap_y = rap_y();
	double Evalue = NNLO_rap_y[0]/LO_rap_y[0]/(QCD::alpha_s(Q)/PI)/(QCD::alpha_s(Q)/PI); 
        double Eerror = sqrt( NNLO_rap_y[0]*NNLO_rap_y[0]
                        /LO_rap_y[0]/LO_rap_y[0]/LO_rap_y[0]/LO_rap_y[0]
                              * LO_rap_y[1]*LO_rap_y[1]
	       	  + 1./LO_rap_y[0]/LO_rap_y[0] * NNLO_rap_y[1]*NNLO_rap_y[1] )
                         /(QCD::alpha_s(Q)/PI)/(QCD::alpha_s(Q)/PI) ;
        cout << y << "  |    " << Evalue  << "   (   " << Eerror << endl ;
      }
      else { cout << y << "  |    " << 0.0  << "             (   " << 0.0 << endl ; }
    }
  }
  cout << "----------------------------------------------------- " << endl;
}
*/
// Routine uses "rap_y" to compute un-normalized d sigma/dM/dy, plus errors,
// in the SYMMETRIC case, just scans from y = 0 to y = ymax,
// with a number of points equal to n_points:
// ymax is computed from E_CM and Q; then we rescale to omit the last point.
// For n_points = 19, this agrees with Frank's choice of points.
// forwrev = 1  -> print output from -ymax to +ymax
// forwrev = -1  -> print output from +ymax to -ymax

DMatrix sym_scan_rap_y(int n_points, int forwrev){
  PDF::check_initialization();
  ymax = log(E_CM/Q) * n_points/(n_points+1.);  
  cout << endl
       << "--------------------------------------------------------" << endl
       << "Performing rapidity scan - symmetric case (0 < y < ymax)" << endl
       << "--------------------------------------------------------" << endl
       << " ymax =  " << ymax << ";    number of rapidity steps =  " << n_points << endl << endl; 
  double step_size = ymax/n_points;
  DMatrix resultMatrix(0,n_points,0,2);  // matrix to store unnorm. results
  for (int j = 0; j <= n_points; j++) {
     Y = 0. + step_size * j;
  // y = -ymax + step_size * j;
     // full result:
     DVector temp_rap_y = rap_y();
     resultMatrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
   }
// print results for topdraw:
    cout << endl
         << "   y               |    d^2sigma/dM/dy   |   (  error   " << endl
	 << "------------------------------------------------------- " << endl;
    for (int j = n_points; j > 0; j--) {
      cout << setw(8) << setprecision(8) <<  " " << -forwrev*resultMatrix[j][0]
           << "       " << resultMatrix[j][1] << " "
           << "   (   " << resultMatrix[j][2] << endl;
    }
    for (int j = 0; j <= n_points; j++) {
      cout << setw(8) << setprecision(8) <<  " " << forwrev*resultMatrix[j][0]
           << "       " << resultMatrix[j][1] << " "
           << "   (   " << resultMatrix[j][2] << endl;
    }
   cout << endl ;
//
 return resultMatrix;
}

// Same as "sym_scan_rap_y", but for the ASYMMETRIC case:
// scans from y = -ymax to y = ymax.
// For n_points = 38, this agrees with Frank's choice of points.

DMatrix asym_scan_rap_y(int n_points, int forwrev){
  PDF::check_initialization();
  ymax = log(E_CM/Q) * n_points/(n_points+2.);  
  cout << endl
       << "-------------------------------------------------------------" 
       << endl; 
  cout << "Performing rapidity scan - asymmetric case (-ymax < y < ymax)" 
       << endl; 
  cout << "-------------------------------------------------------------"
       << endl; 
  double step_size = 2.*ymax/n_points;
  DMatrix resultMatrix(0,n_points,0,2);  // matrix to store unnorm. results
  for (int j = 0; j <= n_points; j++) {
     Y = - ymax + step_size * j;
     // full result:
     DVector temp_rap_y = rap_y();
     resultMatrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
  }
// print results for topdraw:
   cout << endl
        << "   y               |    d^2sigma/dM/dy   |   (  error   " << endl;
   cout << "------------------------------------------------------- " << endl;
   if (forwrev==1) {
     for (int j = 0; j <= n_points; j++) {
       cout << setw(8) << setprecision(8) <<  " " << resultMatrix[j][0]
            << "       " << resultMatrix[j][1] << " "
            << "   (   " << resultMatrix[j][2] << endl;
     }
   }
   if (forwrev==-1) {
     for (int j = n_points; j >=0; j--) {
       cout << setw(8) << setprecision(8) <<  " " << resultMatrix[j][0]
            << "       " << resultMatrix[j][1] << " "
            << "   (   " << resultMatrix[j][2] << endl;
     }
   }
   cout << endl ;
//
 return resultMatrix;
}

// Same as "sym_scan_rap_y", but does all orders -- LO, NLO, NNLO --
// for muR = muF = mu1*Q, and for muR = muF = mu2*Q,
// using MRST or Alekhin distributions.
// Prints results in format convenient for topdraw.
// pdftype must be set to either mrst or alekhin.
// For n_points = 19, agrees with Frank's choice of points.

//void sym_scan_all(pdf_type pdftype, int n_points, double mu1, double mu2) {
void sym_scan_all(int n_points, double mu1, double mu2) {
  PDF::check_initialization();
  ymax = log(E_CM/Q) * n_points/(n_points+1.);  
  cout << endl
       << "-----------------------------------------------------------" << endl;
  cout << "LO, NLO, NNLO rapidity scan - symmetric case (0 < y < ymax)" << endl;
  cout << "-----------------------------------------------------------" << endl;
  cout << " ymax =  " << ymax
       << ";    number of rapidity steps =  " << n_points << endl << endl; 
  cout << " muF_lower = muR_lower = " << mu1 << " * Q " << endl;
  cout << " muF_upper = muR_upper = " << mu2 << " * Q " << endl << endl;
  //cout << " pdf type = " << pdftype << " (2 = mrst, 3 = alekhin) " << endl << endl;
  double step_size = ymax/n_points;
  f_NNLO_only = 1;   lumi::compute_all();
//
// Do both LO curves first:
  order_flag = 0;  
  //if (pdftype==mrst) { QCD::alpha_s_Z = 0.130;  pdf_init(mrst,1); }
  //else if (pdftype==alekhin) {
  //  pdf_init(alekhin,order_flag);   QCD::alpha_s_Z = Alekhin_alpha_s(MASS::mass_Z);
  //}
  DMatrix LO1Matrix(0,n_points,0,2);
  DMatrix LO2Matrix(0,n_points,0,2);
  for (int j = 0; j <= n_points; j++) {
    Y = 0. + step_size * j;
    muF = mu1*Q;   muR = mu1*Q;
    DVector temp_rap_y = rap_y();
    LO1Matrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
//  
    muF = mu2*Q;   muR = mu2*Q;
    temp_rap_y = rap_y();
    LO2Matrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
  }
// Next do both NLO curves:
  order_flag = 1;  
  //if (pdftype==mrst) { QCD::alpha_s_Z = 0.119;  pdf_init(mrst,2); }
  //else if (pdftype==alekhin) {
  //  pdf_init(alekhin,order_flag);  QCD::alpha_s_Z = Alekhin_alpha_s(MASS::mass_Z); 
  //}
  DMatrix NLO1Matrix(0,n_points,0,2);
  DMatrix NLO2Matrix(0,n_points,0,2);
  for (int j = 0; j <= n_points; j++) {
    Y = 0. + step_size * j;
    muF = mu1*Q;   muR = mu1*Q;
    DVector temp_rap_y = rap_y();
    NLO1Matrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
//  
    muF = mu2*Q;   muR = mu2*Q;
    temp_rap_y = rap_y();
    NLO2Matrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
  }
// Finally do both NNLO curves:
  order_flag = 2;  
  //if (pdftype==mrst) { QCD::alpha_s_Z = 0.1155;  pdf_init(mrst,6); }
  //else if (pdftype==alekhin) {
  //  pdf_init(alekhin,order_flag);  QCD::alpha_s_Z = Alekhin_alpha_s(MASS::mass_Z); 
  //}
  DMatrix NNLO1Matrix(0,n_points,0,2);
  DMatrix NNLO2Matrix(0,n_points,0,2);
  for (int j = 0; j <= n_points; j++) {
     Y = 0. + step_size * j;
     muF = mu1*Q;   muR = mu1*Q;
     DVector temp_rap_y = rap_y();
     NNLO1Matrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
//  
     muF = mu2*Q;   muR = mu2*Q;
     temp_rap_y = rap_y();
     NNLO2Matrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
   }
//
// print results: 
// print LO:
  cout << endl << "set color blue" << endl << endl;
   cout << "title 0.05 10.5 data 'LO' SIZE 2.5" << endl << endl;
   cout << "( mu/Q = " << mu2 << endl;
   for (int j = n_points; j > 0; j--) {
     cout << setw(8) << setprecision(8) <<  " " << -LO2Matrix[j][0]
            << "       " << LO2Matrix[j][1] << " "
            << "   (   " << LO2Matrix[j][2] << endl;
   }
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << LO2Matrix[j][0]
            << "       " << LO2Matrix[j][1] << " "
            << "   (   " << LO2Matrix[j][2] << endl;
   }
   cout << "( mu/Q = " << mu1 << endl;
   for (int j = n_points; j > 0; j--) {
     cout << setw(8) << setprecision(8) <<  " " << LO1Matrix[j][0]
            << "       " << LO1Matrix[j][1] << " "
            << "   (   " << LO1Matrix[j][2] << endl;
   }
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << -LO1Matrix[j][0]
            << "       " << LO1Matrix[j][1] << " "
            << "   (   " << LO1Matrix[j][2] << endl;
   }
   cout << "join fill" << endl;
// print NLO:
  cout << endl << "set color green" << endl << endl;
   cout << "title 0.05 20.5 data 'NLO' SIZE 2.5" << endl << endl;
   cout << "( mu/Q = " << mu2 << endl;
   for (int j = n_points; j > 0; j--) {
     cout << setw(8) << setprecision(8) <<  " " << -NLO2Matrix[j][0]
            << "       " << NLO2Matrix[j][1] << " "
            << "   (   " << NLO2Matrix[j][2] << endl;
   }
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << NLO2Matrix[j][0]
            << "       " << NLO2Matrix[j][1] << " "
            << "   (   " << NLO2Matrix[j][2] << endl;
   }
   cout << "( mu/Q = " << mu1 << endl;
   for (int j = n_points; j > 0; j--) {
     cout << setw(8) << setprecision(8) <<  " " << NLO1Matrix[j][0]
            << "       " << NLO1Matrix[j][1] << " "
            << "   (   " << NLO1Matrix[j][2] << endl;
   }
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << -NLO1Matrix[j][0]
            << "       " << NLO1Matrix[j][1] << " "
            << "   (   " << NLO1Matrix[j][2] << endl;
   }
   cout << "join fill" << endl;
// print NNLO:
  cout << endl << "set color red" << endl << endl;
   cout << "title 0.05 25.5 data 'NNLO' SIZE 2.5" << endl << endl;
   cout << "( mu/Q = " << mu2 << endl;
   for (int j = n_points; j > 0; j--) {
     cout << setw(8) << setprecision(8) <<  " " << -NNLO2Matrix[j][0]
            << "       " << NNLO2Matrix[j][1] << " "
            << "   (   " << NNLO2Matrix[j][2] << endl;
   }
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << NNLO2Matrix[j][0]
            << "       " << NNLO2Matrix[j][1] << " "
            << "   (   " << NNLO2Matrix[j][2] << endl;
   }
   cout << "( mu/Q = " << mu1 << endl;
   for (int j = n_points; j > 0; j--) {
     cout << setw(8) << setprecision(8) <<  " " << NNLO1Matrix[j][0]
            << "       " << NNLO1Matrix[j][1] << " "
            << "   (   " << NNLO1Matrix[j][2] << endl;
   }
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << -NNLO1Matrix[j][0]
            << "       " << NNLO1Matrix[j][1] << " "
            << "   (   " << NNLO1Matrix[j][2] << endl;
   }
   cout << "join fill" << endl;
}

// Same as "sym_scan_all", but does W+/W- ratio,
// all orders -- LO, NLO, NNLO --
// for muR = muF = mu1*Q, and for muR = muF = mu2*Q,
// using MRST or Alekhin distributions.
// Prints results in format convenient for topdraw.
// pdftype must be set to either mrst or alekhin.
// For n_points = 19, agrees with Frank's choice of points.

//void Wpm_ratio_scan_all(pdf_type pdftype, int n_points, double mu1, double mu2){
void Wpm_ratio_scan_all(int n_points, double mu1, double mu2){
  PDF::check_initialization();
  ymax = log(E_CM/Q) * n_points/(n_points+1.);  
  double temp_ratio, temp_err;
  Q = MASS::mass_W;  // assumes we are on-shell...
  int f_quiet_saved = f_quiet;
  f_quiet = 1;  // turn off most output
  cout << endl
       << "-----------------------------------------------------------" << endl;
  cout << "LO, NLO, NNLO W+/W- rap. scan - sym. case (0 < y < ymax)" << endl;
  cout << "-----------------------------------------------------------" << endl;
  cout << " ymax =  " << ymax
       << ";    number of rapidity steps =  " << n_points << endl << endl; 
  cout << " muF_lower = muR_lower = " << mu1 << " * Q " << endl;
  cout << " muF_upper = muR_upper = " << mu2 << " * Q " << endl << endl;
  //cout << " pdf type = " << pdftype << " (2 = mrst, 3 = alekhin) " << endl << endl;
  double step_size = ymax/n_points; 
  f_NNLO_only = 1;   lumi::compute_all();
//
// Do both LO curves first:
  order_flag = 0;  
  //if (pdftype==mrst) { QCD::alpha_s_Z = 0.130;  pdf_init(mrst,1); }
  //else if (pdftype==alekhin) {
  //  pdf_init(alekhin,order_flag);   QCD::alpha_s_Z = Alekhin_alpha_s(MASS::mass_Z);
  //}
  DMatrix LO1Matrix(0,n_points,0,2);
  DMatrix LO2Matrix(0,n_points,0,2);
  for (int j = 0; j <= n_points; j++) {
     Y = 0. + step_size * j;
     muF = mu1*Q;   muR = mu1*Q;
     lumi::setV(Wplus,Q,alphat,Nf,f_quiet);
     DVector plus_rap_y = rap_y();
     lumi::setV(Wminus,Q,alphat,Nf,f_quiet);
     DVector minus_rap_y = rap_y();
     temp_ratio = plus_rap_y[0]/minus_rap_y[0];
     temp_err = 1/minus_rap_y[0] * sqrt( 
                  plus_rap_y[1]*plus_rap_y[1] 
               + plus_rap_y[0]*plus_rap_y[0]/minus_rap_y[0]/minus_rap_y[0]
		  * minus_rap_y[1]*minus_rap_y[1] );
     LO1Matrix.fillRow(j,3,Y,temp_ratio,temp_err);
//  
     muF = mu2*Q;   muR = mu2*Q;
     lumi::setV(Wplus,Q,alphat,Nf,f_quiet);
     plus_rap_y = rap_y();
     lumi::setV(Wminus,Q,alphat,Nf,f_quiet);
     minus_rap_y = rap_y();
     temp_ratio = plus_rap_y[0]/minus_rap_y[0];
     temp_err = 1/minus_rap_y[0] * sqrt( 
                  plus_rap_y[1]*plus_rap_y[1] 
               + plus_rap_y[0]*plus_rap_y[0]/minus_rap_y[0]/minus_rap_y[0]
		  * minus_rap_y[1]*minus_rap_y[1] );
     LO2Matrix.fillRow(j,3,Y,temp_ratio,temp_err);
   }
// print LO:
  cout << endl << "set color blue" << endl << endl;
   cout << "title 0.05 10.5 data 'LO' SIZE 2.5" << endl << endl;
   cout << "( mu/Q = " << mu2 << endl;
   for (int j = n_points; j > 0; j--) {
     cout << setw(8) << setprecision(8) <<  " " << -LO2Matrix[j][0]
            << "       " << LO2Matrix[j][1] << " "
            << "   (   " << LO2Matrix[j][2] << endl;
   }
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << LO2Matrix[j][0]
            << "       " << LO2Matrix[j][1] << " "
            << "   (   " << LO2Matrix[j][2] << endl;
   }
   cout << "( mu/Q = " << mu1 << endl;
   for (int j = n_points; j > 0; j--) {
     cout << setw(8) << setprecision(8) <<  " " << LO1Matrix[j][0]
            << "       " << LO1Matrix[j][1] << " "
            << "   (   " << LO1Matrix[j][2] << endl;
   }
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << -LO1Matrix[j][0]
            << "       " << LO1Matrix[j][1] << " "
            << "   (   " << LO1Matrix[j][2] << endl;
   }
   cout << "join fill" << endl;
// Next do both NLO curves:
  order_flag = 1;  
  //if (pdftype==mrst) { QCD::alpha_s_Z = 0.119;  pdf_init(mrst,2); }
  //else if (pdftype==alekhin) {
  //  pdf_init(alekhin,order_flag);  QCD::alpha_s_Z = Alekhin_alpha_s(MASS::mass_Z); 
  //}
  DMatrix NLO1Matrix(0,n_points,0,2);
  DMatrix NLO2Matrix(0,n_points,0,2);
  for (int j = 0; j <= n_points; j++) {
     Y = 0. + step_size * j;
     muF = mu1*Q;   muR = mu1*Q;
     lumi::setV(Wplus,Q,alphat,Nf,f_quiet);
     DVector plus_rap_y = rap_y();
     lumi::setV(Wminus,Q,alphat,Nf,f_quiet);
     DVector minus_rap_y = rap_y();
     temp_ratio = plus_rap_y[0]/minus_rap_y[0];
     temp_err = 1/minus_rap_y[0] * sqrt( 
                  plus_rap_y[1]*plus_rap_y[1] 
               + plus_rap_y[0]*plus_rap_y[0]/minus_rap_y[0]/minus_rap_y[0]
		  * minus_rap_y[1]*minus_rap_y[1] );
     NLO1Matrix.fillRow(j,3,Y,temp_ratio,temp_err);
//  
     muF = mu2*Q;   muR = mu2*Q;
     lumi::setV(Wplus,Q,alphat,Nf,f_quiet);
     plus_rap_y = rap_y();
     lumi::setV(Wminus,Q,alphat,Nf,f_quiet);
     minus_rap_y = rap_y();
     temp_ratio = plus_rap_y[0]/minus_rap_y[0];
     temp_err = 1/minus_rap_y[0] * sqrt( 
                  plus_rap_y[1]*plus_rap_y[1] 
               + plus_rap_y[0]*plus_rap_y[0]/minus_rap_y[0]/minus_rap_y[0]
		  * minus_rap_y[1]*minus_rap_y[1] );
     NLO2Matrix.fillRow(j,3,Y,temp_ratio,temp_err);
   }
// print NLO:
  cout << endl << "set color green" << endl << endl;
   cout << "title 0.05 20.5 data 'NLO' SIZE 2.5" << endl << endl;
   cout << "( mu/Q = " << mu2 << endl;
   for (int j = n_points; j > 0; j--) {
     cout << setw(8) << setprecision(8) <<  " " << -NLO2Matrix[j][0]
            << "       " << NLO2Matrix[j][1] << " "
            << "   (   " << NLO2Matrix[j][2] << endl;
   }
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << NLO2Matrix[j][0]
            << "       " << NLO2Matrix[j][1] << " "
            << "   (   " << NLO2Matrix[j][2] << endl;
   }
   cout << "( mu/Q = " << mu1 << endl;
   for (int j = n_points; j > 0; j--) {
     cout << setw(8) << setprecision(8) <<  " " << NLO1Matrix[j][0]
            << "       " << NLO1Matrix[j][1] << " "
            << "   (   " << NLO1Matrix[j][2] << endl;
   }
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << -NLO1Matrix[j][0]
            << "       " << NLO1Matrix[j][1] << " "
            << "   (   " << NLO1Matrix[j][2] << endl;
   }
   cout << "join fill" << endl;
// Finally do both NNLO curves:
  order_flag = 2;  
  //if (pdftype==mrst) { QCD::alpha_s_Z = 0.1155;  pdf_init(mrst,6); }
  //else if (pdftype==alekhin) {
  //  pdf_init(alekhin,order_flag);  QCD::alpha_s_Z = Alekhin_alpha_s(MASS::mass_Z); 
  //}
  DMatrix NNLO1Matrix(0,n_points,0,2);
  DMatrix NNLO2Matrix(0,n_points,0,2);
  for (int j = 0; j <= n_points; j++) {
     Y = 0. + step_size * j;
     muF = mu1*Q;   muR = mu1*Q;
     lumi::setV(Wplus,Q,alphat,Nf,f_quiet);
     DVector plus_rap_y = rap_y();
     lumi::setV(Wminus,Q,alphat,Nf,f_quiet);
     DVector minus_rap_y = rap_y();
     temp_ratio = plus_rap_y[0]/minus_rap_y[0];
     temp_err = 1/minus_rap_y[0] * sqrt( 
                  plus_rap_y[1]*plus_rap_y[1] 
               + plus_rap_y[0]*plus_rap_y[0]/minus_rap_y[0]/minus_rap_y[0]
		  * minus_rap_y[1]*minus_rap_y[1] );
     NNLO1Matrix.fillRow(j,3,Y,temp_ratio,temp_err);
//  
     muF = mu2*Q;   muR = mu2*Q;
     lumi::setV(Wplus,Q,alphat,Nf,f_quiet);
     plus_rap_y = rap_y();
     lumi::setV(Wminus,Q,alphat,Nf,f_quiet);
     minus_rap_y = rap_y();
     temp_ratio = plus_rap_y[0]/minus_rap_y[0];
     temp_err = 1/minus_rap_y[0] * sqrt( 
                  plus_rap_y[1]*plus_rap_y[1] 
               + plus_rap_y[0]*plus_rap_y[0]/minus_rap_y[0]/minus_rap_y[0]
		  * minus_rap_y[1]*minus_rap_y[1] );
     NNLO2Matrix.fillRow(j,3,Y,temp_ratio,temp_err);
   }
//
// print NNLO:
  cout << endl << "set color red" << endl << endl;
   cout << "title 0.05 25.5 data 'NNLO' SIZE 2.5" << endl << endl;
   cout << "( mu/Q = " << mu2 << endl;
   for (int j = n_points; j > 0; j--) {
     cout << setw(8) << setprecision(8) <<  " " << -NNLO2Matrix[j][0]
            << "       " << NNLO2Matrix[j][1] << " "
            << "   (   " << NNLO2Matrix[j][2] << endl;
   }
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << NNLO2Matrix[j][0]
            << "       " << NNLO2Matrix[j][1] << " "
            << "   (   " << NNLO2Matrix[j][2] << endl;
   }
   cout << "( mu/Q = " << mu1 << endl;
   for (int j = n_points; j > 0; j--) {
     cout << setw(8) << setprecision(8) <<  " " << NNLO1Matrix[j][0]
            << "       " << NNLO1Matrix[j][1] << " "
            << "   (   " << NNLO1Matrix[j][2] << endl;
   }
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << -NNLO1Matrix[j][0]
            << "       " << NNLO1Matrix[j][1] << " "
            << "   (   " << NNLO1Matrix[j][2] << endl;
   }
   cout << "join fill" << endl;
   f_quiet = f_quiet_saved;
}

// Same as "sym_scan_all", but handles case of an asymmetric 
// rapidity distribution, e.g. W production at Tevatron.
// For n_points = 38, agrees with Frank's choice of points.

//void asym_scan_all(pdf_type pdftype, int n_points, double mu1, double mu2){
void asym_scan_all(int n_points, double mu1, double mu2){
  PDF::check_initialization();
  ymax = log(E_CM/Q) * n_points/(n_points+2.);  
  cout << endl
       << "-----------------------------------------------------------" << endl;
  cout << "LO, NLO, NNLO rapidity scan - asymmetric case (|y| < ymax)" << endl;
  cout << "-----------------------------------------------------------" << endl;
  cout << " ymax =  " << ymax
       << ";    number of rapidity steps =  " << n_points << endl << endl; 
  cout << " muF_lower = muR_lower = " << mu1 << " * Q " << endl;
  cout << " muF_upper = muR_upper = " << mu2 << " * Q " << endl << endl;
  //cout << " pdf type = " << pdftype << " (2 = mrst, 3 = alekhin) "  << endl << endl;
  double step_size = 2.*ymax/n_points; 
  f_NNLO_only = 1;   lumi::compute_all();
//
// Do both LO curves first:
  order_flag = 0;  
  //if (pdftype==mrst) { QCD::alpha_s_Z = 0.130;  pdf_init(mrst,1); }
  //else if (pdftype==alekhin) {
  //  pdf_init(alekhin,order_flag);   QCD::alpha_s_Z = Alekhin_alpha_s(MASS::mass_Z);
  //}
  DMatrix LO1Matrix(0,n_points,0,2);
  DMatrix LO2Matrix(0,n_points,0,2);
  for (int j = 0; j <= n_points; j++) {
     Y = - ymax + step_size * j;
     muF = mu1*Q;   muR = mu1*Q;
     DVector temp_rap_y = rap_y();
     LO1Matrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
//  
     muF = mu2*Q;   muR = mu2*Q;
     temp_rap_y = rap_y();
     LO2Matrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
   }
// Next do both NLO curves:
  order_flag = 1;  
  //if (pdftype==mrst) { QCD::alpha_s_Z = 0.119;  pdf_init(mrst,2); }
  //else if (pdftype==alekhin) {
  //  pdf_init(alekhin,order_flag);  QCD::alpha_s_Z = Alekhin_alpha_s(MASS::mass_Z); 
  //}
  DMatrix NLO1Matrix(0,n_points,0,2);
  DMatrix NLO2Matrix(0,n_points,0,2);
  for (int j = 0; j <= n_points; j++) {
     Y = -ymax + step_size * j;
     muF = mu1*Q;   muR = mu1*Q;
     DVector temp_rap_y = rap_y();
     NLO1Matrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
//  
     muF = mu2*Q;   muR = mu2*Q;
     temp_rap_y = rap_y();
     NLO2Matrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
   }
// Finally do both NNLO curves:
  order_flag = 2;  
  //if (pdftype==mrst) { QCD::alpha_s_Z = 0.1155;  pdf_init(mrst,6); }
  //else if (pdftype==alekhin) {
  //  pdf_init(alekhin,order_flag);  QCD::alpha_s_Z = Alekhin_alpha_s(MASS::mass_Z); 
  //}
  DMatrix NNLO1Matrix(0,n_points,0,2);
  DMatrix NNLO2Matrix(0,n_points,0,2);
  for (int j = 0; j <= n_points; j++) {
     Y = -ymax + step_size * j;
     muF = mu1*Q;   muR = mu1*Q;
     DVector temp_rap_y = rap_y();
     NNLO1Matrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
//  
     muF = mu2*Q;   muR = mu2*Q;
     temp_rap_y = rap_y();
     NNLO2Matrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
   }
//
// print results: 
// print LO:
  cout << endl << "set color blue" << endl << endl;
   cout << "title 0.05 10.5 data 'LO' SIZE 2.5" << endl << endl;
   cout << "( mu/Q = " << mu2 << endl;
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << LO2Matrix[j][0]
            << "       " << LO2Matrix[j][1] << " "
            << "   (   " << LO2Matrix[j][2] << endl;
   }
   cout << "( mu/Q = " << mu1 << endl;
   for (int j = n_points; j >=0; j--) {
     cout << setw(8) << setprecision(8) <<  " " << LO1Matrix[j][0]
            << "       " << LO1Matrix[j][1] << " "
            << "   (   " << LO1Matrix[j][2] << endl;
   }
   cout << "join fill" << endl;
// print NLO:
  cout << endl << "set color green" << endl << endl;
   cout << "title 0.05 20.5 data 'NLO' SIZE 2.5" << endl << endl;
   cout << "( mu/Q = " << mu2 << endl;
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << NLO2Matrix[j][0]
            << "       " << NLO2Matrix[j][1] << " "
            << "   (   " << NLO2Matrix[j][2] << endl;
   }
   cout << "( mu/Q = " << mu1 << endl;
   for (int j = n_points; j >= 0; j--) {
     cout << setw(8) << setprecision(8) <<  " " << NLO1Matrix[j][0]
            << "       " << NLO1Matrix[j][1] << " "
            << "   (   " << NLO1Matrix[j][2] << endl;
   }
   cout << "join fill" << endl;
// print NNLO:
  cout << endl << "set color red" << endl << endl;
   cout << "title 0.05 25.5 data 'NNLO' SIZE 2.5" << endl << endl;
   cout << "( mu/Q = " << mu2 << endl;
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << NNLO2Matrix[j][0]
            << "       " << NNLO2Matrix[j][1] << " "
            << "   (   " << NNLO2Matrix[j][2] << endl;
   }
   cout << "( mu/Q = " << mu1 << endl;
   for (int j = n_points; j >= 0; j--) {
     cout << setw(8) << setprecision(8) <<  " " << NNLO1Matrix[j][0]
            << "       " << NNLO1Matrix[j][1] << " "
            << "   (   " << NNLO1Matrix[j][2] << endl;
   }
   cout << "join fill" << endl;
}

// =========== SCAN IN REN/FACT. SCALES mu ============================

// At fixed y, scan muF = muR from mu_r_lower*Q to mu_r_upper*Q,
// (or simple variations on this, like muF only, muR only, etc.)
// with mu values uniformly spaced in log(mu), and print results.
// X is the variable on the horizontal axis for plotting.
// Do LO, NLO and NNLO MRST curves at once.

void scan_mu(double yy, double mu_r_lower, double mu_r_upper, int n_points){
  PDF::check_initialization();
  cout << endl
       << "-------------------------------------------------------------" 
       << endl; 
  cout << "Performing mu scan from " << mu_r_lower << " to " 
       << mu_r_upper << " in " << n_points 
       << " steps;  at rapidity y = " << yy << endl; 
  cout << "-------------------------------------------------------------"
       << endl; 
  Y = yy;
  double n_points_real = n_points;
  double step_size = log(mu_r_upper/mu_r_lower)/n_points_real;
  double X;
// matrices to store results:
  DMatrix LOMatrix(0,n_points,0,2); 
  DMatrix NLOMatrix(0,n_points,0,2);  
  DMatrix NNLOMatrix(0,n_points,0,2);  
  f_NNLO_only = 1;   lumi::compute_all();
  for (int j = 0; j <= n_points; j++) {
    muF = Q * mu_r_lower * exp(step_size * j);
    muR = Q*Q/muF;
    X = muF/Q;
// LO MRST:
    order_flag = 0;  //QCD::alpha_s_Z = 0.130;  pdf_init(mrst,1);  
    DVector temp_rap_y = rap_y();
    LOMatrix.fillRow(j,3,X,temp_rap_y[0],temp_rap_y[1]);
// NLO MRST:
    order_flag = 1;  //QCD::alpha_s_Z = 0.119;  pdf_init(mrst,2);
    temp_rap_y = rap_y();
    NLOMatrix.fillRow(j,3,X,temp_rap_y[0],temp_rap_y[1]);
// NNLO MRST:
    order_flag = 2;  //QCD::alpha_s_Z = 0.1155;  pdf_init(mrst,6);
    temp_rap_y = rap_y();
    NNLOMatrix.fillRow(j,3,X,temp_rap_y[0],temp_rap_y[1]);
  }
// print results: 
// print LO:
  cout << endl << "set color blue" << endl << endl;
  cout << "title 0.05 10.5 data 'LO' SIZE 2.5" << endl << endl;
  for (int j = 0; j <= n_points; j++) {
    cout << setw(8) << setprecision(8) <<  " " << LOMatrix[j][0]
	 << "       " << LOMatrix[j][1] << " "
	 << "   (   " << LOMatrix[j][2] << endl;
  }
  cout << "join" << endl;
// print NLO:
  cout << endl << "set color green" << endl << endl;
  cout << "title 0.05 20.5 data 'NLO' SIZE 2.5" << endl << endl;
  for (int j = 0; j <= n_points; j++) {
    cout << setw(8) << setprecision(8) <<  " " << NLOMatrix[j][0]
	 << "       " << NLOMatrix[j][1] << " "
	 << "   (   " << NLOMatrix[j][2] << endl;
  }
  cout << "join" << endl;
// print NNLO:
  cout << endl << "set color red" << endl << endl;
  cout << "title 0.05 25.5 data 'NNLO' SIZE 2.5" << endl << endl;
  for (int j = 0; j <= n_points; j++) {
    cout << setw(8) << setprecision(8) <<  " " << NNLOMatrix[j][0]
	 << "       " << NNLOMatrix[j][1] << " "
	 << "   (   " << NNLOMatrix[j][2] << endl;
  }
  cout << "join" << endl;
  cout << endl ;
}

// Same as "scan mu", but does the W+/W- ratio.
// X is the variable on the horizontal axis for plotting.

void Wpm_ratio_scan_mu(double yy, double mu_r_lower, double mu_r_upper, int n_points){
  PDF::check_initialization();
  double temp_ratio, temp_err;
  Q = MASS::mass_W;  // assumes we are on-shell...
  int f_quiet_saved = f_quiet;
  f_quiet = 1;  // turn off most output
  cout << endl
       << "-------------------------------------------------------------" 
       << endl; 
  cout << "Performing W+/W- ratio mu scan from " << mu_r_lower << " to " 
       << mu_r_upper << " in " << n_points 
       << " steps;  at rapidity y = " << yy << endl; 
  cout << "-------------------------------------------------------------"
       << endl; 
  Y = yy;
  double n_points_real = n_points;
  double step_size = log(mu_r_upper/mu_r_lower)/n_points_real;
  double X;
// matrices to store results:
  DMatrix LOMatrix(0,n_points,0,2); 
  DMatrix NLOMatrix(0,n_points,0,2);  
  DMatrix NNLOMatrix(0,n_points,0,2);  
  f_NNLO_only = 1;   lumi::compute_all();
  for (int j = 0; j <= n_points; j++) {
     cout << "Now working on point " << j << " of " << n_points << endl; 
     muR = Q * mu_r_lower * exp(step_size * j);
     muF = Q;
     X = muR/Q;
// LO MRST:
     order_flag = 0;  //QCD::alpha_s_Z = 0.130;  pdf_init(mrst,1);  
     lumi::setV(Wplus,Q,alphat,Nf,f_quiet);
     DVector plus_rap_y = rap_y();
     lumi::setV(Wminus,Q,alphat,Nf,f_quiet);
     DVector minus_rap_y = rap_y();
     temp_ratio = plus_rap_y[0]/minus_rap_y[0];
     temp_err = 1/minus_rap_y[0] * sqrt( 
                  plus_rap_y[1]*plus_rap_y[1] 
               + plus_rap_y[0]*plus_rap_y[0]/minus_rap_y[0]/minus_rap_y[0]
		  * minus_rap_y[1]*minus_rap_y[1] );
     LOMatrix.fillRow(j,3,X,temp_ratio,temp_err);
// NLO MRST:
     order_flag = 1;  //QCD::alpha_s_Z = 0.119;  pdf_init(mrst,2);
     lumi::setV(Wplus,Q,alphat,Nf,f_quiet);
     plus_rap_y = rap_y();
     lumi::setV(Wminus,Q,alphat,Nf,f_quiet);
     minus_rap_y = rap_y();
     temp_ratio = plus_rap_y[0]/minus_rap_y[0];
     temp_err = 1/minus_rap_y[0] * sqrt( 
                  plus_rap_y[1]*plus_rap_y[1] 
               + plus_rap_y[0]*plus_rap_y[0]/minus_rap_y[0]/minus_rap_y[0]
		  * minus_rap_y[1]*minus_rap_y[1] );
     NLOMatrix.fillRow(j,3,X,temp_ratio,temp_err);
// NNLO MRST:
     order_flag = 2;  //QCD::alpha_s_Z = 0.1155;  pdf_init(mrst,6);
     lumi::setV(Wplus,Q,alphat,Nf,f_quiet);
     plus_rap_y = rap_y();
     lumi::setV(Wminus,Q,alphat,Nf,f_quiet);
     minus_rap_y = rap_y();
     temp_ratio = plus_rap_y[0]/minus_rap_y[0];
     temp_err = 1/minus_rap_y[0] * sqrt( 
                  plus_rap_y[1]*plus_rap_y[1] 
               + plus_rap_y[0]*plus_rap_y[0]/minus_rap_y[0]/minus_rap_y[0]
		  * minus_rap_y[1]*minus_rap_y[1] );
     NNLOMatrix.fillRow(j,3,X,temp_ratio,temp_err);
  }
// print results: 
// print LO:
  cout << endl << "set color blue" << endl << endl;
   cout << "title 0.5 1.1 data 'LO' SIZE 2.5" << endl << endl;
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << LOMatrix[j][0]
            << "       " << LOMatrix[j][1] << " "
            << "   (   " << LOMatrix[j][2] << endl;
   }
   cout << "join" << endl;
// print NLO:
  cout << endl << "set color green" << endl << endl;
   cout << "title 0.5 1.2 data 'NLO' SIZE 2.5" << endl << endl;
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << NLOMatrix[j][0]
            << "       " << NLOMatrix[j][1] << " "
            << "   (   " << NLOMatrix[j][2] << endl;
   }
   cout << "join" << endl;
// print NNLO:
  cout << endl << "set color red" << endl << endl;
   cout << "title 0.5 1.3 data 'NNLO' SIZE 2.5" << endl << endl;
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << NNLOMatrix[j][0]
            << "       " << NNLOMatrix[j][1] << " "
            << "   (   " << NNLOMatrix[j][2] << endl;
   }
   cout << "join" << endl;
   cout << endl ;
   f_quiet = f_quiet_saved;
}

// Like "scan_mu" above, but for the total cross section, computed
// "the hard way":   FIX !!!!!!!

DMatrix scan_mu_tot(double mu_r_lower, double mu_r_upper, int n_points){
  PDF::check_initialization();
  double n_points_real = n_points;
  double step_size = log(mu_r_upper/mu_r_lower)/n_points_real;
  DMatrix resultMatrix(0,n_points,0,2);  // matrix to store unnorm. results
  for (int j = 0; j <= n_points; j++) {
     muF = Q * mu_r_lower * exp(step_size * j);
     muR = muF;
     // full result:
     DVector temp_int_y = int_y(0.,1.);
     resultMatrix.fillRow(j,3,muF/Q,temp_int_y[0],temp_int_y[1]);
   }

   // print absolute results again, in form convenient for copying: 
   cout << "   (muF=muR)/Q    |    dsigma/dM  |   (  error   " << endl;
   cout << "------------------------------------------------------- " << endl;
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << resultMatrix[j][0]
            << "       " << resultMatrix[j][1] << " "
            << "   (   " << resultMatrix[j][2]   // include errors
            << endl;
   }
   cout << endl ;
//
 return resultMatrix;
}

// =========== INTEGRATE OVER INVARIANT MASS M ==================

// "int_M_sym_scan_y" 
// integrates over invariant masses M, from M_lower to M_upper,
// just using Simpson's rule with m_points in the M direction,
// and also scans in rapidity (symmetric version).  
// Very time-consuming, so probably cannot
// be run at NNLO for more than a couple of rapidity points at a time.
// If last argument, "containsZ" is 1, we remap the interval to take
// into account the Z peak. 
// At the moment, though, use "containsZ = 0"; the remapping seems
// to perform worse than the original at the same number of points???

void int_M_sym_scan_y(exchange exch, double M_lower, double M_upper, 
   int m_points, int n_points, int containsZ){
  PDF::check_initialization();
 double u_l=0., u_u=0., u=0., temp_prefactor, tempres, temperr;
 muRrel = muR/Q;   muFrel = muF/Q;
 double Gamma_Z = 2.4952;
 ymax = log(E_CM/Q) * n_points/(n_points+1.);  
 cout << endl
      << "--------------------------------------------------------" << endl; 
 cout << "Performing M-integration rapidity scan - "
      << "symmetric case (0 < y < ymax)" << endl; 
 cout << "--------------------------------------------------------" << endl; 
 cout << " M_lower =  " << M_lower << ";  M_upper =  " << M_upper 
      << ";    number of mass steps (must be even!) =  " 
      << m_points << endl << endl;
 cout << " ymax =  " << ymax
      << ";    number of rapidity steps =  " << n_points << endl << endl; 
 lumi::setV(exch,M_lower,alphat,Nf,0);
 f_quiet = 1;
 double step_size = ymax/n_points;
 double M_step_size = (M_upper-M_lower)/m_points;
 if (containsZ==1) { 
   Gamma_Z = 2.4952;
   u_l = atan((M_lower*M_lower-MASS::mass_Z*MASS::mass_Z)/Gamma_Z/MASS::mass_Z);
   u_u = atan((M_upper*M_upper-MASS::mass_Z*MASS::mass_Z)/Gamma_Z/MASS::mass_Z);
   M_step_size = (u_u-u_l)/m_points;
 }
//
 DMatrix resultMatrix(0,n_points,0,2);  // matrix to store results
 for (int j = 0; j <= n_points; j++) {
     Y = 0. + step_size * j;
  // y = -ymax + step_size * j;
     // full result/error:
     double temp_sum_y = 0.;    double temp_err_y = 0.;
      for (int k = 0; k <= m_points; k++) {
        Q = M_lower + M_step_size * k;
        if (containsZ==1) {
	  u = u_l + M_step_size * k;
          Q = sqrt(MASS::mass_Z*MASS::mass_Z + Gamma_Z*MASS::mass_Z*tan(u));
	}
        muR = muRrel*Q;    muF = muFrel*Q;
	lumi::setV(exch,Q,alphat,Nf,1);
        DVector temp_rap_y = rap_y();
        temp_prefactor = 1.;
        if (containsZ==1) { 
          temp_prefactor = Gamma_Z*MASS::mass_Z*(1.+tan(u)*tan(u))/2./Q;
	}     
        tempres = temp_prefactor * temp_rap_y[0];
        temperr = temp_prefactor * temp_rap_y[1];
        if ((k==0) || (k==m_points)) {   // endpoints in Simpson's rule:
	  temp_sum_y = temp_sum_y + M_step_size/3. * tempres;
	  temp_err_y = temp_err_y + M_step_size*M_step_size/9. 
                                       * temperr*temperr;
	}
        else if (k/2.==INT(k/2.)) {     // even points:
	  temp_sum_y = temp_sum_y + M_step_size * 2./3. * tempres;
	  temp_err_y = temp_err_y + M_step_size*M_step_size * 4./9. 
                                       * temperr*temperr;
        }
        else {                          // odd points:
	  temp_sum_y = temp_sum_y + M_step_size * 4./3. * tempres;
	  temp_err_y = temp_err_y + M_step_size*M_step_size * 16./9. 
                                       * temperr*temperr;
        }
        temp_err_y = sqrt(temp_err_y);
        resultMatrix.fillRow(j,3,Y,temp_sum_y,temp_err_y);
      }
 }
// print results: 
   cout << endl
        << "   y               |    d^2sigma/dM/dy   |   (  error   " << endl;
   cout << "------------------------------------------------------- " << endl;
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << resultMatrix[j][0]
            << "       " << resultMatrix[j][1] << " "
            << "   (   " << resultMatrix[j][2]   // include errors
            << endl;
   }
   cout << endl ;
}

// Routine computes \int_Ml^Mu dM * d sigma/dM/dy, plus errors:

DVector rap_y_M(){
  double total, total_error;
//  Set relative ren/fact. factors (they are held fixed as we
// integrate over M (Q):
  muRrel = muR/Q;   muFrel = muF/Q;
  DVector result(0,1);   
  DVector i_Born(0,2);   DVector i_NLO(0,2);  DVector i_NNLO(0,2);
  if (f_quiet==0) {
    cout << setw(9) << setprecision(9) << " working on    y =  " << Y << endl; 
  } 
// LO case
  if (order_flag == 0) { 
    if (abs(Born_integrand_M(0.2,20.)) < 1.0e-16){
      cout << "   Setting Born terms to 0, since f_qqbar = 0  " << endl;
      result.fill(2,0.,0.); 
    }
    else {
      cout << "   Now integrating Born terms " << endl;
      i_Born = sqint(6,2,10000,10,30,ranseed); 
      result.fill(2,i_Born[0],i_Born[1]) ;
    }
  }
// NLO case
  else if (order_flag == 1) {
    if (abs(Born_integrand_M(0.2,20.)) < 1.0e-16){
      cout << "   Setting Born terms to 0, since f_qqbar = 0  " << endl;
      i_Born.fill(3,0.,0.,0.);
    }
    else {
      cout << "   Now integrating Born terms " << endl;
      i_Born = sqint(6,2,5000,10,20,ranseed); 
    }
    if (abs(int_NLO_M(.03,.43,.93,20.)) < 1.0e-16) {
       if (f_quiet==0) {
       cout << "Setting NLO non-Born terms to 0, since integrand ~ 0 " << endl;
       }
       i_NLO.fill(3,0.,0.,0.);
    }
    else { i_NLO = sqint(7,3,5000,10,30,ranseed); }
    total = i_Born[0] + i_NLO[0];
    total_error = sqrt(i_Born[1]*i_Born[1] + i_NLO[1]*i_NLO[1]);
    result.fill(2,total,total_error);
  }
// NNLO case
  else {   //  order_flag = 2:
    if (f_NNLO_only == 1) {
      if (abs(Born_integrand_M(0.2,20.)) < 1.0e-16){
        cout << "   Setting Born terms to 0, since f_qqbar = 0  " << endl;
      i_Born.fill(3,0.,0.,0.);
      }
      else {
        cout << "   Now integrating Born terms " << endl;
        i_Born = sqint(6,2,5000,10,20,ranseed); 
      }
      if (f_quiet==0) {
        cout << " computing NLO integral for y = " << Y << endl; 
      }
      if (abs(int_NLO_M(.03,.43,.93,20.)) < 1.0e-16) {
        if (f_quiet==0) {
        cout <<"Setting NLO non-Born terms to 0, since integrand ~ 0 "<< endl;
        }
        i_NLO.fill(3,0.,0.,0.);
      }
      else { i_NLO = sqint(7,3,5000,10,30,ranseed); }
    }
    if (f_quiet==0) {
    cout << " computing NNLO integral for y = " << Y << endl; 
    }
    i_NNLO = sqint(8,3,20000,5,15,ranseed);
    if (f_NNLO_only == 0) {
      total = i_Born[0] + i_NNLO[0];
      total_error = sqrt(i_Born[1]*i_Born[1] + i_NNLO[1]*i_NNLO[1]);
    }
    else {
      total = i_Born[0] + i_NLO[0] + i_NNLO[0];
      total_error = sqrt( i_Born[1]*i_Born[1] + i_NLO[1]*i_NLO[1]
                                             + i_NNLO[1]*i_NNLO[1] );
    }
    result.fill(2,total,total_error);
  }
  if (f_quiet==0) {
  cout << setw(8) << setprecision(8) <<  " y = " << Y 
       << ";  int_ml^Mu dM d^2sigma/dM/dy =  " << result[0]
       << "   pm  " << result[1] << endl;
  }
  return result;
}

// Routine uses "rap_y_M" to compute un-normalized 
// integral_Mu^Ml dM * d sigma/dM/dy, plus errors,
// in the SYMMETRIC case, just scans from y = 0 to y = ymax,
// with a number of points equal to n_points:
// ymax is computed from E_CM and Q; then we rescale to omit the last point.
// For n_points = 19, this agrees with Frank's choice of points.
// forwrev = 1  -> print output from -ymax to +ymax
// forwrev = -1  -> print output from +ymax to -ymax

DMatrix sym_scan_rap_y_M(exchange exch, double M_l, double M_u, 
            int n_points, int forwrev){
  PDF::check_initialization();
  Ml = M_l;  Mu = M_u;   exchM = exch;
  ymax = log(E_CM/Q) * n_points/(n_points+1.);  
 cout << endl
      << "--------------------------------------------------------" << endl; 
 cout << "Performing rapidity scan - symmetric case (0 < y < ymax)" << endl; 
 cout << "Includes integration over M from " 
      << Ml << "  to " << Mu << " GeV " << endl; 
 cout << "--------------------------------------------------------" << endl; 
 cout << " ymax =  " << ymax
      << ";    number of rapidity steps =  " << n_points << endl << endl; 
  double step_size = ymax/n_points;
  DMatrix resultMatrix(0,n_points,0,2);  // matrix to store unnorm. results
  for (int j = 0; j <= n_points; j++) {
     Y = 0. + step_size * j;
  // y = -ymax + step_size * j;
     // full result:
     DVector temp_rap_y = rap_y_M();
     resultMatrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
   }
// print results for topdraw:
    cout << endl
         << "   y       |  int_Ml^Mu dM d^2sigma/dM/dy  |  ( error   " << endl;
    cout << "------------------------------------------------------- " << endl;
    for (int j = n_points; j > 0; j--) {
      cout << setw(8) << setprecision(8) <<  " " << -forwrev*resultMatrix[j][0]
           << "       " << resultMatrix[j][1] << " "
           << "   (   " << resultMatrix[j][2] << endl;
    }
    for (int j = 0; j <= n_points; j++) {
      cout << setw(8) << setprecision(8) <<  " " << forwrev*resultMatrix[j][0]
           << "       " << resultMatrix[j][1] << " "
           << "   (   " << resultMatrix[j][2] << endl;
    }
   cout << endl ;
//
 return resultMatrix;
}

// Same as "sym_scan_rap_y_M", except for the ASYMMETRIC case, 
// e.g. W (W') production at the Tevatron. 
// It scans from y = -ymax to y = ymax, with a number of points equal to n_points:
// ymax is computed from E_CM and Q; then we rescale to omit the last
// point on each end.  Try e.g. n_points = 38.
// forwrev = 1  -> print output from -ymax to +ymax
// forwrev = -1  -> print output from +ymax to -ymax

DMatrix asym_scan_rap_y_M(exchange exch, double M_l, double M_u, 
            int n_points, int forwrev){
  PDF::check_initialization();
  Ml = M_l;  Mu = M_u;   exchM = exch;
  ymax = log(E_CM/Q) * n_points/(n_points+2.);  
 cout << endl
      << "--------------------------------------------------------" << endl; 
 cout << "Performing rapidity scan - asymmetric case (|y| < ymax)" << endl; 
 cout << "Includes integration over M from " 
      << Ml << "  to " << Mu << " GeV " << endl; 
 cout << "--------------------------------------------------------" << endl; 
 cout << " ymax =  " << ymax
      << ";    number of rapidity steps =  " << n_points << endl << endl; 
  double step_size = 2.*ymax/n_points;
  DMatrix resultMatrix(0,n_points,0,2);  // matrix to store unnorm. results
  for (int j = 0; j <= n_points; j++) {
     Y = - ymax + step_size * j;
     // full result:
     DVector temp_rap_y = rap_y_M();
     resultMatrix.fillRow(j,3,Y,temp_rap_y[0],temp_rap_y[1]);
   }
// print results for topdraw:
    cout << endl
         << "   y       |  int_Ml^Mu dM d^2sigma/dM/dy  |  ( error   " << endl;
    cout << "------------------------------------------------------- " << endl;
    if (forwrev==1) {
    for (int j = 0; j <= n_points; j++) {
      cout << setw(8) << setprecision(8) <<  " " << resultMatrix[j][0]
           << "       " << resultMatrix[j][1] << " "
           << "   (   " << resultMatrix[j][2] << endl; }
    }
    if (forwrev==-1) {
    for (int j = n_points; j >= 0; j--) {
      cout << setw(8) << setprecision(8) <<  " " << resultMatrix[j][0]
           << "       " << resultMatrix[j][1] << " "
           << "   (   " << resultMatrix[j][2] << endl; }
    }
   cout << endl ;
//
 return resultMatrix;
}

//====================== TESTS ======================================

// Test the luminosity functions:

void lumi_test(){
  using namespace lumi;
  PDF::check_initialization();
 double x_1, x_2, mu_temp;
 cout << "type x1"  << endl;
 cin >> x_1;
 cout << "type x2"  << endl;
 cin >> x_2;
 cout << "type mu"  << endl;
 cin >> mu_temp;
 cout << " x1 = " << x_1 << "  ;   x2 = " << x_2 
      << "  ;   mu = " << mu_temp << endl;
 cout << setw(8) << setprecision(8) << " qqbarNS(x1,x2,mu)  =   " 
      << qqbar_lumi(x_1,x_2,mu_temp,DY,coll) << endl;
 cout << " qqbarB2(x1,x2,mu)  =   " 
      << qqbar_lumi(x_1,x_2,mu_temp,gluon,coll) << endl;
 cout << " qqbarBC(x1,x2,mu)  = [exactly 2 * NS for (gamma,Z) case] " 
      << qqbar_BC_lumi(x_1,x_2,mu_temp,coll) << endl;
 cout << " qqbarABv(x1,x2,mu) not required; hard cross section vanishes  " 
      << endl;
 cout << " qqbarABax(x1,x2,mu)  =   " 
      << qqbar_ax_lumi(x_1,x_2,mu_temp,coll) << endl;
 cout << " qg_lumi(x1,x2,mu) = " << qg_lumi(x_1,x_2,mu_temp,coll) << endl;
 cout << " gq_lumi(x1,x2,mu) = " << gq_lumi(x_1,x_2,mu_temp,coll) << endl;
 cout << " lumiC2(x1,x2,mu)  =   " 
      << qq_11_lumi(x_1,x_2,mu_temp,coll) << endl;
 cout << " lumiD2(x1,x2,mu)  =   " 
      << qq_22_lumi(x_1,x_2,mu_temp,coll) << endl;
 cout << " lumiCD_V(x1,x2,mu)  =   " 
      << qq_12_lumi(x_1,x_2,mu_temp,coll) << endl;
 cout << " lumiCD_ax(x1,x2,mu)  =   " 
      << qq_12_ax_lumi(x_1,x_2,mu_temp,coll) << endl;
 cout << " lumiCE1(x1,x2,mu)  =   " 
      << qq_CE1_lumi(x_1,x_2,mu_temp,coll) << endl;
 cout << " lumiCE2(x1,x2,mu)  =   " 
      << qq_CE2_lumi(x_1,x_2,mu_temp,coll) << endl;
 cout << " lumiCF(x1,x2,mu)  = [same as CE for (gamma,Z) case] " 
      << qq_CF_lumi(x_1,x_2,mu_temp,coll) << endl;
 cout << " gg_lumi(x1,x2,mu) = " << gg_lumi(x_1,x_2,mu_temp,coll) << endl;
}


};
