/* =============================================================
   pdf luminosity functions required for Z-gamma^* total cross section
   and rapidity distributions.
   ============================================================= */
#ifndef ZGLUMIFNS_H
#define ZGLUMIFNS_H
#include "LHAPDF_interface.hh"  // pdf distributions
#include "QCD_EW.hh"


enum collider {
  pp = 1,
  ppbar = 2,
  LHC=1,
  Tevatron=2
} ;
// Controls number of factors of e_q^2 weighting the q-\bar{q} luminosity function:
enum process { gluon = 0, DY = 1, gamgam = 2 } ;
enum exchange { gamma_only = 1, Zgamma_interf = 2, Z_only = 3, Zgamma = 4, Wplus = 5, Wminus = 6 } ;



namespace lumi {

  // procedures to decide which piece(s) are being computed:
  extern void compute_all(int f_quiet=0);
  extern void compute_qqbar();
  extern void compute_qg();
  extern void compute_gg(); 
  extern void compute_qq();
  extern void compute_qqbar_plus_qq();

  // procedure to decide which of Z/gamma^* exchanges are being computed:
  extern void setV(exchange E, double Q, double alpha, double Nf, int f_quiet);

  //======== Luminosity functions ============================
  // Nf = number of light flavors; should depend on DY mass Q.
  extern double NFf(int Nf);  // NFf = \sum_{i=1}^Nf e_f^2, generalized for (Z,gamma)
  extern double qqbar_lumi(double x1, double x2, double muF, process p, collider c);
  extern double qqbar_BC_lumi(double x1, double x2, double muF, collider c);
  extern double qqbar_ax_lumi(double x1, double x2, double muF, collider c);
  extern double qg_lumi(double x1, double x2, double muF, collider c);
  extern double gq_lumi(double x1, double x2, double muF, collider c);
  extern double gg_lumi(double x1, double x2, double muF, collider c);
  extern double qq_11_lumi(double x1, double x2, double muF, collider c);
  extern double qq_22_lumi(double x1, double x2, double muF, collider c);
  extern double qq_12_lumi(double x1, double x2, double muF, collider c);
  extern double qq_12_ax_lumi(double x1, double x2, double muF, collider c);
  extern double qq_CE1_lumi(double x1, double x2, double muF, collider c);
  extern double qq_CE2_lumi(double x1, double x2, double muF, collider c);
  extern double qq_CF_lumi(double x1, double x2, double muF, collider c);


};

# endif    /*  ZGLUMIFNS_H  */
