#ifndef __VRAP__
#define __VRAP__

#include "math/dilog.hh"
#include "math/DClasses.hh"
#include "Vlumifns.hh"  // luminosity functions required for Drell-Yan


namespace vrap {

  // rapidity & integration ranges:
  //extern double Y, y_lower, y_upper, xi_l, xi_u, ymax, Ml, Mu; 

  extern collider GetCollider();  // Get collider: pp (or LHC) or ppbar (or Tevatron)
  extern double GetECM();  // Get the hadron c.m.s. energy, sqrt(S)
  extern double GetS();  // Get the hadron c.m.s. energy squared S
  extern double GetQ();  // Final state invariant mass
  extern double Getx();  // Get the value of hadronic x = Q^2/S = (Q/E_CM)^2
  extern double GetFactScale();  // Factorization scale
  extern double GetRenormScale();  // Renormalization scale
  extern double GetFactScaleRatio();  // Factorization scale ratio wrt Q
  extern double GetRenormScaleRatio();  // Renormalization scale ratio wrt Q
  extern double GetAlphaQED();  // Get the value of alpha_QED
  extern double GetAlphaQCD();  // Get the value of alpha_QCD 
  extern int GetOrder();  // Get the order k for N^k LO computation
  extern int GetNf();  // Set number of light flavours.


  extern int SetCollider(collider c);  // Set collider: pp (or LHC) or ppbar (or Tevatron)
  extern int SetECM(double CM_energy);  // Set the hadron c.m.s. energy, sqrt(S)
  extern int SetS(double s);  // Set the hadron c.m.s. energy squared, S
  extern int SetQ(double q);  // Final state invariant mass
  extern int Setx(double x);  // Set the value of hadronic x = Q^2/S = (Q/E_CM)^2
  extern int SetY(double y);  // Set the value of hadronic rapidity Y
  extern int SetScales(double mu_R, double mu_F);  // Renormalization and Factorization scales
  extern int SetScalesRatio(double muR_Q_ratio, double muF_Q_ratio);  // Renormalization and Factorization scales ratio wrt Q
  extern int SetOrder(int order);  // Set the order k for N^k LO computation
  extern int SetAlphaQED(double alpha);  // Set the value of alpha_QED (default: ~1/128 -> Z pole value)
  extern int SetAlphaQCD(double alpha);  // Set the value of alpha_QCD (default taken from PDFs at the scale mu_R)
  extern int SetNf(int nf);  // Set number of light flavours. NOTE: the function SetScale will overwrite the value set here

  // Set to TRUE to isolate NNLO contribution; if FALSE (default without calling) the full LO+NLO+NNLO is computed
  extern int SetNNLOonly(bool flag=true);

  // procedure to decide which of Z/gamma^* exchanges are being computed:
  // E could be:   gamma_only, Zgamma_interf, Z_only, Zgamma, Wplus, Wminus
  // ( Zgamma is the sum: gamma_only + Zgamma_interf + Z_only )
  extern void SetV(exchange E);


  // set flag_quiet to TRUE to suppress the output
  extern int SetQuiet(bool flag_quiet=false);

  extern double DY_prefactor(double M, double alpha);  // prefactor (alpha is alpha_QED)
  extern double DY_prefactor();  // prefactor using local values

  extern int SetSeed(int n=0); // Set seed of random number generator. Call *BEFORE* init()

  extern int PrintInfo(); // Prints some informations about the initialization

  // main functions: see the example sources for their usage
  extern int init(double CM_energy, double q, collider c, exchange exch, double muR_Q_ratio=1., double muF_Q_ratio=1., bool flag_quiet=false);
  extern double rap_distr_lo  (double y);
  extern double rap_distr_nlo (double y);
  extern double rap_distr_nnlo(double y);
  extern double rap_integrated_lo  (double Y_min, double Y_max);
  extern double rap_integrated_nlo (double Y_min, double Y_max);
  extern double rap_integrated_nnlo(double Y_min, double Y_max);
  extern double mass_integrated_rap_distr_lo  (double y, double M_min, double M_max, bool run=true);
  extern double mass_integrated_rap_distr_nlo (double y, double M_min, double M_max, bool run=true);
  extern double mass_integrated_rap_distr_nnlo(double y, double M_min, double M_max, bool run=true);



  extern DVector int_y(double xil, double xiu);
  extern DVector rap_y();
  extern DMatrix sym_scan_rap_y(int n_points, int forwrev);
  extern DMatrix asym_scan_rap_y(int n_points, int forwrev);
  extern void sym_scan_all(int n_points, double mu1, double mu2);
  extern void Wpm_ratio_scan_all(int n_points, double mu1, double mu2);
  extern void asym_scan_all(int n_points, double mu1, double mu2);
  extern void scan_mu(double yy, double mu_r_lower, double mu_r_upper, int n_points);
  extern void Wpm_ratio_scan_mu(double yy, double mu_r_lower, double mu_r_upper, int n_points);
  extern DMatrix scan_mu_tot(double mu_r_lower, double mu_r_upper, int n_points);
  extern void int_M_sym_scan_y(exchange exch, double M_lower, double M_upper, int m_points, int n_points, int containsZ);
  extern DVector rap_y_M();
  extern DMatrix sym_scan_rap_y_M(exchange exch, double M_l, double M_u, int n_points, int forwrev);
  extern DMatrix asym_scan_rap_y_M(exchange exch, double M_l, double M_u, int n_points, int forwrev);
  extern void lumi_test();

}

//extern int pdf_init(string SET_NAME);



#endif
