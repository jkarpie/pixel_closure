/*
  You are referred to the LHAPDF library
      http://projects.hepforge.org/lhapdf/
  for detailed explainations about the functions used here.
*/

#include <string>
#include <sstream>
//#include "LHAPDF/LHAPDF.h"  // PDF library LHAPDF
#include "LHAPDF_interface.hh"
#include "QCD_EW.hh"
#include "math/interpolation.hh"

using namespace std;


namespace PDF {
  bool initialized = false;
  bool use_approximate_pdfs = false;
  approx_method a_method;
};

verbosity pdf_verb;
bool automatic_mu_approx = false;
unsigned int n_approx;
double a_mu=-1, a_xmin=-1, a_xmax=-1, *a_x, **a_pdf;
string s_method(approx_method meth) {
  ostringstream s_meth;
  switch(meth) {
  case 0:
    s_meth << "Interpolation   ( points: " << n_approx << " )" << endl ;
    break;
  case 1:
    s_meth << "Chebyshev   ( order: " << n_approx << " )" << endl ;
    break;
  }
  return s_meth.str();
}


int PDF::check_initialization() {
  if(!PDF::initialized) {
    cerr << " >>>>> PDF set not initialized !    -->  Exit" << endl;
    exit(-19);
  }
  return 0;
}

// initialize a pdf set
int PDF::pdf_init(string SET_NAME, int SUBSET, verbosity v) {
  pdf_verb = v;
  setVerbosity((LHAPDF::Verbosity)v);
  LHAPDF::initPDFSet(SET_NAME, LHAPDF::LHGRID, SUBSET);
  cout << endl << " >>>>> Using PDFs:  " << SET_NAME << " ,  subset: " << SUBSET << endl << endl;
  initialized = true;
  return 0;
}

// use a PDF member (subset)
int PDF::pdf_select_subset(int subset) {
  LHAPDF::usePDFMember(subset);
  return 0;
}

// return the number of members (subset) of the selected PDF set
int PDF::number_of_subsets() {
  return LHAPDF::numberPDF();
}

// Extrapolate beyond grid edges.
void PDF::extrapolate(bool extrapolate) {
  LHAPDF::extrapolate(extrapolate);
}

double PDF::alphas_PDF(double Q) {
  return LHAPDF::alphasPDF(Q);
}


// approximate pdfs
int PDF::UseApproximatePDFs(bool approx, approx_method meth, unsigned int n) {
  use_approximate_pdfs = approx;
  a_method = meth;
  n_approx = n;
  if(pdf_verb) {
    if(use_approximate_pdfs)
      cout << endl << "-- Using Approximate PDFs --" << endl
	   << "--    approximation method:  " << s_method(a_method) << endl << endl;
    else
      cout << endl << "-- Using non-Approximate PDFs --" << endl << endl;
  }
  return 0;
}
bool PDF::IsApproximatePDFs() {
  return use_approximate_pdfs;
}
int PDF::SetApproxMethod(approx_method meth, unsigned int n) {
  a_method = meth;
  n_approx = n;
  if(pdf_verb) {
    cout << endl << "-- Using PDFs approximation method:  " << s_method(a_method) << endl << endl;
  }
  return 0;
}
approx_method PDF::GetApproxMethod() {
  return a_method;
}
int PDF::SetAutomaticMu(bool automu) {
  automatic_mu_approx = automu;
  return 0;
}
int PDF::pdfs_approx(double mu, double xmin, double xmax) {
  if(mu == a_mu && xmin==a_xmin && xmax==a_xmax) return 0;
  if(mu <= 0)      { cerr << "mu <= 0 in approximation of PDFs"      << endl; exit(501); }
  if(xmin <= 0)    { cerr << "xmin <= 0 in approximation of PDFs"    << endl; exit(502); }
  if(xmax <= 0)    { cerr << "xmax <= 0 in approximation of PDFs"    << endl; exit(503); }
  if(xmin >= 1)    { cerr << "xmin >= 1 in approximation of PDFs"    << endl; exit(504); }
  if(xmax >  1)    { cerr << "xmax > 1 in approximation of PDFs"     << endl; exit(505); }
  if(xmax <= xmin) { cerr << "xmax <= xmin in approximation of PDFs" << endl; exit(506); }
  if(a_mu < 0) { // never called yet -> not yet initialized
    a_pdf = new double*[11];
    a_pdf = a_pdf + 5;
    for(int i=-5; i<=5; i++) a_pdf[i] = new double[n_approx];
  } else {
    for(int i=-5; i<=5; i++) {
      delete a_pdf[i];
      a_pdf[i] = new double[n_approx];
    }
  }
  a_mu = mu;
  a_xmin = xmin;
  a_xmax = xmax;

  // Now (after checks) start apporximation

  if(a_method == interpol) {  // Interpolation: create grid
    delete a_x;
    a_x = new double[n_approx];
    for(int i=-5; i<=5; i++) {
      for(unsigned int k=0; k<n_approx; k++) {
	// x-logscale sampling
	if(i==-5) a_x[k] = exp( log(a_xmin) + ((double)k/(n_approx-1.)) * log(a_xmax/a_xmin) );
	a_pdf[i][k] = LHAPDF::xfx(a_x[k], a_mu, i);
      }
    }
  }
  else if(a_method == chebyshev) {  // Chebyshev: project on polynomial basis
    cout << "Not implemented" << endl;
    exit(55);
  }
  return 0;
}



double approximated_pdf(int num, double x, double mu) {
  if(mu>0 && mu!=a_mu && automatic_mu_approx) PDF::pdfs_approx(mu, a_xmin, a_xmax);
  double result=0;
  if(PDF::a_method == interpol) {  // Interpolation: create grid
    result = interpolation::linear(a_x, a_pdf[num], n_approx, x);
  }
  else if(PDF::a_method == chebyshev) {  // Chebyshev: project on polynomial basis
    cout << "Not implemented" << endl;
    exit(55);
  }
  return result;
}




inline double xfx(double x, double mu, int pdf_number) {
  return (PDF::use_approximate_pdfs ? approximated_pdf(pdf_number,x,mu) : LHAPDF::xfx(x,mu, pdf_number) );
}


// call pdfs in a standard notation, after initialization:
double PDF::pdf (int pdf_number, double x, double mu) { return xfx(x,mu, pdf_number)/x; }

double PDF::d   (double x, double mu) { return xfx(x,mu, 1)/x; }
double PDF::dbar(double x, double mu) { return xfx(x,mu,-1)/x; }

double PDF::u   (double x, double mu) { return xfx(x,mu, 2)/x; }
double PDF::ubar(double x, double mu) { return xfx(x,mu,-2)/x; }

double PDF::s   (double x, double mu) { return xfx(x,mu, 3)/x; }
double PDF::str (double x, double mu) { return xfx(x,mu, 3)/x; }
double PDF::sbar(double x, double mu) { return xfx(x,mu,-3)/x; }

double PDF::c   (double x, double mu) { return xfx(x,mu, 4)/x; }
double PDF::chm (double x, double mu) { return xfx(x,mu, 4)/x; }
double PDF::cbar(double x, double mu) { return xfx(x,mu,-4)/x; }

double PDF::b   (double x, double mu) { return xfx(x,mu, 5)/x; }
double PDF::bot (double x, double mu) { return xfx(x,mu, 5)/x; }
double PDF::bbar(double x, double mu) { return xfx(x,mu,-5)/x; }

double PDF::g   (double x, double mu) { return xfx(x,mu, 0)/x; }


// same as before, but calls x*f(x,Q)
double PDF::xpdf (int pdf_number, double x, double mu) { return xfx(x,mu, pdf_number); }

double PDF::xd   (double x, double mu) { return xfx(x,mu, 1); }
double PDF::xdbar(double x, double mu) { return xfx(x,mu,-1); }

double PDF::xu   (double x, double mu) { return xfx(x,mu, 2); }
double PDF::xubar(double x, double mu) { return xfx(x,mu,-2); }

double PDF::xs   (double x, double mu) { return xfx(x,mu, 3); }
double PDF::xstr (double x, double mu) { return xfx(x,mu, 3); }
double PDF::xsbar(double x, double mu) { return xfx(x,mu,-3); }

double PDF::xc   (double x, double mu) { return xfx(x,mu, 4); }
double PDF::xchm (double x, double mu) { return xfx(x,mu, 4); }
double PDF::xcbar(double x, double mu) { return xfx(x,mu,-4); }

double PDF::xb   (double x, double mu) { return xfx(x,mu, 5); }
double PDF::xbot (double x, double mu) { return xfx(x,mu, 5); }
double PDF::xbbar(double x, double mu) { return xfx(x,mu,-5); }

double PDF::xg   (double x, double mu) { return xfx(x,mu, 0); }


void PDF::PrintPDFInfo(int SUBSET) {
  LHAPDF::getDescription();
  cout << " Parameters:" << endl;
  cout << "  alpha_s(m_Z) = " << LHAPDF::alphasPDF(MASS::mass_Z) << endl;
  cout << "  qcdlam4      = " << LHAPDF::getLam4(SUBSET) << endl;
  cout << "  qcdlam5      = " << LHAPDF::getLam5(SUBSET) << endl;
  cout << "  orderPDF     = " << LHAPDF::getOrderPDF() << endl;
  cout << "  xmin         = " << LHAPDF::getXmin(SUBSET) << endl;
  cout << "  xmax         = " << LHAPDF::getXmax(SUBSET) << endl;
  cout << "  q2min        = " << LHAPDF::getQ2min(SUBSET) << endl;
  cout << "  q2max        = " << LHAPDF::getQ2max(SUBSET) << endl;
  cout << "  orderalfas   = " << LHAPDF::getOrderAlphaS() << endl;
  cout << "  num flav     = " << LHAPDF::getNf() << endl;
  cout << "  number       = " << LHAPDF::numberPDF() << endl << endl;
}
