/* =============================================================
   Special functions required for the "hard" NNLO contributions 
   to the DY rapidity distributions.
   ============================================================= */

#ifndef HARDFNS_H
#define HARDFNS_H

#include "math/dilog.hh"
#include "math/complex.hh"

extern double real_conv(double y, double z); // Kirill -> my conventions
extern double DD1(double n, double y);  // "plus" distributions (w.o. subtraction)
extern double J3(double y, double z);
// Functions needed for J2:
extern double M1(double x, double xp, double xm);
extern double I_analytic(double y, double z);
extern double J27(double y, double z);
extern double J2(double y, double z);
// J1 is not independent, but here it is anyway:
extern double J1(double y, double z);
extern double J21(double y, double z);
// u -> 1 limits:
extern double J3_u1(double z);
extern double J27_u1(double z);
extern double J2_u1(double z);
extern double J21_u1(double z);
extern double J2rem(double z);
// For singularity at z = (2*u/(1+u))^2:
extern double y_sing(double z);
# endif    /*  HARDFNS_H  */
