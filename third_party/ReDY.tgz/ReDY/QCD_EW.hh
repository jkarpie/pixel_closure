#ifndef __QCD_EW__
#define __QCD_EW__
#include <iostream>
#include <iomanip>
#include <cmath>
#include "math/complex.hh"
#include "math/thbasics.hh"
#include "math/dilog.hh"
#include "math/random.hh"



const double GeV2fb = 389379292000.;   // GeV^2*fb conversion constant
const double GeV2pb = 389379292.;   // GeV^2*pb conversion constant



//////////////////////////////////
// Masses in GeV
//////////////////////////////////
namespace MASS {
  // massive vector bosons
  const double mass_Z=91.1876;
  const double mass_W=80.398;
  // quarks
  const double mass_s=0.104, mass_c=1.27, mass_b=4.20, mass_t=171.2;
  // leptons
  const double mass_e = 0.0005109989, mass_mu = 0.105658, mass_tau = 1.77703;
  // "best (?) light quark masses" 
  //const double mass_u = 0.005, mass_d = 0.005;
  // value of m_t(m_t) corresponding to  m_t(pole) = 174.3,
  // using Melnikov - van Ritbergen 3-loop relation, for alpha_s(M_Z) = 0.119
  //const double m_t = 164.6;


};



//////////////////////////////////
// ElectroWeak quantities
//////////////////////////////////
namespace EW {

  // ElectroMagnetic QED coupling at 0 energy
  const double alpha_em = 1./137.035999679;
  // ElectroMagnetic QED coupling at Z mass scale
  const double alpha_em_Z = 1./127.925;
  // Fermi constant in GeV^-2
  const double G_F = 1.16639e-05;
  // choose the definition of sin^2 theta_W:
  //const double s2W = 1.-SQR(MASS::mass_W/MASS::mass_Z);  // sin^2 theta_W = 1 - (m_W/m_Z)^2 = 0.2226
  //const double s2W = 0.2319;                             // sin^2 theta_W(M_Z)_{MS-bar}
  const double s2W = 0.23149;                            // sin^2 theta_W(M_Z)_{MS-bar}, "effective" (Z pole asymmetry) value
  const double c2W = 1.-s2W, sW = sqrt(s2W), cW = sqrt(c2W);
  const double Gamma_W = 2.141;
  const double Gamma_Z = 2.4952;
  const double Br_l_W = 0.108; // average, not sum over all leptons!
  const double Br_l_Z = 0.03363;

  // CKM matrix elements
  const double vud=0.97419;
  const double vus=0.2257;
  const double vub=0.; //0.00359;
  const double vcd=0.2256;
  const double vcs=0.97334;
  const double vcb=0.; //0.0415;

  // photon, Z and W couplings
  //extern double e2[6], ew2[6][6], ez2[6];
  //extern int init_couplings();

  // running couplings:
  extern double alpha_QED_low(double mu); // 1-loop running of alpha_QED, valid between 0 and (about) 2*m_mu.
  extern double alpha_QED_OLD(double mu); // 1-loop running of alpha_QED, valid between 2*m_b and 2*m_W.
  extern double alpha_QED(double mu);     // 1-loop running of alpha_QED, should be ~ valid between 0 and 2*m_W.

  // individual quark charges and weak isospins:
  const double e_u = 2./3.;  const double e_c = 2./3.;  const double e_t = 2./3.; 
  const double e_d = -1./3.;  const double e_s = -1./3.;  const double e_b = -1./3.; 
  //const double I_3u = 0.5;  const double I_3c = 0.5;  const double I_3t = 0.5; 
  //const double I_3d = -0.5;  const double I_3s = -0.5;  const double I_3b = -0.5; 
  //const double sumQsq = 2. * 4./9. + 3. * 1./9.;      // (charge)^2 sum for:  u+c + d+s+b 
  //const double sumQ4 = 2. * 16./81. + 3. * 1./81.;    // (charge)^4 sum for:  u+c + d+s+b   (don't forget leptons too, for lbyl)
  //const double sumQ6 = 2. * 64./729. + 3. * 1./729.;  // (charge)^4 sum for:  u+c + d+s+b   (don't forget leptons too, for lbyl)

};



//////////////////////////////////
// QCD quantities
//////////////////////////////////
namespace QCD {

  // QCD coupling at Z mass
  const double alphaZ=0.118;

  // colour factors
  const int N_c = 3;
  const double T_R = 1./2.;
  const double C_F = (N_c*N_c-1.)/2./N_c;
  const double C_A = 2.*T_R*N_c;

  // running coupling stuff
  ///////////////////////////
  extern double b0(int nf);
  extern double b1(int nf);
  extern double b2(int nf);
  extern double alpha_1loop(double mu, double alpha0, double m0, int nf);
  extern double alpha_2loop(double mu, double alpha0, double m0, int nf);
  // QCD running coupling with thresholds at 2 loops
  extern double alpha_thr_2loop(double mu, double alpha_massZ = alphaZ);
  // QCD running coupling with thresholds at 1 loop
  extern double alpha_thr_1loop(double mu, double alpha_massZ = alphaZ);
  // number of flavours as a function of the energy scale mu
  extern int nf_of_mu(double mu);



  // QCD basics - from Dixon
  //////////////////////////////////

  // preserved from Dixon to keep track of the previous use
  extern double alpha_s_Z;   // alpha_s(m_Z).  Should depend on "order_flag".

  // INITIALIZE alpha_s_Z BEFORE CALLING alpha_s(mu,flag) !!!
  extern double alpha_s(double mu, int order_flag); // Up to 3-loop PDG formula for alpha_s(mu)
  // alpha_s(m_Z) = alpha_s_Z is adjustable.
  // Calls these functions, alpha_s^{1,2,3-loop}(mu)/Pi.
  extern double as1(double mu);
  extern double as2(double mu);
  extern double as3(double mu);
  extern double iterlnx3(double lnx, double alpha_s, double N_f);  // used by as3
  extern double as3_fixed(double mu); // Three-loop PDG formula for alpha_s(mu)/PI with alpha_s(m_Z) = 0.118 fixed.

  // Formulae to run c and b quark MS-bar masses
  /*
  extern double cq(double x, int Nf);
  extern double M_q(double m_q, double mu1, double mu2, int Nf);
  extern double M_t(double mu);
  extern double M_b(double mu);
  extern double M_c(double mu);
  */


  //extern double ran(int n=0);
  //extern int signum(double a);
  /*
  extern complex Clog(double s1, double s2); // complex log of a ratio
  extern complex Clog1(double s);   // complex log of a single s
  extern complex L0(double s1, double s2);
  extern complex L0(double s1, double s2);
  extern complex L1(double s1, double s2);
  extern complex L2(double s1, double s2);
  // Li_2(1-r), for r = s1/s2:
  extern complex CLi2r(double s1, double s2);
  extern complex Lsm1(double s1, double s2, double s3, double s4);
  extern complex Ls0(double s1, double s2, double s3, double s4);
  extern complex Ls1(double s1, double s2, double s3, double s4);
  extern complex Ls2(double s1, double s2, double s3, double s4);
  extern complex Ls3(double s1, double s2, double s3, double s4);
  */
};

#endif
