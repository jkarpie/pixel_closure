#include "QCD_EW.hh"


/*
double EW::e2[6], EW::ew2[6][6], EW::ez2[6];

int EW::init_couplings() {
  // photon couplings
  e2[0] = 0;
  e2[1] = 1./9.;
  e2[2] = 4./9.;
  e2[3] = 1./9.;
  e2[4] = 4./9.;
  e2[5] = 1./9.;
  // Z couplings
  ez2[0] = 0;
  for(int i=1; i<6; i++) {
    ez2[i] = (pow(1.-4.*sqrt(e2[i])*s2W,2)+1.)/4.;
  }
  // W couplings
  for(int i=0; i<6; i++) {
    for(int j=0; j<6; j++) {
      ew2[i][j] = 0.;
    }
  }
  ew2[0][1] = pow(vud,2) + pow(vcd,2);
  ew2[0][2] = pow(vud,2) + pow(vus,2) + pow(vub,2);
  ew2[0][3] = pow(vus,2) + pow(vcs,2);
  ew2[0][4] = pow(vcd,2) + pow(vcs,2) + pow(vcb,2);
  ew2[0][5] = pow(vub,2) + pow(vcb,2);
  for(int i=1; i<6; i++) {
    ew2[i][0] = ew2[0][i];
  }
  ew2[1][2] = pow(vud,2);
  ew2[1][4] = pow(vcd,2); 
  ew2[2][1] = ew2[1][2];
  ew2[2][3] = pow(vus,2);
  ew2[2][5] = pow(vub,2);
  ew2[3][2] = ew2[2][3];
  ew2[3][4] = pow(vcs,2);
  ew2[4][1] = ew2[1][4];
  ew2[4][3] = ew2[3][4];
  ew2[4][5] = pow(vcb,2);
  ew2[5][2] = ew2[2][5];
  ew2[5][4] = ew2[4][5];
  
  return 1;
}
*/

// 1-loop running of alpha_QED, starting from 0, valid up to about 2 * m_mu
// ("1" includes e only):
double EW::alpha_QED_low(double mu){
  double alpha_inv = 1/alpha_em - 1./3./PI * ( 2. * log(mu/MASS::mass_e) - 5./3. );
  return 1./alpha_inv;
}

// 1-loop running of alpha_QED, starting from m_Z, 
// valid between 2*m_b and 2*m_W ("20/3" includes e,mu,tau,d,s,b,u,c):
double EW::alpha_QED_OLD(double mu){
  double alpha_inv = 1/alpha_em_Z - 2./3./PI * (20./3.) * log(mu/MASS::mass_Z);
  return 1./alpha_inv;
}

// 1-loop running of alpha_QED, starting from 0, 
// ~ valid between 0 and 2*m_W ("20/3" includes e,mu,tau,d,s,b,u,c).
// artificial quark masses mock up actual hadron vacuum polarization
// (See hep-ph/0306234, Ciccolini, Dittmaier & Kramer.)

double EW::alpha_QED(double mu){
  using namespace MASS;
  double mass_u_fake = 0.066;
  double mass_s_fake = 0.150;
  double alpha_inv;
  if (ABS(mu) < 2.*mass_e) { alpha_inv = 1/alpha_em; }
  else if (ABS(mu) < mass_u_fake) { // e only in vac. pol.:
    alpha_inv = 1/alpha_em - 1./3./PI * ( 2. * log(mu/mass_e) - 5./3. ); }
  else if (ABS(mu) < 2.*mass_mu) { // add u and d quarks together here:
    alpha_inv = 1/alpha_em - 1./3./PI * ( 2. * log(mu/mass_e) - 5./3.
                 + 5./3. * ( 2. * log(mu/mass_u_fake) - 5./3. )  ); }
  else if (ABS(mu) < 2.*mass_s) { // add mu:
    alpha_inv = 1/alpha_em - 1./3./PI * ( 2. * log(mu/mass_e) - 5./3.
                 + 5./3. * ( 2. * log(mu/mass_u_fake) - 5./3. ) 
                 + 2. * log(mu/mass_mu) - 5./3. ); }
  else if (ABS(mu) < 2.*mass_c) { // add s quark:
    alpha_inv = 1/alpha_em - 1./3./PI * ( 2. * log(mu/mass_e) - 5./3.
                 + 5./3. * ( 2. * log(mu/mass_u_fake) - 5./3. ) 
                 + 2. * log(mu/mass_mu) - 5./3.
                 + 1./3. * ( 2. * log(mu/mass_s_fake) - 5./3. ) ); }
  else if (ABS(mu) < 2.*mass_tau) { // add c quark:
    alpha_inv = 1/alpha_em - 1./3./PI * ( 2. * log(mu/mass_e) - 5./3.
                 + 5./3. * ( 2. * log(mu/mass_u_fake) - 5./3. ) 
                 + 2. * log(mu/mass_mu) - 5./3.
                 + 1./3. * ( 2. * log(mu/mass_s_fake) - 5./3. ) 
                 + 4./3. * ( 2. * log(mu/mass_c) - 5./3. ) ); }
  else if (ABS(mu) < 2.*mass_b) { // add tau:
    alpha_inv = 1/alpha_em - 1./3./PI * ( 2. * log(mu/mass_e) - 5./3.
                 + 5./3. * ( 2. * log(mu/mass_u_fake) - 5./3. ) 
                 + 2. * log(mu/mass_mu) - 5./3.
                 + 1./3. * ( 2. * log(mu/mass_s_fake) - 5./3. ) 
                 + 4./3. * ( 2. * log(mu/mass_c) - 5./3. )
                 + 2. * log(mu/mass_tau) - 5./3. ); }
  else if (ABS(mu) < 2.*mass_W) { // add b:
    alpha_inv = 1/alpha_em - 1./3./PI * ( 2. * log(mu/mass_e) - 5./3.
                 + 5./3. * ( 2. * log(mu/mass_u_fake) - 5./3. ) 
                 + 2. * log(mu/mass_mu) - 5./3.
                 + 1./3. * ( 2. * log(mu/mass_s_fake) - 5./3. ) 
                 + 4./3. * ( 2. * log(mu/mass_c) - 5./3. )
                 + 2. * log(mu/mass_tau) - 5./3. 
                 + 1./3. * ( 2. * log(mu/mass_b) - 5./3. ) ); }
  else if (ABS(mu) < 2.*mass_t) { // add W:
    alpha_inv = 1/alpha_em - 1./3./PI * ( 2. * log(mu/mass_e) - 5./3.
                 + 5./3. * ( 2. * log(mu/mass_u_fake) - 5./3. ) 
                 + 2. * log(mu/mass_mu) - 5./3.
                 + 1./3. * ( 2. * log(mu/mass_s_fake) - 5./3. ) 
                 + 4./3. * ( 2. * log(mu/mass_c) - 5./3. )
                 + 2. * log(mu/mass_tau) - 5./3. 
                 + 1./3. * ( 2. * log(mu/mass_b) - 5./3. )
 // used "Kaplunovsky formula" (not sure about "-5/3") for W case!
                 - 21./2. * log(mu/mass_W) ); }
  else { // add t quark:
    alpha_inv = 1/alpha_em - 1./3./PI * ( 2. * log(mu/mass_e) - 5./3.
                 + 5./3. * ( 2. * log(mu/mass_u_fake) - 5./3. ) 
                 + 2. * log(mu/mass_mu) - 5./3.
                 + 1./3. * ( 2. * log(mu/mass_s_fake) - 5./3. ) 
                 + 4./3. * ( 2. * log(mu/mass_c) - 5./3. )
                 + 2. * log(mu/mass_tau) - 5./3. 
                 + 1./3. * ( 2. * log(mu/mass_b) - 5./3. ) 
 // used "Kaplunovsky formula" (not sure about "-5/3") for W case!
                 - 21./2. * log(mu/mass_W)
                 + 4./3. * ( 2. * log(mu/mass_t) - 5./3. ) ); }
  return 1./alpha_inv;
}






//////////////////////////////////
// QCD quantities
//////////////////////////////////

// running coupling stuff
///////////////////////////
double QCD::b0(int nf){
  return (11.*C_A-4.*T_R*nf)/(12*M_PI);
}
double QCD::b1(int nf){
  return (17.*C_A*C_A - (10.*C_A*T_R+6.*C_F*T_R)*nf)/((11.*C_A-4.*T_R*nf)*2.*M_PI);
}
double QCD::b2(int nf){
  return (2857.*C_A*C_A*C_A/54. + (2.*C_F*C_F-205*C_F*C_A/9.-1415.*C_A*C_A/27.)*T_R*nf + (44.*C_F/9.+158.*C_A/27.)*T_R*T_R*nf*nf)
    /(b0(nf)*64.*M_PI*M_PI*M_PI);
}
double QCD::alpha_1loop(double mu, double alpha0, double m0, int nf){
  return (alpha0/(1.+b0(nf)*alpha0*2.*log(mu/m0)));
}
double QCD::alpha_2loop(double mu, double alpha0, double m0, int nf){
  return alpha_1loop(mu,alpha0,m0,nf)*(1-b1(nf)*alpha_1loop(mu,alpha0,m0,nf)*log(1.+b0(nf)*alpha0*2.*log(mu/m0)));
}
// QCD running coupling with thresholds at 2 loops
double QCD::alpha_thr_2loop(double mu, double alpha_massZ){
  using namespace MASS;
  double res=0;
  if(mu>mass_t)
    res = alpha_2loop(mu,alpha_thr_2loop(mass_t),mass_t,6);
  else if(mu<mass_b && mu>=mass_c)
    res = alpha_2loop(mu,alpha_thr_2loop(mass_b),mass_b,4);
  else if(mu<mass_c && mu>=mass_s)
    res = alpha_2loop(mu,alpha_thr_2loop(mass_c),mass_c,3);
  else if(mu<mass_s)
    res = alpha_2loop(mu,alpha_thr_2loop(mass_s),mass_t,2);
  else
    res = alpha_2loop(mu,alpha_massZ,mass_Z,5);
  return res;
}
// QCD running coupling with thresholds at 1 loop
double QCD::alpha_thr_1loop(double mu, double alpha_massZ){
  using namespace MASS;
  double res=0;
  if(mu>mass_t)
    res = alpha_1loop(mu,alpha_thr_1loop(mass_t),mass_t,6);
  else if(mu<mass_b && mu>=mass_c)
    res = alpha_1loop(mu,alpha_thr_1loop(mass_b),mass_b,4);
  else if(mu<mass_c && mu>=mass_s)
    res = alpha_1loop(mu,alpha_thr_1loop(mass_c),mass_c,3);
  else if(mu<mass_s)
    res = alpha_1loop(mu,alpha_thr_1loop(mass_s),mass_t,2);
  else
    res=alpha_1loop(mu,alpha_massZ,mass_Z,5);
  return res;
}
// number of flavours as a function of the energy scale mu
int QCD::nf_of_mu(double mu){
  using namespace MASS;
  int res=0;
  if(mu>mass_t) res=6;
  else if(mu<mass_b && mu>=mass_c) res=4;
  else if(mu<mass_c && mu>=mass_s) res=3;
  else if(mu<mass_s) res=2;
  else res=5;
  return res;
}



// QCD basics - from Dixon code
//////////////////////////////////


// General running alpha_s formula:
double QCD::alpha_s_Z = QCD::alphaZ;

double QCD::alpha_s(double mu, int order_flag){
  if (order_flag==0) { return PI*as1(mu); }
  else if (order_flag==1) { return PI*as2(mu); }
  else if (order_flag==2) { return PI*as3(mu); }
  else return 0.;
}

// 1-loop is only valid for mu > m_b (5 flavors):
double QCD::as1(double mu){
  double N_f = 5.;
  double b0 = 0.5 * (11./3.*C_A-2./3.*N_f) ;
  double Lambda = MASS::mass_Z * exp(-PI/b0/alpha_s_Z);
  return 1./b0/log(mu/Lambda) ;
}

// 2-loop (from ALEPH Phys. Lett. B284:163 (1992)):
double QCD::as2(double mu){
  using namespace MASS;
  double w, as, b0, b1, N_f;
  if (mu >= mass_b) {
    N_f = 5.;
    b0 = 0.5 * (11./3.*C_A-2./3.*N_f) ;
    b1 = 0.5 * (17./3.*C_A*C_A-(5./3.*C_A+C_F)*N_f) ;
    as = alpha_s_Z/PI;
    w = 1. - b0 * as * log(mass_Z/mu) ;
    return as/w * ( 1. - b1/2./b0 * as * log(w)/w ) ; }
  else {
  // run with 4 flavors below mu = m_b; match with formula
  // alpha_{N_f-1}(M) = alpha_{N_f}(M) [ + O([alpha_{N_f}(M)]^3) ]:
    N_f = 4.;
    b0 = 0.5 * (11./3.*C_A-2./3.*N_f) ;
    b1 = 0.5 * (17./3.*C_A*C_A-(5./3.*C_A+C_F)*N_f) ;
    as = as2(mass_b);
    w = 1. - b0 * as * log(mass_b/mu) ;
    return as/w * ( 1. - b1/2./b0 * as * log(w)/w ) ; }
}

/* 3-loop PDG formula for alpha_s(mu)/PI:
   For mu > m_b we run with 5 flavors from alpha_s(m_Z) = alpha_s_Z.
   For mu < m_b we run with 4 flavors and match at m_b using
   alpha_{N_f-1}(M) = alpha_{N_f}(M) + 11/72/Pi^2 * [alpha_{N_f}(M)]^3 */

double QCD::as3(double mu){
  using namespace MASS;
  double lnx, Lambda_5, Lambda_4, L0, L4, l0, l4,
        b0, b1, b2, alpha_s_5_mb, alpha_s_4_mb, N_f;
  if (mu >= mass_b){ 
    N_f = 5.;
    b0 = 0.5 * (11./3.*C_A-2./3.*N_f) ;
    b1 = 0.5 * (17./3.*C_A*C_A-(5./3.*C_A+C_F)*N_f) ;
    b2 = 0.0625 * ( 2857./27.*C_A*C_A*C_A 
       + (-1415./27.*C_A*C_A-205./9.*C_A*C_F+2.*C_F*C_F)*N_f 
       + (79./27.*C_A+22./9.*C_F)*N_f*N_f ) ;
   // first calculate Lambda_5 from alpha_s_Z.
   // L0 is first approximation to ln(m_Z^2/Lambda_5^2), L4 is 4th:
    L0 = 2.*PI/b0/alpha_s_Z ;
    L4 = iterlnx3(iterlnx3(iterlnx3(iterlnx3(L0,alpha_s_Z,5),
                  alpha_s_Z,5),alpha_s_Z,5),alpha_s_Z,5);
    Lambda_5 = mass_Z * exp(-L4/2.) ;
    lnx = 2. * log(mu/Lambda_5);
    return 2./b0/lnx * ( 1. - b1/b0/b0 * log(lnx)/lnx
          + b1*b1/b0/b0/b0/b0/lnx/lnx 
         * ( (log(lnx) - 0.5)*(log(lnx) - 0.5) + b2*b0/b1/b1 - 1.25 ) );
  }
  else
   // run with 4 flavors below mu = m_b; match at m_b with formula
   // alpha_{N_f-1}(M) = alpha_{N_f}(M) + 11/72/Pi^2 * [alpha_{N_f}(M)]^3
   alpha_s_5_mb = PI*as3(mass_b);
   alpha_s_4_mb = alpha_s_5_mb 
                    * ( 1. + 11./72./PI/PI * alpha_s_5_mb * alpha_s_5_mb );
   // now calculate Lambda_4 from alpha_s_4_mb.
   // l0 is first approximation to ln(m_b^2/Lambda_4^2), l4 is 4th:
   N_f = 4.;
   b0 = 0.5 * (11./3.*C_A-2./3.*N_f) ;
   b1 = 0.5 * (17./3.*C_A*C_A-(5./3.*C_A+C_F)*N_f) ;
   b2 = 0.0625 * ( 2857./27.*C_A*C_A*C_A 
      + (-1415./27.*C_A*C_A-205./9.*C_A*C_F+2.*C_F*C_F)*N_f 
               	+ (79./27.*C_A+22./9.*C_F)*N_f*N_f ) ;
   l0 = 2.*PI/b0/alpha_s_4_mb ;
   l4 = iterlnx3(iterlnx3(iterlnx3(iterlnx3(l0,alpha_s_4_mb,4),
                alpha_s_4_mb,4),alpha_s_4_mb,4),alpha_s_4_mb,4);
   Lambda_4 = mass_b * exp(-l4/2.) ;
   lnx = 2. * log(mu/Lambda_4);
   return 2./b0/lnx * ( 1. - b1/b0/b0 * log(lnx)/lnx
          + b1*b1/b0/b0/b0/b0/lnx/lnx 
         * ( (log(lnx) - 0.5)*(log(lnx) - 0.5) + b2*b0/b1/b1 - 1.25 ) );
}

// Iterate the 3rd order solution to solve for lnx = ln(m^2/Lambda^2) 
// given alpha_s(m), and for N_f flavors:

double QCD::iterlnx3(double lnx, double alpha_s, double N_f){
 double b0 = 0.5 * (11./3.*C_A-2./3.*N_f) ;
 double b1 = 0.5 * (17./3.*C_A*C_A-(5./3.*C_A+C_F)*N_f) ;
 double b2 = 0.0625 * ( 2857./27.*C_A*C_A*C_A 
     + (-1415./27.*C_A*C_A-205./9.*C_A*C_F+2.*C_F*C_F)*N_f 
			+ (79./27.*C_A+22./9.*C_F)*N_f*N_f ) ;
 return 2.*PI/b0/alpha_s * ( 1 - b1/b0/b0 * log(lnx)/lnx
    + b1*b1/b0/b0/b0/b0/lnx/lnx * ( (log(lnx)-.5)*(log(lnx)-.5) 
				    + b2*b0/b1/b1 - 1.25 ) ) ;
}

/* Three-loop PDG formula for alpha_s(mu)/PI:
   For mu > m_b we run with 5 flavors from alpha_s(m_Z) = 0.118.
   For mu < m_b we run with 4 flavors and match at m_b using
   alpha_{N_f-1}(M) = alpha_{N_f}(M) + 11/72/Pi^2 * [alpha_{N_f}(M)]^3 */

double QCD::as3_fixed(double mu){
 double b0, b1, b2, N_f, lnx, Lambda;
 if (mu > MASS::mass_b) { Lambda = .20837;     N_f = 5.; }
 else { Lambda = .28846;    N_f= 4.; }
 b0 = 0.5 * ( 11. - 2./3. * N_f );
 b1 = 0.5 * ( 51. - 19./3. * N_f );
 b2 = 0.0625 * ( 2857. - 5033./9. * N_f + 325./27. * N_f * N_f );

 lnx = 2. * log(mu/Lambda);
 return 2./b0/lnx * ( 1. - b1/b0/b0 * log(lnx)/lnx
       + b1*b1/b0/b0/b0/b0/lnx/lnx 
         * ( (log(lnx) - .5) * (log(lnx) - .5) + b2*b0/b1/b1 - 1.25 ) );
}

/* Formulae to run b and c quark MS-bar masses up to higher scales */

// Intermediate procedure used e.g. in HDECAY:
/*
double QCD::cq(double x, int Nf){
 double b0, A1, A2;
 b0 = 0.5 * (11.-2./3.*Nf);
 A1 = 499./24. - 7./6. * Nf + 5./54. * Nf*Nf;
 A2 = 6375961./4608. + ( - 775333./3456. - 6655./48. * ZETA3 ) * Nf
     + ( 31573./2304. + 605./24. * ZETA3 ) * Nf*Nf
     + ( 527./2592. - 55./36. * ZETA3 ) * Nf*Nf*Nf
     + ( - 2009./46656. + 5./162. * ZETA3 ) * Nf*Nf*Nf*Nf 
     + 35./34992. * Nf*Nf*Nf*Nf*Nf;
 return pow(x/b0, 2./b0) * ( 1. + x * A1/b0/b0 + x*x * A2/b0/b0/b0/b0 ) ;
}

double QCD::M_q(double m_q, double mu1, double mu2, int Nf){
  return m_q * cq(as3(mu2),Nf)/cq(as3(mu1),Nf) ;
}

// M_t(mu) runs the t-quark mass from m_t = m_t(m_t) up to mu,
// OR DOWN TO mu.

double QCD::M_t(double mu){
  using namespace MASS;
  if ((mu >= mass_b) && (mu <= mass_t)) { return M_q(mass_t,mass_t,mu,5) ; }
  else { return M_q(mass_t,mass_t,mu,6) ; }
}

// M_b(mu) runs the b-quark mass from m_b = m_b(m_b) up to mu.
// Need mu >= m_b.

double QCD::M_b(double mu){
  using namespace MASS;
  if ((mu >= mass_b) && (mu <= mass_t)) { return M_q(mass_b,mass_b,mu,5) ; }
  else { return M_q(M_b(mass_t),mass_t,mu,6) ; }
}

// M_c(mu) runs the c-quark mass from m_c = m_c(m_c) up to mu:
// Need mu >= m_c.

double QCD::M_c(double mu){
  using namespace MASS;
  if ((mu >= mass_c) && (mu <= mass_b)) { return M_q(mass_c,mass_c,mu,4) ; }
  else if ((mu > mass_b) && (mu <= mass_t)) { return M_q(M_c(mass_b),mass_b,mu,5); }
  else { return M_q(M_c(mass_t),mass_t,mu,6); }
}
*/



/* From Vegas.C: It is necessary to supply a random number generator.
  ran() gives the next random number and ran(n) initializes the sequence 
  when n is a negative integer.  */

//inline double ran(int n=0) {return ran2(n);}

//inline int signum(double a){return (a < 0 ? -1: 1);}

//==========================================================
// Basic functions of s_{ij}:

// The L_i and Ls_i functions.
/*
complex QCD::Clog(double s1, double s2){  // complex log of a ratio, s1/s2
 complex temp = log(ABS(s1/s2));
 if (s1 > 0) { temp = temp - I * PI; }
 if (s2 > 0) { temp = temp + I * PI; }
 return temp;
}

complex QCD::Clog1(double s){   // complex log of a single s
 complex temp = log(ABS(s));
 if (s > 0) { temp = temp - I * PI; }
 return temp;
}

complex QCD::L0(double s1, double s2){ 
  double r = s1/s2;
  return Clog(s1,s2)/(1.-r);
}

complex QCD::L1(double s1, double s2){ 
  double r = s1/s2;
  return (Clog(s1,s2)+1.-r)/(1.-r)/(1.-r);
}

complex QCD::L2(double s1, double s2){ 
  double r = s1/s2;
  return (Clog(s1,s2)-(r-1./r)/2.)/(1.-r)/(1.-r)/(1.-r);
}

// Li_2(1-r), for r = s1/s2:

complex QCD::CLi2r(double s1, double s2){
  double r = s1/s2;  
  return li2(1.-r) - log(ABS(1.-r)) * I * imag(Clog(s1,s2));
}

complex QCD::Lsm1(double s1, double s2, double s3, double s4){
 return CLi2r(s1,s2) + CLi2r(s3,s4) + Clog(s1,s2)*Clog(s3,s4) - PISQ6;
}

complex QCD::Ls0(double s1, double s2, double s3, double s4){
 double r1 = s1/s2;
 double r2 = s3/s4; 
 return Lsm1(s1,s2,s3,s4)/(1.-r1-r2);
}

complex QCD::Ls1(double s1, double s2, double s3, double s4){
 double r1 = s1/s2;
 double r2 = s3/s4; 
 return ( Ls0(s1,s2,s3,s4) + L0(s1,s2) + L0(s3,s4) )/(1.-r1-r2);
}

complex QCD::Ls2(double s1, double s2, double s3, double s4){
 double r1 = s1/s2;
 double r2 = s3/s4; 
 return ( Ls1(s1,s2,s3,s4) + 0.5 * ( L1(s1,s2) + L1(s3,s4) ) )/(1.-r1-r2);
}

complex QCD::Ls3(double s1, double s2, double s3, double s4){
 double r1 = s1/s2;
 double r2 = s3/s4; 
 return ( Ls2(s1,s2,s3,s4) + 1./3. * ( L2(s1,s2) + L2(s3,s4) ) 
          - 1./6. * (1./r1+1./r2) )/(1.-r1-r2);
}
*/
