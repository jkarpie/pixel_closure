#ifndef __chebyshev__
#define __chebyshev__
#include <cmath>
#include "math/complex.hh"
#include "Vlumifns.hh"

namespace cheb {

  extern int init(double mu, collider c);
  extern double Lum(double x);

  extern int cheb_approx_borel(double x, double *coeff_borel, unsigned int N_plus=10);
  extern int cheb_approx_borel_log1z(double x, double *coeff_borel, unsigned int N_plus=10);
  extern int cheb_approx_luminosity(double *coeff_lum, unsigned int N_lum=22, double beta=5., double gamma=6.);
  extern int cheb_approx_luminosity_log(double z_min, double *coeff_lum, unsigned int N_lum=15);

  extern int cheb_approx_borel_rap(double Y, double x, double *coeff_borel, unsigned int N_plus=15);
  extern int cheb_approx_borel_rap_BNX(int pm, double Y, double x, double *coeff_borel, unsigned int N_plus=15);
  extern int cheb_approx_luminosity_rap(double Y, double *coeff_lum, unsigned int N_lum=20, double beta=5., double gamma=6.);
  extern int cheb_approx_luminosity_rap_log(double Y, double z_min, double *coeff_lum, unsigned int N_lum=15);

};








#endif
