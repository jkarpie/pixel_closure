/*======================================================================
 LO, NLO, NNLO TOTAL CROSS SECTION distributions for 
      p p(bar) -> q qbar (q) -> (Z,gamma^*) + X,
                  q g -> (Z,gamma^*) + q + X
                  g g -> (Z,gamma^*) + X
      p p(bar) -> q qbar -> DY + X,
 NNLO formulae from Hamberg, van Neerven, & Matsuura
 ====================================================================*/

#include <iomanip>
#include "QCD_EW.hh"
#include "math/NAClasses.hh"
#include "math/DClasses.hh"
#include "LHAPDF_interface.hh"
#include "totfns.hh"
#include "vtot.hh"

using namespace std;

namespace vtot {
  double E_CM;         // hadron-hadron center-of-mass energy
  double Q, muR, muF;  // DY-mass; renormalization & factorization scales
  double muRrel, muFrel;  // global muR/Q, muF/Q (needed to do M (Q) integral)
  double tau;
  double asR;
  double alphat;  // local value of alpha_QED(Q)
  bool alpha_run;
  double Nf;  // Nf = number of light quarks flavors; should ~ depend on Q.
  double Ml, Mu;
  collider coll;
  exchange exch_particles;
  int ranseed = -1;
  int f_NNLO_only;  // fudge parameter to isolate NNLO terms
  // normally should be 1
  // Set to 0 for only the NNLO hard cross section terms
  int f_quiet = 0; // Set to 1 to suppress intermediate printing by setV().

  int order_flag;

/*================================================================
 The full (NLO, NNLO) DY total calculation divides up into 2 pieces:
 1) A Born kinematics piece (Born), with only DY in final state, and
  proportional to delta(1-z).
 2) A boosted Born kinematics pieces (boost).
=================================================================*/

/*=================================================================
  The overall q qbar -> DY normalization:
  The "Born-level" partonic cross section in pb is sigma_DY_0.
  It omits the quark charges, which will be supplied elsewhere.
  (Now sigma_DY_0 is factored out front of everything.)
  The "2/M" normalization gives d sigma/dM.                     */

  double sigma_DY_0(double M, double alpha){
    return GeV2pb * 2./M * 4.*PI*alpha*alpha/3./QCD::N_c /M/M ;
  }

  // Total prefactor:
  double DY_prefactor(double M, double alpha){
    return sigma_DY_0(M,alpha) * M*M/E_CM/E_CM;
  }
  double DY_prefactor(){
    return sigma_DY_0(Q,alphat) * Q*Q/E_CM/E_CM;
  }


  // set random number generator seed
  int SetSeed(int n) {
    ranseed = n;
    return 1;
  }

  int init(double CM_energy, collider c, exchange exch, bool flag_quiet) {
    PDF::check_initialization();
    f_quiet = flag_quiet;

    coll = c;
    exch_particles = exch;
    E_CM = CM_energy;

    f_NNLO_only = 1; // Set f_NNLO_only = 0 (1)  for NNLO terms only (LO+NLO+NNLO)
    lumi::compute_all(f_quiet);

    //alphat = 1./128.;   // USE FOR ALL Z/W COMPARISONS WITH FRANK!!!
    alphat = EW::alpha_em_Z;   // Z pole value
    //alphat = 1./132.1;  // Used for fxd. tgt. M=8 GeV in  hep-ph/0306192
    //alphat = EW::alpha_em;  // Zero energy value 1/137
    //alphat = EW::alpha_QED(Q);   // Dixon running QED coupling, better for low-mass

    if(ranseed < 0) SetSeed(0);
    PrintInfo();
    return 1;
  }

  int PrintInfo() {
    if(!f_quiet) {
      //cout << " enter random number seed: "; 
      //cin >> ranseed;
      //ran(-ranseed);   // initialize random number generator
      cout << " ranseed =         " << ranseed << endl; 
      cout << " E_CM =            " << E_CM << " GeV" << endl;
      cout << " collider =        " << coll << "  (1 = pp;  2 = ppbar)"  << endl; 
      cout << " alpha_s(M_Z) =    " << QCD::alphaZ << endl; 
      cout << " 1/alpha_QED =     " << 1./alphat << endl; 
    }
    return 1;

  }

  int set_variables(double x, double muR_Q_ratio, double muF_Q_ratio) {
    tau = x;//Q*Q/E_CM/E_CM;
    Q = E_CM*sqrt(tau);
    muF = Q * muF_Q_ratio;
    muR = Q * muR_Q_ratio;  // ren. & fact. scales
    Nf = QCD::nf_of_mu(muR);  // Number of light quark flavors in hard cross section:
    asR = PDF::alphas_PDF(muR)/M_PI;  // ren. & fact. scales
    lumi::setV(exch_particles,Q,alphat,Nf,f_quiet);
    PrintCurrentInfo();
    return 1;
  }

  int PrintCurrentInfo() {
    if(!f_quiet) {
      //cout << " order_flag =      " << order_flag << endl; 
      cout << " x =               " << tau << endl;
      cout << " Q =               " << Q  << " GeV" << endl
	   << " muR/Q =           " << muR/Q << endl
	   << " muF/Q =           " << muF/Q << endl; 
      cout << " Nf =              " << Nf << endl
	   << " NFf =             " << lumi::NFf(int(Nf)) << endl;
      cout << " alpha_s(muR)/Pi = " << asR << endl; 
      cout << " DY prefactor =    " << DY_prefactor(Q,alphat) << endl;
    }
    return 1;
  }

  double x_distr_lo(double x, double muR_Q_ratio, double muF_Q_ratio) {
    order_flag = 0;
    set_variables(x, muR_Q_ratio, muF_Q_ratio);
    DVector cross_section = int_y();
    return cross_section[0];
  }
  double x_distr_nlo(double x, double muR_Q_ratio, double muF_Q_ratio) {
    order_flag = 1;
    set_variables(x, muR_Q_ratio, muF_Q_ratio);
    DVector cross_section = int_y();
    return cross_section[0];
  }
  double x_distr_nnlo(double x, double muR_Q_ratio, double muF_Q_ratio) {
    order_flag = 2;
    set_variables(x, muR_Q_ratio, muF_Q_ratio);
    DVector cross_section = int_y();
    return cross_section[0];
  }
  double x_distr_lo() {
    order_flag = 0;
    DVector cross_section = int_y();
    return cross_section[0];
  }
  double x_distr_nlo() {
    order_flag = 1;
    DVector cross_section = int_y();
    return cross_section[0];
  }
  double x_distr_nnlo() {
    order_flag = 2;
    DVector cross_section = int_y();
    return cross_section[0];
  }
  double mass_integrated_cross_section_lo(double M_min, double M_max, bool run) {
    order_flag = 0;
    alpha_run = run;
    Ml = M_min;
    Mu = M_max;
    DVector cross_section = int_y_M();
    return cross_section[0];
  }
  double mass_integrated_cross_section_nlo(double M_min, double M_max, bool run) {
    order_flag = 1;
    alpha_run = run;
    Ml = M_min;
    Mu = M_max;
    DVector cross_section = int_y_M();
    return cross_section[0];
  }
  double mass_integrated_cross_section_nnlo(double M_min, double M_max, bool run) {
    order_flag = 2;
    alpha_run = run;
    Ml = M_min;
    Mu = M_max;
    DVector cross_section = int_y_M();
    return cross_section[0];
  }

  int SetCollider(collider c) { coll=c; return 1; }
  int SetECM(double CM_energy) { E_CM = CM_energy; return 1; }
  int SetS(double s) { E_CM = sqrt(s); return 1; }
  int SetQ(double q) {
    Q = q;
    tau = Q*Q/E_CM/E_CM;
    return 1;
  }
  int Setx(double x) {
    tau = x;
    Q = E_CM*sqrt(tau);
    return 1;
  }
  int SetScales(double mu_R, double mu_F) {
    muR = mu_R;
    muF = mu_F;
    Nf = QCD::nf_of_mu(muR);  // Number of light quark flavors in hard cross section:
    asR = PDF::alphas_PDF(muR)/M_PI;  // ren. & fact. scales
    return 1;
  }
  int SetScalesRatio(double muR_Q_ratio, double muF_Q_ratio) {
    SetScales(Q * muR_Q_ratio, Q * muF_Q_ratio);
    return 1;
  }
  void SetV(exchange E) {
    lumi::setV(E,Q,alphat,Nf,int(f_quiet));
  }
  int SetOrder(int order) { order_flag=order; return 1; }
  int SetAlphaQED(double alpha) { alphat = alpha; return 1; }
  int SetAlphaQCD(double alpha) { asR = alpha/M_PI; return 1; }
  int SetNf(int nf) { Nf = nf; return 1; }
  int SetNNLOonly(bool flag) {
    if(flag) f_NNLO_only = 0;
    else f_NNLO_only = 1;
    return 1;
  }
  int SetQuiet(bool flag_quiet) { f_quiet=flag_quiet; return 1; }

  // Get... functions
  collider GetCollider() { return coll; }  // Get collider: pp (or LHC) or ppbar (or Tevatron)
  double GetECM() { return E_CM; }  // Get the hadron c.m.s. energy, sqrt(S)
  double GetS() { return E_CM*E_CM; }  // Get the hadron c.m.s. energy squared, S
  double GetQ() { return Q; }  // Final state invariant mass
  double Getx() { return tau; }  // Get the value of hadronic x = Q^2/S = (Q/E_CM)^2
  double GetFactScale() { return muF; }  // Factorization scale
  double GetRenormScale() { return muR; }  // Renormalization scale
  double GetFactScaleRatio() { return muF/Q; }  // Factorization scale ratio wrt Q
  double GetRenormScaleRatio() { return muR/Q; }  // Renormalization scale ratio wrt Q
  double GetAlphaQED() { return alphat; }  // Get the value of alpha_QED
  double GetAlphaQCD() { return asR*M_PI; }  // Get the value of alpha_QCD 
  int GetOrder() { return order_flag; }  // Get the order k for N^k LO computation
  int GetNf() { return int(Nf); }  // Set number of light flavours.



//================================================================
// The Born-type terms in the integrand.

double Born_integrand(double y){
  //double tau = Q*Q/E_CM/E_CM;
  //double asR = alpha_s(muR)/PI;
  double x1 = sqrt(tau) * exp(y);
  double x2 = sqrt(tau) * exp(-y);
  if ((x1 >= 1.) || (x2 >= 1.)){ return 0.; }
  double LO_term = 1.;
  double NLO_term = SV_Born_NLO(muF/Q);
  double NNLO_term = SV_Born_NNLO(Nf,muF/Q,muR/Q);
  double Born_term = 0.;;
  if (order_flag == 0) {
    Born_term = LO_term; }
  if (order_flag == 1) {
    Born_term = LO_term + asR * NLO_term; }
  if (order_flag == 2) {
    if (f_NNLO_only == 0) { Born_term = asR*asR * NNLO_term; }
    else { Born_term = LO_term + asR * NLO_term + asR*asR * NNLO_term; }
  }
  return Born_term * lumi::qqbar_lumi(x1,x2,muF,DY,coll);
}

//================================================================
// The boost-type terms in the integrand.  
// Here NLO and NNLO are combined.
// Form after change of variables to x1h, zh (much better convergence):

double boost_integrand(double x1h, double zh){
  using namespace lumi;
  double c, x1, d, z, x2, x20, Jx1hzh, lumiz, lumi0,  
         qbarq_BC_lumiz, qbarq_NFf_lumiz, qbarq_ax_lumiz,
         gq_lumiz, qg_lumiz, gg_lumiz,
         qq_11_lumiz, qq_22_lumiz, qq_12_lumiz, qq_12_ax_lumiz,
         qq_CE1_lumiz, qq_CF_lumiz, main_ans_NLO, main_ans_NNLO;
  //asR = alpha_s(muR)/PI; 
  //tau = Q*Q/E_CM/E_CM;
  c = -log(tau);    x1 = exp(-c*x1h) ;
  d = c + log(x1);   z = exp(-d*zh);  x2 = tau/x1/z;  x20 = tau/x1;
  Jx1hzh = c * d * z ;
  lumiz = qqbar_lumi(x1,x2,muF,DY,coll); 
  qg_lumiz = qg_lumi(x1,x2,muF,coll);
  gq_lumiz = gq_lumi(x1,x2,muF,coll);
  // for z = 1 subtraction (q qbar only):
  lumi0 = qqbar_lumi(x1,x20,muF,DY,coll);
  main_ans_NLO = Jx1hzh * (
  // qqbar
     ( SV_boost_NLO(z,muF/Q) + qbarq_hard_NLO(z,muF/Q) ) * lumiz/z
   - ( SV_boost_NLO(z,muF/Q) + SV_boost_NLOe(x20,muF/Q) ) * lumi0
  // qg
   + qg_NLO(z,muF/Q) * (gq_lumiz + qg_lumiz)/z 
                          ) ;
  if (order_flag == 1) { return asR * main_ans_NLO ; }
  else if (order_flag == 2) {
    qbarq_BC_lumiz = qqbar_BC_lumi(x1,x2,muF,coll); 
    qbarq_NFf_lumiz = qqbar_lumi(x1,x2,muF,gluon,coll);
    qbarq_ax_lumiz = qqbar_ax_lumi(x1,x2,muF,coll);
    gg_lumiz = gg_lumi(x1,x2,muF,coll);
    qq_11_lumiz = qq_11_lumi(x1,x2,muF,coll);
    qq_22_lumiz = qq_22_lumi(x1,x2,muF,coll);
    qq_12_lumiz = qq_12_lumi(x1,x2,muF,coll);
    qq_12_ax_lumiz = qq_12_ax_lumi(x1,x2,muF,coll);
    qq_CE1_lumiz = qq_CE1_lumi(x1,x2,muF,coll);
    qq_CF_lumiz = qq_CF_lumi(x1,x2,muF,coll);

    // SOFT TEST VERSION:
    /*
      main_ans_NNLO =
      SV_boost_NNLO_TEST(z,Nf,muF/Q,muR/Q) * z * lumiz/z
    - ( SV_boost_NNLO_TEST(z,Nf,muF/Q,muR/Q) 
	+ SV_boost_NNLOe_TEST(x20,Nf,muF/Q,muR/Q) ) * lumi0 ;
    */
    // REAL VERSION:
    main_ans_NNLO =
      // q-\bar{q}:  Note that 
      // 1) BC terms now have their own luminosity function
      // 2) CC and CD_V terms are removed to "qq".
      ( SV_boost_NNLO(z,Nf,muF/Q,muR/Q) 
	+ qbarq_NS_hard_NNLO(z,Nf,muF/Q,muR/Q) ) * lumiz/z
      - ( SV_boost_NNLO(z,Nf,muF/Q,muR/Q) 
	  + SV_boost_NNLOe(x20,Nf,muF/Q,muR/Q) ) * lumi0
      // q-\bar{q} BC terms:
      + qbarq_BC(z) * qbarq_BC_lumiz/z
      // q-\bar{q} NFf terms:
      + qbarq_NFf(z) * qbarq_NFf_lumiz/z
      + AB_ax(z) * qbarq_ax_lumiz/z  // extra axial terms for Z
      // qg:
      + ( qg_C_A(z,muF/Q,muR/Q) + qg_C_F(z,muF/Q,muR/Q) 
	  + Nf * qg_NF(z,muF/Q,muR/Q) ) // FIXED missing Nf, 11/21/2003 (LD)
      * (gq_lumiz + qg_lumiz)/z
      // gg:
      + (gg_C_A(z) + gg_C_F(z,muF/Q)) * gg_lumiz/z
      // q_i \neq q_j (or \bar{q}_j)   plus   identical quark terms:
      + qbarq_CC(z,muF/Q) * (qq_11_lumiz + qq_22_lumiz)/z 
      + qbarq_CD_V(z) * qq_12_lumiz/z
      + CD_ax(z) * qq_12_ax_lumiz/z
      + 2. * qq_CE_tot(z,muF/Q) * qq_CE1_lumiz/z
      + qq_CF(z) * qq_CF_lumiz/z
      ;
    main_ans_NNLO = Jx1hzh * main_ans_NNLO;
    if (f_NNLO_only == 0) { return asR*asR * main_ans_NNLO; }
    else { return asR * main_ans_NLO + asR*asR * main_ans_NNLO; }
  }
  else { return 0.; }
}


/*=================================================================
 For integrating over M, we need slightly different integrands:
 We have to reset the lumi-functions for a different M,
 which also requires passing along exch,alphat 
 (we assume Nf stays constant over the integration range).  */

double Born_integrand_M(double y, double M){
  Q = M;    muR = muRrel*Q;    muF = muFrel*Q;    tau = Q*Q/E_CM/E_CM;
  if(alpha_run) {
    asR = PDF::alphas_PDF(muR)/M_PI;
    // if you want to run alpha_QED here:
    // alphat = EW::alpha_QED(Q); 
  }
  lumi::setV(exch_particles,M,alphat,Nf,1);
  return DY_prefactor(Q,alphat) * Born_integrand(y);
}

double int_NLO_M(double x1h, double zh, double M){
  Q = M;    muR = muRrel*Q;    muF = muFrel*Q;    tau = Q*Q/E_CM/E_CM;
  order_flag = 1;
  if(alpha_run) {
    asR = PDF::alphas_PDF(muR)/M_PI;
    // if you want to run alpha_QED here:
    // alphat = EW::alpha_QED(Q); 
  }
  lumi::setV(exch_particles,M,alphat,Nf,1);
  return DY_prefactor(Q,alphat) * boost_integrand(x1h,zh);
}

double int_NNLO_M(double x1h, double zh, double M){
  Q = M;    muR = muRrel*Q;    muF = muFrel*Q;    tau = Q*Q/E_CM/E_CM;
  f_NNLO_only = 0;
  order_flag = 2;
  if(alpha_run) {
    asR = PDF::alphas_PDF(muR)/M_PI;
    // if you want to run alpha_QED here:
    // alphat = EW::alpha_QED(Q); 
  }
  lumi::setV(exch_particles,M,alphat,Nf,1);
  //return DY_prefactor(Q,alphat) * asR * asR  * int_NNLO(y,ys,z);
  return DY_prefactor(Q,alphat) * boost_integrand(x1h,zh);
}


//============================================================
/* !!!!! MARCO
   The integration in Y is not optimal, since is done in the range [-infty, infty]
   and the integrand is set to be zero outside the physical region.
   I suggest to use instead either pseudorapidity or a remapping of xi.
   .......................
 */
class surf: public Surface{
public:
  int n;
  surf(int m): n(m){}

  double surface(DVector & x){
    double xi = x[1] ;
    double ytemp = 0.5*log(xi/(1-xi));
    double Jy = 0.5/xi/(1.-xi);
    // Integrands for total cross section:
    // introduce change of variables to do integral over y:
    // let xi = (1+tanh(y))/2,  y = ln(xi/(1-xi))/2.
    // xi = x[1] already runs from 0 to 1.
    if (n==1) {  // integrate Born_integrand over y
      return Jy * Born_integrand(ytemp) ; }
    if (n==2) { 
      // OLD way of doing y integration:
      //     return Jy * boost_integrand_OLD(ytemp, x[2]) ; 
      // integrate boost integrand over y 
      // (but we actually use x[1] = x1h, x[2] = zh \in [0,1]):
      return boost_integrand(x[1], x[2]) ; 
    }
    // Integrands for integration over a range in M:
    // mapping of M range containing Z pole:
    double Gamma_Z = EW::Gamma_Z; 
    double u_l = atan((Ml*Ml-MASS::mass_Z*MASS::mass_Z)/Gamma_Z/MASS::mass_Z);
    double u_u = atan((Mu*Mu-MASS::mass_Z*MASS::mass_Z)/Gamma_Z/MASS::mass_Z);
    double u = u_l + (u_u-u_l) * x[2];
    double M = sqrt(MASS::mass_Z*MASS::mass_Z + Gamma_Z*MASS::mass_Z*tan(u));
    double JM = (u_u-u_l) * Gamma_Z*MASS::mass_Z*(1.+tan(u)*tan(u))/2./M;
    // uniform mapping of M range:
    //    double M = Ml + (Mu-Ml) * x[1];   double JM = Mu-Ml; 
    if (n==6) { // integrate Born integrand over M:
      return Jy * JM * Born_integrand_M(ytemp,M); }
    if (n==7) { // integrate NLO integrand over M:
      return JM * int_NLO_M(x[1], x[3], M) ; }
    if (n==8) { // integrate NNLO integrand over M:
      return JM * int_NNLO_M(x[1], x[3], M) ; }
    else return 0;
  }

};

// "sqint" runs a VEGAS integration for function number n_f,
// over a n-dimensional unit square (hypercube), using surface "surf".
// It returns "integral, sd, chi2" as a DVector:

DVector sqint(int n_f, int n_dim, int n_call, int n_adapt, int n_run, 
              int ranseed){
  double integral, sd, chi2; 
  DVector temp_out(0,2);
  DVector x1(1,n_dim);  DVector x2(1,n_dim);
  for (int i=1; i <= n_dim; i++) {
     x1[i] = 0.;   x2[i] = 1.;
  }
  VegasGrid V(x1,x2,n_call,ranseed);  // last argument is "ranseed"
  surf Sfc(0);
  V.reset(n_call);
  Sfc.n = n_f;
  if (f_quiet==0) cout << "adapting grid"<<endl;
  integral = Sfc.vegas(V,n_adapt,sd,chi2);
  if (f_quiet==0) {
    cout << setw(8) << setprecision(8) << integral 
	 << "  pm  " << sd << "  chi2 = " << chi2 << endl;
    cout << "evaluating integral" <<endl;
  }
  integral = Sfc.vegasint(V,n_run,sd,chi2);
  if (f_quiet==0) {
    cout << setw(8) << setprecision(8) << integral 
	 << "  pm  " << sd << "  chi2 = " << chi2 << endl;
    cout << endl;
  }
  temp_out.fill(3,integral,sd,chi2);
  return temp_out;
}

// Routine to integrate over y, from -infinity to +infinity.

DVector int_y(){
  PDF::check_initialization();
  DVector result(0,1);
  DVector Born_int(0,2);
  DVector boost_int(0,2);
  double prefactor = DY_prefactor(Q,alphat);
  if (order_flag == 0) {
    if (abs(Born_integrand(0.2)) < 1.0e-16){
      if(f_quiet==0) cout << "   Setting Born terms to 0, since f_qqbar = 0  " << endl;
      Born_int.fill(3,0.,0.,0.);
    }
    else {
      if(f_quiet==0) cout << "   Now integrating Born terms " << endl;
      Born_int = sqint(1,1,1000,10,20,ranseed);
      if(f_quiet==0) {
	cout << " LO integral =  " << setw(8) << setprecision(8)
	     << prefactor*Born_int[0] << "  pm  " << prefactor*Born_int[1]
	     <<  ";    chi^2 =  " << Born_int[2] << endl << endl;
      }
      result.fill(2,prefactor*Born_int[0],prefactor*Born_int[1]); 
    } 
  }
  else if ((order_flag == 1) || (order_flag == 2)) {
    if (abs(Born_integrand(0.2)) < 1.0e-16){
      if(f_quiet==0) cout << "   Setting Born terms to 0, since f_qqbar = 0  " << endl;
      Born_int.fill(3,0.,0.,0.);
    }
    else {
      if(f_quiet==0) cout << "   Now integrating Born terms " << endl;
      Born_int = sqint(1,1,1000,10,20,ranseed);
      if(f_quiet==0) {
	cout << " Born-type integral =  " << setw(8) << setprecision(8)
	     << prefactor*Born_int[0] << "  pm  " << prefactor*Born_int[1]
	     <<  ";    chi^2 =  " << Born_int[2] << endl << endl;
      }
    }
    if(f_quiet==0) cout << "   Now integrating boost terms " << endl;
    boost_int = sqint(2,2,3000,10,40,ranseed);
    if(f_quiet==0) {
      cout << " boost-type integral =  " << setw(8) << setprecision(8)
	   << prefactor*boost_int[0] 
	   << "  pm  " << prefactor*boost_int[1]
	   <<  ";    chi^2 =  " << boost_int[2] << endl 
	   << endl;
    }
    double total_int = prefactor * ( Born_int[0] + boost_int[0] );
    double total_int_error = prefactor * sqrt( Born_int[1]*Born_int[1] 
					       + boost_int[1]*boost_int[1] ) ;
    if (order_flag == 1) {
      if(f_quiet==0) {
	cout << " NLO integral =  " << setw(8) << setprecision(8)
	     << total_int << "  pm  " << total_int_error  
	     << endl << endl;
      }
    }
    else {
      if(f_quiet==0) {
	cout << " NNLO integral =  " << setw(8) << setprecision(8)
	     << total_int << "  pm  " << total_int_error  
	     << endl << endl;
      }
    }
    result.fill(2,total_int,total_int_error);  
  }
  return result;
}

// Scan muF = muR from mu_r_lower*Q to mu_r_upper*Q,
// with mu values uniformly spaced in log(mu), and print results:

DMatrix scan_mu(double mu_r_lower, double mu_r_upper, int n_points){
  double n_points_real = n_points;
  double step_size = log(mu_r_upper/mu_r_lower)/n_points_real;
  DMatrix resultMatrix(0,n_points,0,2);  // matrix to store unnorm. results
  for (int j = 0; j <= n_points; j++) {
     muF = Q * mu_r_lower * exp(step_size * j);
     muR = muF;
     // full result:
     DVector temp_int_y = int_y();
     resultMatrix.fillRow(j,3,muF/Q,temp_int_y[0],temp_int_y[1]);
   }

   // print absolute results again, in form convenient for copying: 
   cout << "   (muF=muR)/Q    |    d sigma/dM   |   (  error   " << endl;
   cout << "------------------------------------------------------- " << endl;
   for (int j = 0; j <= n_points; j++) {
     cout << setw(8) << setprecision(8) <<  " " << resultMatrix[j][0]
            << "       " << resultMatrix[j][1] << " "
            << "   (   " << resultMatrix[j][2]   // include errors
            << endl;
   }
   cout << endl ;
//
 return resultMatrix;
}


/* ===========================================
   Mass integration routines
   */
DVector int_y_M(){
  double total, total_error;
  //  Set relative ren/fact. factors (they are held fixed as we
  // integrate over M (Q):
  muRrel = muR/Q;   muFrel = muF/Q;
  DVector result(0,1);   
  DVector i_Born(0,2);   DVector i_NLO(0,2);  DVector i_NNLO(0,2);
// LO case
  if (order_flag == 0) { 
    if (abs(Born_integrand_M(0.2,20.)) < 1.0e-16){
      if (!f_quiet) cout << "   Setting Born terms to 0, since f_qqbar = 0  " << endl;
      result.fill(2,0.,0.); 
    }
    else {
      if (!f_quiet) cout << "   Now integrating Born terms " << endl;
      i_Born = sqint(6,2,10000,10,30,ranseed); 
      result.fill(2,i_Born[0],i_Born[1]) ;
    }
  }
// NLO case
  else if (order_flag == 1) {
    if (abs(Born_integrand_M(0.2,20.)) < 1.0e-16){
      if (!f_quiet) cout << "   Setting Born terms to 0, since f_qqbar = 0  " << endl;
      i_Born.fill(3,0.,0.,0.);
    }
    else {
      if (!f_quiet) cout << "   Now integrating Born terms " << endl;
      i_Born = sqint(6,2,5000,10,20,ranseed); 
    }
    /*
    if (abs(int_NLO_M(.03,.43,.93,20.)) < 1.0e-16) {
       if (f_quiet==0) {
         cout << "Setting NLO non-Born terms to 0, since integrand ~ 0 " << endl;
       }
       i_NLO.fill(3,0.,0.,0.);
    }
    else {
    */
    i_NLO = sqint(7,3,5000,10,30,ranseed);
    //}
    total = i_Born[0] + i_NLO[0];
    total_error = sqrt(i_Born[1]*i_Born[1] + i_NLO[1]*i_NLO[1]);
    result.fill(2,total,total_error);
  }
// NNLO case
  else {   //  order_flag = 2:
    if (f_NNLO_only == 1) {
      if (abs(Born_integrand_M(0.2,20.)) < 1.0e-16){
        if (!f_quiet) cout << "   Setting Born terms to 0, since f_qqbar = 0  " << endl;
	i_Born.fill(3,0.,0.,0.);
      }
      else {
        if (!f_quiet) cout << "   Now integrating Born terms " << endl;
        i_Born = sqint(6,2,5000,10,20,ranseed); 
      }
      /*
      if (abs(int_NLO_M(.03,.43,.93,20.)) < 1.0e-16) {
        if (f_quiet==0) {
        cout <<"Setting NLO non-Born terms to 0, since integrand ~ 0 "<< endl;
        }
        i_NLO.fill(3,0.,0.,0.);
      }
      else {
      */
      i_NLO = sqint(7,3,5000,10,30,ranseed);
      //}
    }
    i_NNLO = sqint(8,3,20000,5,15,ranseed);
    if (f_NNLO_only == 0) {
      total = i_Born[0] + i_NNLO[0];
      total_error = sqrt(i_Born[1]*i_Born[1] + i_NNLO[1]*i_NNLO[1]);
    }
    else {
      total = i_Born[0] + i_NLO[0] + i_NNLO[0];
      total_error = sqrt( i_Born[1]*i_Born[1] + i_NLO[1]*i_NLO[1]
                                             + i_NNLO[1]*i_NNLO[1] );
    }
    result.fill(2,total,total_error);
  }
  if (f_quiet==0) {
  cout << "int_ml^Mu dM dsigma/dM =  " << result[0]
       << "   pm  " << result[1] << endl;
  }
  return result;
}


};
