#ifndef __gauss_inetgration__
#define __gauss_inetgration__

#include "complex.hh"



////////////////////////////////////////////////////////////
// INTEGRALS                                              //
////////////////////////////////////////////////////////////



namespace integration {

  extern double dgauss(double (*f)(double), double xmin, double xmax, double prec);
  extern double dgauss2(double (*f)(double), double xmin, double xmax, double prec);

  extern double dgauss(double f(double, void*), double xmin, double xmax, double prec);

  extern double dgauss(double f(double, void*), double xmin, double xmax, double prec, double par);
  extern double dgauss2(double f(double, void*), double xmin, double xmax, double prec, double par);

  extern double gauss(double f(double, void*), double xmin, double xmax, double prec, complex par);

  extern double gauss_sing(double f(double, void*), double xmin, double xmax, double prec, double par);

  extern double gauss_nonadaptive(double f(double, void*), double xmin, double xmax, double prec, double par);

  extern double gauss_inf_up(double f(double, void*), double xmin, double prec, double par);

};





#endif
