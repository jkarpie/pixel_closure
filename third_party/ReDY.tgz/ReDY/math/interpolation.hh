#ifndef __interpolation__
#define __interpolation__

#include <cmath>
#include <cstdlib>
#include <iostream>



namespace interpolation {


  //template<class y_interp>
  //extern y_interp linear(double *x_p, y_interp *y_p, unsigned int n_points, double x);
  extern double linear (double *x_p, double *y_p, unsigned int n_points, double x);
  extern double cspline(double *x_p, double *y_p, unsigned int n_points, double x);

};




#endif
