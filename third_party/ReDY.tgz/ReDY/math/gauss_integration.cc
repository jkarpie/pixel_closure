#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <gsl/gsl_integration.h>
#include "gauss_integration.hh"


using namespace std;



////////////////////////////////////////////////////////////
// INTEGRALS                                              //
////////////////////////////////////////////////////////////


double (* integration__function_)(double);
double integration__function(double x, void * p){
  return (*integration__function_)(x);
}
double (* integration__function_2_)(double);
double integration__function_2(double x, void * p){
  return (*integration__function_2_)(x);
}

double integration::dgauss(double (*f)(double), double xmin, double xmax, double prec){
  double result, error;
  integration__function_=f;
  gsl_function F;
  gsl_integration_workspace * w = gsl_integration_workspace_alloc (100000);
  F.function=integration__function;
  F.params=0;
  gsl_integration_qag (&F, xmin, xmax, 0, prec, 100000, 6, w, &result, &error);
  gsl_integration_workspace_free (w);
  return result;
}

double integration::dgauss2(double (*f)(double), double xmin, double xmax, double prec){
  double result, error;
  integration__function_2_=f;
  gsl_function F;
  gsl_integration_workspace * w = gsl_integration_workspace_alloc (100000);
  F.function=integration__function_2;
  F.params=0;
  gsl_integration_qag (&F, xmin, xmax, 0, prec, 100000, 6, w, &result, &error);
  gsl_integration_workspace_free (w);
  return result;
}

double integration::dgauss(double f(double, void*), double xmin, double xmax, double prec){
  double result, error;
  gsl_function F;
  gsl_integration_workspace * w = gsl_integration_workspace_alloc (100000);
  F.function=f;
  F.params=0;
  gsl_integration_qag (&F, xmin, xmax, 0, prec, 100000, 6, w, &result, &error);
  gsl_integration_workspace_free (w);
  return result;
}

double integration::dgauss(double f(double, void*), double xmin, double xmax, double prec, double par){
  double result, error;
  gsl_function F;
  gsl_integration_workspace * w = gsl_integration_workspace_alloc (100000);
  F.function=f;
  F.params=&par;
  gsl_integration_qag (&F, xmin, xmax, 0, prec, 100000, 6, w, &result, &error);
  gsl_integration_workspace_free (w);
  return result;
}
double integration::dgauss2(double f(double, void*), double xmin, double xmax, double prec, double par){
  double result, error;
  gsl_function F;
  gsl_integration_workspace * w = gsl_integration_workspace_alloc (100000);
  F.function=f;
  F.params=&par;
  gsl_integration_qag (&F, xmin, xmax, 0, prec, 100000, 6, w, &result, &error);
  gsl_integration_workspace_free (w);
  return result;
}

double integration::gauss(double f(double, void*), double xmin, double xmax, double prec, complex par){
  double result, error;
  gsl_function F;
  gsl_integration_workspace * w = gsl_integration_workspace_alloc (100000);
  F.function=f;
  F.params=&par;
  gsl_integration_qag (&F, xmin, xmax, 0, prec, 100000, 6, w, &result, &error);
  gsl_integration_workspace_free (w);
  return result;
}

double integration::gauss_sing(double f(double, void*), double xmin, double xmax, double prec, double par){
  double result, error;
  gsl_function F;
  gsl_integration_workspace * w = gsl_integration_workspace_alloc (100000);
  F.function=f;
  F.params=&par;
  gsl_integration_qags (&F, xmin, xmax, 0, prec, 100000, w, &result, &error);
  gsl_integration_workspace_free (w);
  return result;
}

double integration::gauss_nonadaptive(double f(double, void*), double xmin, double xmax, double prec, double par){
  double result, error;
  size_t neval;
  gsl_function F;
  F.function=f;
  F.params=&par;
  gsl_integration_qng (&F, xmin, xmax, 0, prec, &result, &error, &neval);
  return result;
}

double integration::gauss_inf_up(double f(double, void*), double xmin, double prec, double par){
  double result, error;
  gsl_function F;
  gsl_integration_workspace * w = gsl_integration_workspace_alloc (100000);
  F.function=f;
  F.params=&par;
  gsl_integration_qagiu (&F, xmin, 0, prec, 100000, w, &result, &error);
  gsl_integration_workspace_free (w);
  return result;
}










