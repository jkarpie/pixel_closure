#ifndef THBASICS_H
#define THBASICS_H

/*  header file for general purpose routines for theory classes,
       incorporating the utility routines from
     Numerical Recipes, by Press, Teukolsky, Vetterling, and Flannery
             C version,  2nd ed  1992
                     modified for C++ by MEP               */


#include <cmath>
#include <cstdlib>
#include <iostream>
//#include <stdarg.h>

const double PI = M_PI;
const double E = M_E;

const double TINY =  1.0e-30;


template<class T>
inline T SQR(T a){return a*a;}

extern double ABS(double a); 
extern int    ABS(int a);

extern double MIN (double a,double b);
extern double MAX (double a, double b);
extern double SIGN(double a, double b);

extern int MIN (int a, int b);
extern int MAX (int a, int b);
extern int SIGN(int a, int b);

extern int INT(double a);
extern bool isINT(double a);

extern void therror(char error_text[]);
/*        standard error handler  */


#endif    /*  THBASICS_H  */

