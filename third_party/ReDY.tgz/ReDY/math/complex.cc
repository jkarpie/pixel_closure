#include "complex.hh"
#include <gsl/gsl_sf_gamma.h>


// stream operators
istream & operator >> (istream& is, complex & a){
   return is >> a.r  >> a.i;
}
ostream & operator << (ostream & os, const complex & a){
   return os << "( "<< a.r <<" + i " << a.i << " )" ;
}


complex Gamma(complex z){
  gsl_sf_result r, arg;
  gsl_sf_lngamma_complex_e(real(z),imag(z),&r,&arg);  // causes problems in (x,0), x<0
  return polar(exp(r.val),arg.val);
}

complex logGamma(complex z){
  gsl_sf_result r, arg;
  gsl_sf_lngamma_complex_e(real(z),imag(z),&r,&arg);  // causes problems in (x,0), x<0
  return complex(r.val,arg.val);
}
