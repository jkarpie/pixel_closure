#include <iomanip>
#include <vector>
#include <algorithm>
#include "interpolation.hh"
#include <gsl/gsl_interp.h>
#include <gsl/gsl_spline.h>


using namespace std;



//template<class y_interp>
//y_interp interpolation::linear(double *x_p, y_interp *y_p, unsigned int n_points, double x) {
double interpolation::linear(double *x_p, double *y_p, unsigned int n_points, double x) {
  // maybe in the future add a sorting routine for x_p
  if(n_points < 2) {
    cerr << "Interpolation: number of points less than 2" << endl;
    exit(-6);
  }
  if(x==x_p[0]) return y_p[0];
  if(x==x_p[n_points-1]) return y_p[n_points-1];
  if(x<x_p[0] || x>x_p[n_points-1]) {
    cerr << "Interpolation: x = " << setprecision(15) << x << " out of range [ "
	 << setprecision(15) << x_p[0] << " , " << setprecision(15) << x_p[n_points-1] << " ]" << endl << endl;
    exit(-5);
  }

  unsigned int _i=0;
  vector<double> vx_p(x_p,x_p+n_points);
  vector<double>::iterator low_val;
  //sort (vx_p.begin(), vx_p.end());
  low_val = lower_bound (vx_p.begin(), vx_p.end(), x);
  _i = int(low_val - vx_p.begin());

  if(_i>n_points-2) _i = n_points-2;
  return y_p[_i] + (x-x_p[_i])*(y_p[_i+1]-y_p[_i])/(x_p[_i+1]-x_p[_i]);
}


double interpolation::cspline(double *x_p, double *y_p, unsigned int n_points, double x) {
  gsl_interp_accel *acc = gsl_interp_accel_alloc ();
  gsl_spline *spline = gsl_spline_alloc (gsl_interp_cspline, n_points);
  gsl_spline_init (spline, x_p, y_p, n_points);
  double val = gsl_spline_eval (spline, x, acc);
  gsl_spline_free (spline);
  gsl_interp_accel_free (acc);
  return val;
}

