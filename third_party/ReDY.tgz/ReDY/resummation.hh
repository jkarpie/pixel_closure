#ifndef __resummation__
#define __resummation__

#include "Vlumifns.hh"
#include "math/complex.hh"

namespace resumm {

  enum {
    LL=0,
    NLL=1,
    NNLL=2
  };
  enum {
    LO=0,
    NLO=1,
    NNLO=2
  };

  // set the kind of logs are used by the Borel prescription
  // (see M.Bonvini, S.Forte, G.Ridolfi, NPB 847 (2011) 93-159, arXiv:1009.5691 [hep-ph]):
  // type = 0  ->  eq. (3.23)
  // type = 1  ->  eq. (3.29)
  // type = 2  ->  eq. (3.21)
  extern int SetBorelType(int type);

  // it sets if the constant terms must be added or not, see discussion in Sect. 2.1.5.1 of
  // M.Bonvini, arXiv:xxxx.xxxx [hep-ph]  (PhD thesis)
  // if set to 1, the constants are added to get types 0 and 1 as NPB 847; they are added to the MP like logs as well.
  // if set to 0, the pure prescriptions defined in my thesis are used, in particular
  // type = 0  ->  eq. (2.1.58)
  // type = 1  ->  eq. (2.1.62)
  // type = 2  ->  eq. (2.1.48) (coincides with (3.21) of NPB 874)
  extern int SetAddConstants(bool);

  // choose to use the luminosity by Becher, Neubert, Xu
  // eq. (4.44) of M.Bonvini, S.Forte, G.Ridolfi NPB 847 (2011) 93-159, arXiv:1009.5691 [hep-ph]
  // only applicable to rapidity distributions
  extern int SetBNXluminosity(bool);


  // Initializations
  extern int InitFromVtot();
  extern int InitFromVrap();
  extern int Init(double S, double alpha_s, double muF_q_ratio, double muR_q_ratio, int n_f, collider coll);

  extern int DontUseApproxPDFsForBorelPrescription(bool use=true);
  extern int DontUseApproxPDFsForMinimalPrescription(bool use=true);


  extern double Borel_tot(double x, double C, unsigned int log_order=1, unsigned int match_order=1,
			  unsigned int N_cheb=10);
  extern double Minimal_tot(double x, unsigned int log_order=1, unsigned int match_order=1,
			    unsigned int N_cheb=15, int method=1, double beta=7., double gamma=3.);
  extern double Borel_rap(double Y, double x, double C, unsigned int log_order=1, unsigned int match_order=1,
			  unsigned int N_cheb=15);
  extern double Minimal_rap(double Y, double x, unsigned int log_order=1, unsigned int match_order=1,
			    unsigned int N_cheb=15, int method=1, double beta=7., double gamma=3.);

};




#endif
