#include <iostream>
#include <stdio.h>
#include <sys/time.h>

#include "math/gauss_integration.hh"
#include "LHAPDF_interface.hh"  // interface with LHAPDF
#include "vrap.hh"              // Rapidity distributions
#include "vtot.hh"              // Integrated cross-section

using namespace std;



double func(double x){
  return 6.*x;
}
double func2(double x){
  return integration::dgauss(func,0.,x,1e-5);
}



int main(){


  // complex numbers test
  complex c(2.,3.);
  cout << "------------------------------" << endl;
  cout << "---- Complex Numbers Test ----" << endl;
  cout << "------------------------------" << endl;
  cout << "Gamma" << c << "  =  "<< Gamma(c) << endl;
  cout << "The above string should be:" << endl;
  cout << "Gamma( 2 + i 3 )  =  ( -0.0823953 + i 0.0917743 )" << endl;
  cout << "------------------------------" << endl << endl << endl;


  // Random number generator test
  cout << "Random number: "<< ran1(-time(0)) << endl << endl << endl;


  //////////////////////////
  // INTEGRATION TEST
  double var=4.;
  cout << "------------------------------" << endl;
  cout << "--- Gauss Integration Test ---" << endl;
  cout << "------------------------------" << endl;
  cout << "  " << var << "^3 = " << var*var*var << " = " << integration::dgauss2(func2,0.,var,1.e-5) << "     Right?" << endl;
  cout << "------------------------------" << endl << endl << endl;
  //////////////////////////



  //--------------------------------
  //  LHAPDF initialization 
  //--------------------------------
  // Refer to the LHAPDF library ( http://projects.hepforge.org/lhapdf/ )
  // for a detailed list of available pdf's sets.

  PDF::pdf_init("NNPDF21_100",0,LOWKEY);
  //PDF::pdf_init("cteq66",0,LOWKEY);
  //PDF::pdf_init("mrst2004nnlo");
  //PDF::pdf_init("mrst2001nlo");



  cout << endl << " Running ...  (it takes few seconds)" << endl;


  //----------------------------
  //  VRAP & VTOT test
  //----------------------------
  double CM_energy = 7000.;    // in GeV (LHC)
  collider coll = pp;          // can be either pp (or LHC) or ppbar (or Tevatron)
  exchange exch = gamma_only;  // set which virtual particle(s) is (are) considered. Possibilities are:
                               // - for neutral final state: gamma_only, Zgamma_interf, Z_only, Zgamma (=gamma_only+Zgamma_interf+Z_only)
                               // - for charged final state: Wplus, Wminus
  double Q = MASS::mass_Z;     // in GeV, final state DY pair invariant mass 
  double muR_Q_ratio = 1.;     // muR/Q
  double muF_Q_ratio = 1.;     // muF/Q
  double x = SQR(Q/CM_energy); // useful variable x; is dependent on Q and CM_energy
  bool quiet = 1;              // flag for output verbosity: 0=verbose, 1=quiet


  // Initialize VTOT stuff:
  vtot::init(CM_energy, coll, exch, quiet);
  double xd_lo   = vtot::x_distr_lo  (x,muR_Q_ratio,muF_Q_ratio);

  // Initialize VRAP stuff:
  vrap::init(CM_energy, Q, coll, gamma_only, muR_Q_ratio, muF_Q_ratio, quiet);
  double Ymax = 0.5*log(1./x); // kinematical bound
  double rap_int_lo   = vrap::rap_integrated_lo  (-Ymax, Ymax);

  cout << endl;
  cout << "------------------------------" << endl;
  cout << "--- Vegas Integration Test ---" << endl;
  cout << "------------------------------" << endl;
  cout << endl << "The following two results should be equal up to ~0.1% :" << endl;
  cout << "VRAP LO result is:    " << rap_int_lo   << endl;
  cout << "VTOT LO result is:    " << xd_lo   << endl << endl;




  cout << endl << "Do you want to perform a Luminosity test (taken form VRAP code)?  (y/N)" << endl;
  char answer;
  answer = getchar();
  if(answer=='y' || answer=='Y') vrap::lumi_test();


  return 0;

}

