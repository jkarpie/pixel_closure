#include <fstream>
#include <sys/time.h>

#include "QCD_EW.hh"            // QCD & EW constants and functions
#include "LHAPDF_interface.hh"  // interface with LHAPDF
#include "vrap.hh"              // Rapidity distributions
#include "resummation.hh"       // Resummation 




using namespace std;

/* ! ! ! ! ! ! ! ! !  IMPORTANT  ! ! ! ! ! ! ! ! !

   Do NOT to use "using namespace ..." globally for the namespaces defined in ReDY codes.

*/





int main(){

  //--------------------------------
  //  PDF initialization !!
  //--------------------------------
  // Refer to the LHAPDF library ( http://projects.hepforge.org/lhapdf/ )
  // for a detailed list of available pdf's sets.

  PDF::pdf_init("NNPDF21_100",0,SILENT);
  //PDF::pdf_init("cteq66",0,SILENT);
  //PDF::pdf_init("mrst2004nnlo");
  //PDF::pdf_init("mrst2001nlo");

  PDF::PrintPDFInfo();



  //Start time counter
  struct timeval t0, t1;
  gettimeofday(&t0,NULL);





  //----------------------------
  // Rapidity distribution
  // (without uncertainty bands)
  //----------------------------

  /* 
     Now we are going to compute the differential rapidity cross-section for a Drell-Yan process.
     Here we set some variable that identify the process (collider, exchange virtual boson, energies, ...)
     Then we call the vrap::init(..) function to initialize the program with these variables.
     Finally we compute the value of the differential cross section at LO, NLO and NNLO for a grid of values
     of the rapidity Y and the corresponding resummation contributions at LL, NLL, NNLL.
     The output will be written in a file named by the string variable "filename".
  */

  double CM_energy = 7000.;    // in GeV (LHC)
  collider coll = pp;          // can be either pp (or LHC) or ppbar (or Tevatron)
  exchange exch = Zgamma;      // set which virtual particle(s) is (are) considered. Possibilities are:
                               // - for neutral final state: gamma_only, Zgamma_interf, Z_only, Zgamma (=gamma_only+Zgamma_interf+Z_only)
                               // - for charged final state: Wplus, Wminus
  double Q = MASS::mass_Z;     // in GeV, final state DY pair invariant mass 
  double muR_Q_ratio = 1.;     // muR/Q
  double muF_Q_ratio = 1.;     // muF/Q
  double x = SQR(Q/CM_energy); // useful variable x; is dependent on Q and CM_energy
  bool quiet = 1;              // flag for output verbosity: 0=verbose, 1=quiet

  // Initialize VRAP and resumm stuff:
  vrap::init(CM_energy, Q, coll, exch, muR_Q_ratio, muF_Q_ratio, quiet);
  resumm::InitFromVrap();

  // Approximate PDFs
  PDF::UseApproximatePDFs();
  PDF::pdfs_approx( Q*muF_Q_ratio, x );
  resumm::DontUseApproxPDFsForMinimalPrescription(true);
  resumm::DontUseApproxPDFsForBorelPrescription(true);

  // If you don't want to compute 2 times the NLO contribution, set to TRUE and sum to the NLO result
  vrap::SetNNLOonly(true);

  // Set variables for loop
  const int nY=21;
  double Ymax = 0.5*log(1./x); // kinematical bound
  double Y[nY];
  double rapd_lo  [nY];
  double rapd_nlo [nY];
  double rapd_nnlo[nY];
  double resB_lo  [nY];
  double resB_nlo [nY];
  double resB_nnlo[nY];
  double resM_lo  [nY];
  double resM_nlo [nY];
  double resM_nnlo[nY];

  // cutoff C for Borel prescription
  double C=2.;
  // set the kind of logs are used by the Borel prescription
  resumm::SetBorelType(1);
  // set to true to resum a partcular set of constants coming from Mellin of plus-ditributions
  resumm::SetAddConstants(true);


  // Loop over rapidity

  // change pdf here (if set before, not need to change)
  //PDF::pdf_init("mrst2001lo");
  // consider that you may want to use the value of alpha_s used in PDF fit:
  //vrap::SetAlphaQCD(PDF::GetAlpha(muR_Q_ratio*Q));
  for(int k=0; k<nY; k++) {  // LO loop
    Y[k] = ((double)k/(nY-1.)) * 1.99 * Ymax - 0.995*Ymax;
    rapd_lo  [k] = vrap::rap_distr_lo  (Y[k]);
    resB_lo  [k] = rapd_lo  [k] + resumm::Borel_rap  (Y[k],x,C,0,0,15);
    resM_lo  [k] = rapd_lo  [k] + resumm::Minimal_rap(Y[k],x,0,0,15,1);
    cout << "-";
    cout.flush();
  }
  cout << endl;
  // change pdf here
  //PDF::pdf_init("mrst2001nlo");
  //vrap::SetAlphaQCD(PDF::GetAlpha(muR_Q_ratio*Q));
  // consider that you may want to use the value of alpha_s used in PDF fit:
  //vrap::SetAlphaQCD(PDF::GetAlpha(muR_Q_ratio*Q));
  for(int k=0; k<nY; k++) {  // NLO loop
    rapd_nlo [k] = vrap::rap_distr_nlo (Y[k]);
    resB_nlo [k] = rapd_nlo [k] + resumm::Borel_rap  (Y[k],x,C,1,1,15);
    resM_nlo [k] = rapd_nlo [k] + resumm::Minimal_rap(Y[k],x,1,1,15,1);
    cout << "-";
    cout.flush();
  }
  cout << endl;
  // change pdf here
  //PDF::pdf_init("mrst2001nnlo");
  // consider that you may want to use the value of alpha_s used in PDF fit:
  //vrap::SetAlphaQCD(PDF::GetAlpha(muR_Q_ratio*Q));
  for(int k=0; k<nY; k++) {  // NNLO loop
    rapd_nnlo[k] = vrap::rap_distr_nnlo(Y[k]) + rapd_nlo[k];
    resB_nnlo[k] = rapd_nnlo[k] + resumm::Borel_rap  (Y[k],x,C,2,2,15);
    resM_nnlo[k] = rapd_nnlo[k] + resumm::Minimal_rap(Y[k],x,2,2,15,1);
    cout << "-";
    cout.flush();
  }
  cout << endl;


  // output file: will contain the results in a format suitable for gnuplot
  string filename = "./graph_rap.dat";
  ofstream file_rap(filename.c_str());

  for(int k=0; k<nY; k++){
    file_rap << setw(10) << Y[k]
	     << setw(16) << rapd_lo[k]
	     << setw(16) << rapd_nlo[k]
	     << setw(16) << rapd_nnlo[k]
	     << setw(16) << resB_lo[k]
	     << setw(16) << resB_nlo[k]
	     << setw(16) << resB_nnlo[k]
	     << setw(16) << resM_lo[k]
	     << setw(16) << resM_nlo[k]
	     << setw(16) << resM_nnlo[k]
	     << endl;
  }
  file_rap.close();






  // Finish time
  gettimeofday(&t1,NULL);
  double t=t1.tv_sec-t0.tv_sec+(t1.tv_usec-t0.tv_usec)*0.000001;
  cout << endl << endl << "Total execution time: " << t << "s" << endl << endl;





  return 0;

}

