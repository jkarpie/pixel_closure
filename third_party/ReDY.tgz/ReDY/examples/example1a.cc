#include <fstream>
#include <sys/time.h>

#include "QCD_EW.hh"            // QCD & EW constants and functions
#include "LHAPDF_interface.hh"  // interface with LHAPDF
#include "vrap.hh"              // Rapidity distributions
#include "vtot.hh"              // Integrated cross-section
#include "resummation.hh"       // Resummation 




using namespace std;

/* ! ! ! ! ! ! ! ! !  IMPORTANT  ! ! ! ! ! ! ! ! !

   Do NOT to use "using namespace ..." globally for the namespaces defined in ReDY codes.

   The motivation is that there are many functions that has the same name inside different namespaces.
   This should not be considered as a bad feature, because equal function name means equal concept,
   but the realization could be different for different parts of the program.
   For example, the namespaces vrap:: and vtot:: identifies 2 parts of the program which compute
   rapidity distributions and total cross-section respectively. Many function are of course the same,
   but acts on different internal variables and functions.
   I could have achieved the same final effect by concatenating something like vrap_ and vtot_
   to each function name, or by defining classes and promote the functions to methods.
   I preferred the namespaces way, it seems more clear to me. But remember that if you use
   the statement "using namespace vrap;" and "using namespace vtot;" globally in the same source
   and call one equal-named function the compiler will produce an error.
   If you like to divide the computation of various part of the program in functions
   (for example one function for rapidity distributions and one for total cross section),
   you can more safely state ONE of the namespaces inside each function.
*/





int main(){

  //--------------------------------
  //  PDF initialization !!
  //--------------------------------
  // Refer to the LHAPDF library ( http://projects.hepforge.org/lhapdf/ )
  // for a detailed list of available pdf's sets.
  // Note: in this example we use the same PDF set for LO, NLO and NNLO computations.
  // You may want to use consistent pdfs: see example3.cc

  PDF::pdf_init("NNPDF21_100",0,LOWKEY);
  //PDF::pdf_init("cteq66");
  //PDF::pdf_init("mrst2004nnlo");
  //PDF::pdf_init("mrst2001nlo");




  //Start time counter
  struct timeval t0, t1;
  gettimeofday(&t0,NULL);



  //----------------------------
  // Rapidity test
  //----------------------------

  /* 
     Now we are going to compute the differential rapidity cross-section for a Drell-Yan process.
     Here we set some variable that identify the process (collider, exchange virtual boson, energies, ...)
     Then we call the vrap::init(..) function to initialize the program with these variables.
     Finally we compute the 0 rapidity value of the differential cross section at LO, NLO and NNLO
     and the corresponding resummation contributions at LL, NLL, NNLL.
  */

  double CM_energy = 7000.;    // in GeV (LHC)
  collider coll = pp;          // can be either pp (or LHC) or ppbar (or Tevatron)
  exchange exch = gamma_only;  // set which virtual particle(s) is (are) considered. Possibilities are:
                               // - for neutral final state: gamma_only, Zgamma_interf, Z_only, Zgamma (=gamma_only+Zgamma_interf+Z_only)
                               // - for charged final state: Wplus, Wminus
  double Q = MASS::mass_Z;     // in GeV, final state DY pair invariant mass 
  double muR_Q_ratio = 1.;     // muR/Q
  double muF_Q_ratio = 1.;     // muF/Q
  double x = SQR(Q/CM_energy); // useful variable x; is dependent on Q and CM_energy
  bool quiet = 1;              // flag for output verbosity: 0=verbose, 1=quiet

  // Initialize VRAP stuff:
  vrap::init(CM_energy, Q, coll, exch, muR_Q_ratio, muF_Q_ratio, quiet);

  // For fast execution (5-10 times faster), you can approximate the PDFs
  // pdfs_apprx(..) must be called for each value of muF and x (if x is less than the previous value)
  PDF::UseApproximatePDFs();
  PDF::pdfs_approx( Q*muF_Q_ratio, x );
  resumm::DontUseApproxPDFsForMinimalPrescription(true);
  resumm::DontUseApproxPDFsForBorelPrescription(true);

  // If you don't want to compute 2 times the NLO contribution, set to TRUE and sum to the NLO result
  vrap::SetNNLOonly(true);

  // Set the value of rapidity Y for the differential cross-section to be computed (in this example Y=0)
  double Y = 0;
  double Ymax = 0.5*log(1./x); // kinematical bound

  // Here we call the functions which compute the rapidity distribution
  double rapd_lo   = vrap::rap_distr_lo  (Y);
  double rapd_nlo  = vrap::rap_distr_nlo (Y);
  double rapd_nnlo = vrap::rap_distr_nnlo(Y) + rapd_nlo;  // summed to the NLO because we have set NNLOonly to true above

  cout << endl << "------ Rapidity distribution ------" << endl;
  cout << "VRAP    LO result is:    " << rapd_lo   << endl;
  cout << "VRAP   NLO result is:    " << rapd_nlo  << endl;
  cout << "VRAP  NNLO result is:    " << rapd_nnlo << endl;


  // ** Resummation **
  // initialize some variables getting them from vrap initialization
  resumm::InitFromVrap();
  // set the kind of logs are used by the Borel prescription
  resumm::SetBorelType(1);
  // set to true to resum a partcular set of constants coming from Mellin of plus-ditributions
  resumm::SetAddConstants(true);
  // Here we compute the resummed contribution at LL, NLL, NNLL using both Borel and minimal prescriptions.
  // The arguments resumm::(NN)LL and resumm::(NN)LO respresent respectively the logarithmic order
  // of resummation and the fixed order result which it is matched to.
  cout << "Resum   LO result is:    " << rapd_lo   + resumm::Borel_rap  (Y,x,2.,resumm::LL,  resumm::LO,  15) << "  Borel" << endl
       << "                         " << rapd_lo   + resumm::Minimal_rap(Y,x,   resumm::LL,  resumm::LO,  15,1) << "  Minimal" << endl;
  cout << "Resum  NLO result is:    " << rapd_nlo  + resumm::Borel_rap  (Y,x,2.,resumm::NLL, resumm::NLO, 15) << "  Borel" << endl
       << "                         " << rapd_nlo  + resumm::Minimal_rap(Y,x,   resumm::NLL, resumm::NLO, 15,1) << "  Minimal" << endl;
  cout << "Resum NNLO result is:    " << rapd_nnlo + resumm::Borel_rap  (Y,x,2.,resumm::NNLL,resumm::NNLO,15) << "  Borel" << endl
       << "                         " << rapd_nnlo + resumm::Minimal_rap(Y,x,   resumm::NNLL,resumm::NNLO,15,1) << "  Minimal" << endl;
  cout << endl;




  //----------------------------
  // Rapidity integrated test
  //----------------------------

  /* 
     As a check, we integrate the rapidity distribution to verify that this corresponds to the
     cross-section we will compute obtained below.
  */

  double rap_int_lo   = vrap::rap_integrated_lo  (-Ymax, Ymax);
  double rap_int_nlo  = vrap::rap_integrated_nlo (-Ymax, Ymax);
  double rap_int_nnlo = vrap::rap_integrated_nnlo  (-Ymax, Ymax) + rap_int_nlo;  // summed to the NLO because we have set NNLOonly to true above

  cout << endl << "------ Rapidity integrated distribution ------" << endl;
  cout << "VRAP    LO result is:    " << rap_int_lo   << endl;
  cout << "VRAP   NLO result is:    " << rap_int_nlo  << endl;
  cout << "VRAP  NNLO result is:    " << rap_int_nnlo << endl;
  cout << endl;




  //----------------------------
  // Total cross-section test
  //----------------------------

  /* 
     Now we are going to compute the Q^2 differential cross-section (referred as "total") for a Drell-Yan process.
     Here we use the same variables as above.
     We compute the the Q^2 differential cross section at LO, NLO and NNLO
     and the corresponding resummation contributions at LL, NLL, NNLL.
  */

  // Initialize VTOT stuff:
  vtot::init(CM_energy, coll, exch, quiet);

  // If you don't want to compute 2 times the NLO contribution, set to TRUE and sum to the NLO result
  vtot::SetNNLOonly(true);

  /*
  // The most clear way to call x_distr_*lo
  double xd_lo   = vtot::x_distr_lo  (x,muR_Q_ratio,muF_Q_ratio);
  double xd_nlo  = vtot::x_distr_nlo (x,muR_Q_ratio,muF_Q_ratio);
  double xd_nnlo = vtot::x_distr_nnlo(x,muR_Q_ratio,muF_Q_ratio) + xd_nlo;
  /*/
  //  Alternatively (produces less output)
  vtot::set_variables(x,muR_Q_ratio,muF_Q_ratio);
  double xd_lo   = vtot::x_distr_lo  ();
  double xd_nlo  = vtot::x_distr_nlo ();
  double xd_nnlo = vtot::x_distr_nnlo() + xd_nlo;
  

  cout << endl << "------ Total cross-section ------" << endl;
  cout << "VTOT    LO result is:    " << xd_lo   << endl;
  cout << "VTOT   NLO result is:    " << xd_nlo  << endl;
  cout << "VTOT  NNLO result is:    " << xd_nnlo << endl;

  // ** Resummation **
  // initialize some variables getting them from vtot initialization
  resumm::InitFromVtot();
  // Here we compute the resummed contribution at LL, NLL, NNLL using both Borel and minimal prescriptions.
  cout << "Resum   LO result is:    " << xd_lo   + resumm::Borel_tot  (x,2.,resumm::LL,  resumm::LO,  10) << "  Borel" << endl;
  cout << "                         " << xd_lo   + resumm::Minimal_tot(x,   resumm::LL,  resumm::LO,  15,1) << "  Minimal" << endl;
  cout << "Resum  NLO result is:    " << xd_nlo  + resumm::Borel_tot  (x,2.,resumm::NLL, resumm::NLO, 10) << "  Borel" << endl
       << "                         " << xd_nlo  + resumm::Minimal_tot(x,   resumm::NLL, resumm::NLO, 15,1) << "  Minimal" << endl;
  cout << "Resum NNLO result is:    " << xd_nnlo + resumm::Borel_tot  (x,2.,resumm::NNLL,resumm::NNLO,10) << "  Borel" << endl
       << "                         " << xd_nnlo + resumm::Minimal_tot(x,   resumm::NNLL,resumm::NNLO,15,1) << "  Minimal" << endl;




  // Finish time
  gettimeofday(&t1,NULL);
  double t=t1.tv_sec-t0.tv_sec+(t1.tv_usec-t0.tv_usec)*0.000001;
  cout << endl << endl << "Total execution time: " << t << "s" << endl << endl;
  


  return 0;

}

