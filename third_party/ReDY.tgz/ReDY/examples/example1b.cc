#include <fstream>
#include <sys/time.h>

#include "QCD_EW.hh"            // QCD & EW constants and functions
#include "LHAPDF_interface.hh"  // interface with LHAPDF
#include "vrap.hh"              // Rapidity distributions
#include "vtot.hh"              // Integrated cross-section
#include "resummation.hh"       // Resummation 
#include "math/DClasses.hh"     // Contains the definitions of DVector and DMatrix



using namespace std;

/* ! ! ! ! ! ! ! ! !  IMPORTANT  ! ! ! ! ! ! ! ! !

   Do NOT to use "using namespace ..." globally for the namespaces defined in ReDY codes.

*/





int main(){

  //--------------------------------
  //  PDF initialization !!
  //--------------------------------
  // Refer to the LHAPDF library ( http://projects.hepforge.org/lhapdf/ )
  // for a detailed list of available pdf's sets.
  // Note: in this example we use the same PDF set for LO, NLO and NNLO computations.
  // You may want to use consistent pdfs: see example3.cc

  //The first argument is the set name, the second is the subset, and the third could be
  // SILENT, LOWKEY, VERBOSE
  PDF::pdf_init("NNPDF21_100",0,LOWKEY);
  //PDF::pdf_init("cteq66",0,SILENT);
  //PDF::pdf_init("mrst2004nnlo",0,LOWKEY);
  //PDF::pdf_init("mrst2001nlo",0,VERBOSE);

  // Prints some infos about the PDF set used (more or less the same you will see with LOWKEY and VERBOSE above)
  PDF::PrintPDFInfo();




  //Start time
  struct timeval t0, t1;
  gettimeofday(&t0,NULL);



  //----------------------------
  // Rapidity test
  //----------------------------

  /* 
     Now we are going to compute the differential rapidity cross-section for a Drell-Yan process.
     Here we set some variable that identify the process (collider, exchange virtual boson, energies, ...)
     Then we call the vrap::init(..) function to initialize the program with these variables.
     Finally we compute the 0 rapidity value of the differential cross section at LO, NLO and NNLO
     and the corresponding resummation contributions at LL, NLL, NNLL.
  */

  double CM_energy = 7000.;    // in GeV (LHC)
  collider coll = pp;          // can be either pp (or LHC) or ppbar (or Tevatron)
  exchange exch = gamma_only;  // set which virtual particle(s) is (are) considered. Possibilities are:
                               // - for neutral final state: gamma_only, Zgamma_interf, Z_only, Zgamma (=gamma_only+Zgamma_interf+Z_only)
                               // - for charged final state: Wplus, Wminus
  double Q = MASS::mass_Z;     // in GeV, final state DY pair invariant mass 
  double muR_Q_ratio = 1.;     // muR/Q
  double muF_Q_ratio = 1.;     // muF/Q
  double x = SQR(Q/CM_energy); // useful variable x; is dependent on Q and CM_energy
  bool quiet = 0;              // flag for output verbosity: 0=verbose, 1=quiet

  // Now, instead of using
  //   vrap::init(CM_energy, Q, coll, exch, muR_Q_ratio, muF_Q_ratio, quiet);
  // we set each parameter individually

  // These 2 functions must be called first
  vrap::SetCollider(coll);
  vrap::SetECM(CM_energy);  // alternatively vrap::SetS(SQR(CM_energy));

  vrap::SetQuiet(quiet);
  vrap::SetQ(Q);            // alternatively vrap::Setx(x);

  // renormalization and factorization scales
  double muR = muR_Q_ratio*Q;
  double muF = muF_Q_ratio*Q;
  vrap::SetScales(muR,muF); // alternatively vrap::SetScalesRatio(muR_Q_ratio,muF_Q_ratio);

  // nf and alphaQCD are optionals, set by default by SetScales:
  // Number of light quark flavors in hard cross section
  int nf = QCD::nf_of_mu(muR);
  vrap::SetNf(nf);
  // alpha strong
  double alpha_s = PDF::alphas_PDF(muR);
  vrap::SetAlphaQCD(alpha_s);

  // alpha electro-magnetic
  double alpha_e = EW::alpha_em;  // Zero energy value 1/137
  vrap::SetAlphaQED(alpha_e);

  // random number generator seed
  vrap::SetSeed(0);

  // Set the process. Call after SetQ, SetAlphaQED, SetNf.
  vrap::SetV(exch);

  // select which partonic subprocess to compute
  lumi::compute_all();
  //lumi::compute_qqbar();
  //lumi::compute_qg();
  //lumi::compute_gg(); 
  //lumi::compute_qq();
  //lumi::compute_qqbar_plus_qq();
  //
  // In the easy way, by default vrap::init(..) and vtot::init(..) call
  //   lumi::compute_all();
  // If you want to restrict to a partonic subprocess call one of these functions *AFTER* vtot::init(..) and/or vrap::init(..)

  // Print some infos; will produce nothing if quiet=1;
  vrap::PrintInfo();
  //////////////////////////



  // For fast execution (5-10 times faster), you can approximate the PDFs
  // first argument:  true or false (to choose if use approx pdfs or not)
  // second argument: interpol or chebyshev
  // third argument:  number of points (interpol) or order of approx (chebyshev)
  PDF::UseApproximatePDFs(true, interpol, 1000);
  // pdfs_apprx(..) must be called for each value of muF and x
  // it save in some way (the easier is a grid of points) the PDFs at the scale muF
  // for x (argument of the pdf) in the range [x,1] (second and third argument of pdfs_approx)
  PDF::pdfs_approx( Q*muF_Q_ratio, x, 1.);
  // in the Minimal Prescription, a Mellin transform of the luminosity is used,
  // and the values of the PDFs below x are needed.
  // You may either approximate pdfs in a wider range or suppress the approximation for the minimal prescription
  resumm::DontUseApproxPDFsForMinimalPrescription(true);
  // in the Borel prescription a Chebyshev polynomial approx is used;
  // it turns out that using approximate pdfs the Chebyshev approx is bad, hence:
  resumm::DontUseApproxPDFsForBorelPrescription(true);



  // If you don't want to compute 2 times the NLO contribution, set to TRUE and sum to the NLO result
  vrap::SetNNLOonly(true);

  // Set the value of rapidity Y for the differential cross-section to be computed (in this example Y=0)
  double Y = 0;
  double Ymax = 0.5*log(1./x); // kinematical bound

  // Here we call the functions which compute the rapidity distribution
  vrap::SetY(Y);
  vrap::SetOrder(0);
  DVector rapd_lo   = vrap::rap_y();
  vrap::SetOrder(1);
  DVector rapd_nlo  = vrap::rap_y();
  vrap::SetOrder(2);
  DVector rapd_nnlo = vrap::rap_y() + rapd_nlo;  // summed to the NLO because we have set NNLOonly to true above


  cout << endl << "------ Rapidity distribution ------" << endl;
  cout << "VRAP    LO result is:    " << rapd_lo[0]   << endl;
  cout << "VRAP   NLO result is:    " << rapd_nlo[0]  << "  pm  " << rapd_nlo[1]  << endl;
  cout << "VRAP  NNLO result is:    " << rapd_nnlo[0] << "  pm  " << rapd_nnlo[1] << endl;


  // ** Resummation **
  // initialize some variables getting them from vrap initialization
  //resumm::InitFromVrap();
  //this is the same as
  resumm::Init(vrap::GetS(),vrap::GetAlphaQCD(),vrap::GetFactScaleRatio(),vrap::GetRenormScaleRatio(),vrap::GetNf(),vrap::GetCollider());
  // don't use approximate PDFs for Minimal prescription
  PDF::UseApproximatePDFs(false);
  // set the kind of logs are used by the Borel prescription
  // (see M.Bonvini, S.Forte, G.Ridolfi, NPB xxxxx, arXiv:1009.5691 [hep-ph]):
  // type = 0  ->  eq. (3.23)
  // type = 1  ->  eq. (3.29)
  // type = 2  ->  eq. (3.21)  -- currently not completely tested
  resumm::SetBorelType(1);
  // set to true to resum a partcular set of constants coming from Mellin of plus-ditributions
  // see discussion on M.Bonvini, arXiv:xxxx.xxxx [hep-ph]  (PhD thesis)
  resumm::SetAddConstants(true);
  // Here we compute the resummed contribution at LL, NLL, NNLL using both Borel and minimal prescriptions.
  // The arguments resumm::(NN)LL and resumm::(NN)LO respresent respectively the logarithmic order
  // of resummation and the fixed order result which it is matched to.
  cout << "Resum   LO result is:    " << rapd_lo[0]   + resumm::Borel_rap  (Y,x,2.,0,0,15) << "  Borel" << endl
       << "                         " << rapd_lo[0]   + resumm::Minimal_rap(Y,x,   0,0,15,1) << "  Minimal" << endl;
  cout << "Resum  NLO result is:    " << rapd_nlo[0]  + resumm::Borel_rap  (Y,x,2.,1,1,15) << "  Borel" << endl
       << "                         " << rapd_nlo[0]  + resumm::Minimal_rap(Y,x,   1,1,15,1) << "  Minimal" << endl;
  cout << "Resum NNLO result is:    " << rapd_nnlo[0] + resumm::Borel_rap  (Y,x,2.,2,2,15) << "  Borel" << endl
       << "                         " << rapd_nnlo[0] + resumm::Minimal_rap(Y,x,   2,2,15,1) << "  Minimal" << endl;
  cout << endl;




  //----------------------------
  // Rapidity integrated test
  //----------------------------

  /* 
     As a check, we integrate the rapidity distribution to verify that this corresponds to the
     cross-section we will compute obtained below.
  */

  // Use int_y(xi_l,xi_u) to integrate over a specified rapidity interval
  double xi_l = 0.5 * (1. + tanh(-Ymax));  // range in terms of xi variable.
  double xi_u = 0.5 * (1. + tanh( Ymax));
  vrap::SetOrder(0);
  DVector LO_int_y   = vrap::int_y(xi_l, xi_u);
  vrap::SetOrder(1);
  DVector NLO_int_y  = vrap::int_y(xi_l, xi_u);
  vrap::SetOrder(2);
  DVector NNLO_int_y = vrap::int_y(xi_l, xi_u) + NLO_int_y;

  PDF::UseApproximatePDFs(true, interpol, 1000);
  cout << endl << "------ Rapidity integrated distribution ------" << endl;
  cout << "VRAP    LO result is:    " << LO_int_y[0] << endl;
  cout << "VRAP   NLO result is:    " << NLO_int_y[0]  << "  pm  " << NLO_int_y[1]   << endl;
  cout << "VRAP  NNLO result is:    " << NNLO_int_y[0] << "  pm  " << NNLO_int_y[1]   << endl;
  cout << endl;




  //----------------------------
  // Total cross-section test
  //----------------------------

  /* 
     Now we are going to compute the Q^2 differential cross-section (referred as "total") for a Drell-Yan process.
     Here we use the same variables as above.
     We compute the the Q^2 differential cross section at LO, NLO and NNLO
     and the corresponding resummation contributions at LL, NLL, NNLL.
  */

  // Now, instead of using
  //   vtot::init(CM_energy, coll, exch, quiet);
  // we set each parameter individually

  // These 2 functions must be called first
  vtot::SetCollider(coll);
  vtot::SetECM(CM_energy);  // alternatively vtot::SetS(SQR(CM_energy));

  vtot::SetQuiet(quiet);

  // alpha electro-magnetic
  alpha_e = EW::alpha_em;  // Zero energy value 1/137
  vtot::SetAlphaQED(alpha_e);

  // random number generator seed
  vtot::SetSeed(0);

  // select which partonic subprocess to compute
  lumi::compute_all();
  //lumi::compute_qqbar();
  //lumi::compute_qg();
  //lumi::compute_gg(); 
  //lumi::compute_qq();
  //lumi::compute_qqbar_plus_qq();
  //
  // In the easy way, by default vrap::init(..) and vtot::init(..) call
  //   lumi::compute_all();
  // If you want to restrict to a partonic subprocess call one of these functions *AFTER* vtot::init(..) and/or vrap::init(..)

  // Print some infos; will produce nothing if quiet=1;
  vtot::PrintInfo();
  //////////////////////////



  // If you don't want to compute 2 times the NLO contribution, set to TRUE and sum to the NLO result
  vtot::SetNNLOonly(true);



  vtot::Setx(x);  // alternatively vtot::SetQ(Q);
  // Here we call the functions which compute the rapidity distribution
  // renormalization and factorization scales
  muR = muR_Q_ratio*Q;
  muF = muF_Q_ratio*Q;
  vtot::SetScales(muR,muF); // alternatively vtot::SetScalesRatio(muR_Q_ratio,muF_Q_ratio);

  // nf and alphaQCD are optionals, set by default by SetScales:
  // Number of light quark flavors in hard cross section
  nf = QCD::nf_of_mu(muR);
  vtot::SetNf(nf);
  // alpha strong
  alpha_s = PDF::alphas_PDF(muR);
  vtot::SetAlphaQCD(alpha_s);

  // Set the process. Call after SetQ, SetAlphaQED, SetNf.
  vtot::SetV(exch);

  vtot::PrintCurrentInfo();


  vtot::SetOrder(0);
  DVector xd_lo   = vtot::int_y();
  vtot::SetOrder(1);
  DVector xd_nlo  = vtot::int_y();
  vtot::SetOrder(2);
  DVector xd_nnlo = vtot::int_y() + xd_nlo;  // summed to the NLO because we have set NNLOonly to true above


  cout << endl << "------ Total cross-section ------" << endl;
  cout << "VTOT    LO result is:    " << xd_lo[0]   << endl;
  cout << "VTOT   NLO result is:    " << xd_nlo[0]  << "  pm  " << xd_nlo[1]  << endl;
  cout << "VTOT  NNLO result is:    " << xd_nnlo[0] << "  pm  " << xd_nnlo[1] << endl;


  // ** Resummation **
  // initialize some variables getting them from vtot initialization
  //resumm::InitFromVtot();
  //this is the same as
  resumm::Init(vtot::GetS(),vtot::GetAlphaQCD(),vtot::GetFactScaleRatio(),vtot::GetRenormScaleRatio(),vtot::GetNf(),vtot::GetCollider());
  // don't use approximate PDFs for Minimal prescription
  PDF::UseApproximatePDFs(false);
  // Here we compute the resummed contribution at LL, NLL, NNLL using both Borel and minimal prescriptions.
  cout << "Resum   LO result is:    " << xd_lo[0]   + resumm::Borel_tot  (x,2.,0,0,10) << "  Borel" << endl
       << "                         " << xd_lo[0]   + resumm::Minimal_tot(x,   0,0,20) << "  Minimal" << endl;
  cout << "Resum  NLO result is:    " << xd_nlo[0]  + resumm::Borel_tot  (x,2.,1,1,10) << "  Borel" << endl
       << "                         " << xd_nlo[0]  + resumm::Minimal_tot(x,   1,1,20) << "  Minimal" << endl;
  cout << "Resum NNLO result is:    " << xd_nnlo[0] + resumm::Borel_tot  (x,2.,2,2,10) << "  Borel" << endl
       << "                         " << xd_nnlo[0] + resumm::Minimal_tot(x,   2,2,20) << "  Minimal" << endl;



  // Finish time
  gettimeofday(&t1,NULL);
  double t=t1.tv_sec-t0.tv_sec+(t1.tv_usec-t0.tv_usec)*0.000001;
  cout << endl << "Total time: " << t << "s" << endl;
  





  return 0;

}

